## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", warning = TRUE)
library(YuleInfer)

## ----fit-models---------------------------------------------------------------
data(otitis_media)
dat <- strat_data(otitis_media, reference = "Amoxicillin")
models <- c("yule", "dallal", "rosner", "donner")
fits <- setNames(lapply(models, function(model) {
  strat_fit(dat, model = model)
}), models)
fit_table <- do.call(rbind, lapply(models, function(model) {
  fit <- fits[[model]]
  data.frame(model, estimate = fit$d, se = fit$se,
             regular = fit$convergence$regular,
             logLik = as.numeric(logLik(fit)))
}))
knitr::kable(fit_table, digits = 4,
             caption = "Common RD is cefaclor minus amoxicillin")

## ----tests--------------------------------------------------------------------
methods <- c("LR", "score", "Wald")
test_table <- do.call(rbind, lapply(models, function(model) {
  do.call(rbind, lapply(methods, function(method) {
    test <- strat_test(fits[[model]], d0 = 0, method = method)
    data.frame(model, method, statistic = unname(test$statistic),
               p.value = test$p.value)
  }))
}))
knitr::kable(test_table, digits = 4,
             caption = "Two-sided zero-common-RD tests, each with 1 df")

## ----confidence-sets----------------------------------------------------------
yule_lr <- strat_confint(fits$yule, method = "LR")
yule_score <- strat_confint(fits$yule, method = "score")
yule_wald <- strat_confint(fits$yule, method = "Wald")
ci_table <- do.call(rbind, lapply(list(yule_lr, yule_score, yule_wald),
                                  as.data.frame))
knitr::kable(ci_table, digits = 4,
             caption = "Yule confidence components and completeness")

## ----incomplete-score---------------------------------------------------------
dallal_score <- strat_confint(fits$dallal, method = "score")
dallal_score$intervals
dallal_score$complete
dallal_score$diagnostics$messages

## ----finer-score-search, eval=FALSE-------------------------------------------
# dense <- strat_confint(fits$dallal, method = "score",
#                         control = list(grid.length = 129,
#                                        refinements = 2,
#                                        max.evaluations = 2000))
# dense$complete
# dense$intervals
# dense$diagnostics

## ----diagnostic-fields--------------------------------------------------------
fits$yule$convergence[c("ok", "regular", "boundary", "reason",
                        "scaled_gradient", "minimum_probability",
                        "likelihood_evaluations")]

## ----simulated-analysis-------------------------------------------------------
counts <- strat_simulate(baseline = c(.20, .35), d = .08,
                          association = .40, n_bilateral = 200,
                          n_unilateral = 50, seed = 2026, model = "yule")
simulation_fit <- strat_fit(counts, model = "yule")
vapply(methods, function(method) {
  strat_test(simulation_fit, d0 = 0, method = method)$p.value
}, numeric(1))

## ----analytic-power-----------------------------------------------------------
strat_power(baseline = c(.20, .35), association = .40,
              n_bilateral = 200, n_unilateral = 50,
              d0 = 0, delta = c(0, .04, .08), model = "yule")

## ----simulation-template, eval=FALSE------------------------------------------
# B <- 1000L
# records <- lapply(seq_len(B), function(r) {
#   counts <- strat_simulate(c(.20, .35), d = .08, association = .40,
#                             n_bilateral = 200, n_unilateral = 50,
#                             seed = 202600L + r, model = "yule")
#   do.call(rbind, lapply(models, function(model) {
#     tryCatch({
#       fit <- strat_fit(counts, model = model)
#       test <- strat_test(fit, d0 = 0, method = "LR")
#       data.frame(replicate = r, model, available = TRUE,
#                  rejected = test$p.value < .05, message = "")
#     }, error = function(e) {
#       data.frame(replicate = r, model, available = FALSE,
#                  rejected = NA, message = conditionMessage(e))
#     })
#   }))
# })
# records <- do.call(rbind, records)

