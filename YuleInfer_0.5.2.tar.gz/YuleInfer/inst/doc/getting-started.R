## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", warning = TRUE)
library(YuleInfer)

## ----clinical-counts----------------------------------------------------------
data(otitis_media)
knitr::kable(otitis_media,
             caption = "Children by age, treatment and number of cured ears")

## ----clinical-analysis--------------------------------------------------------
analysis <- yule_analyze(otitis_media, reference = "Amoxicillin",
                         model = "yule", method = "LR")
analysis

## ----extract-results----------------------------------------------------------
result <- as.data.frame(analysis)
result[c("estimate", "percentage_points", "p.value", "lower", "upper",
         "test_available", "ci_complete")]
analysis$fit$convergence$regular
analysis$confint$intervals
analysis$confint$complete

## ----prepared-data------------------------------------------------------------
dat <- strat_data(otitis_media, reference = "Amoxicillin")
dat
# Separate calls give the same model and inference as yule_analyze().
fit <- strat_fit(dat, model = "yule")
strat_test(fit, d0 = 0, method = "LR")
strat_confint(fit, method = "LR")

## ----read-own-counts, eval=FALSE----------------------------------------------
# counts <- read.csv("trial_counts.csv", stringsAsFactors = FALSE)
# my_analysis <- yule_analyze(counts, reference = "control",
#                             model = "yule", method = "LR")

## ----individual-input---------------------------------------------------------
subjects <- data.frame(
  subject = paste0("p", 1:8),
  treatment = rep(c("control", "active"), each = 4),
  left = c(0, 1, 0, 1, 0, 1, 1, NA),
  right = c(0, 0, 1, NA, 0, 1, 0, 1)
)
imported <- yule_import(subjects, group = "treatment",
                        outcomes = c("left", "right"),
                        reference = "control", id = "subject")
imported$counts

## ----individual-strata--------------------------------------------------------
subjects$age_group <- rep(c("younger", "older"), 4)
stratified <- yule_import(subjects, group = "treatment",
                    outcomes = c("left", "right"), stratum = "age_group",
                    reference = "control", id = "subject")
stratified$counts

## ----save-results, eval=FALSE-------------------------------------------------
# saveRDS(analysis, "trial_analysis.rds")
# summary_table <- as.data.frame(analysis)
# write.csv(summary_table[setdiff(names(summary_table), "intervals")],
#           "trial_summary.csv", row.names = FALSE)
# writeLines(capture.output(sessionInfo()), "session_info.txt")

## ----version------------------------------------------------------------------
packageVersion("YuleInfer")

