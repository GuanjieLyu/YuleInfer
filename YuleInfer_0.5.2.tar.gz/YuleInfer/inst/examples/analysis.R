# YuleInfer: common risk difference analysis under four association models.
# Run after installation. This example prints results and writes no files.
library(YuleInfer)

# Start with individual records and the unified analysis report.
data(paired_trial)
subjects <- yule_import(paired_trial, group = "group", outcomes = c("left", "right"),
                        stratum = "centre", reference = "control", id = "id")
result <- yule_analyze(subjects)
print(result)
print(as.data.frame(result))

# The lower-level API below supports reusable fits and customized workflows.

counts <- data.frame(
  stratum = rep(c("A", "B"), each = 2),
  group = rep(c("control", "treatment"), 2),
  m0 = c(70, 60, 55, 48), m1 = c(20, 25, 28, 30),
  m2 = c(10, 15, 17, 22), u0 = c(20, 18, 16, 14),
  u1 = c(5, 7, 9, 11)
)

# Explicit reference fixes the direction: treatment minus control.
data <- strat_data(counts, reference = "control")
models <- c("yule", "dallal", "rosner", "donner")
fits <- setNames(lapply(models, function(model) {
  strat_fit(data, model = model)
}), models)
print(data)
print(lapply(fits, summary))

# Inference uses the family recorded in each fitted object.
methods <- c("LR", "score", "Wald")
tests <- lapply(fits, function(fit) {
  if (!isTRUE(fit$convergence$regular)) return(fit$convergence)
  setNames(lapply(methods, function(method) {
    strat_test(fit, d0 = 0, method = method)
  }), methods)
})
print(tests)

# Wald intervals are quick; LR and score sets retain search diagnostics.
wald_sets <- lapply(fits, function(fit) {
  if (!isTRUE(fit$convergence$regular)) return(NULL)
  strat_confint(fit, method = "Wald")
})
print(wald_sets)

fit <- fits$yule
if (isTRUE(fit$convergence$regular)) {
  lr_set <- strat_confint(fit, method = "LR")
  print(lr_set)
  print(as.data.frame(lr_set))
  print(lr_set$complete)
}

# These native parameters represent the same reference table.
reference_association <- c(yule = .4, dallal = .7,
                           rosner = 1.4, donner = .4)
print(lapply(models, function(model) {
  strat_probabilities(.5, reference_association[[model]], model = model)
}))

# Negative Donner correlation must satisfy the margin-specific bound.
print(strat_probabilities(.20, -.10, model = "donner"))

simulated <- strat_simulate(
  baseline = c(.20, .35, .50), d = .04, association = .40,
  n_bilateral = 300, n_unilateral = 100, seed = 2026, model = "yule"
)
print(summary(strat_fit(simulated, model = "yule")))

# Own-model local power: the four null designs share the same joint tables.
baseline <- c(.20, .35, .50)
q <- strat_probabilities(baseline, .60, model = "yule")$q
association <- list(yule = rep(.60, 3), dallal = q / baseline,
                    rosner = q / baseline^2,
                    donner = (q - baseline^2) / (baseline * (1 - baseline)))
power <- setNames(lapply(models, function(model) {
  strat_power(
    baseline, association[[model]], n_bilateral = 1000,
    n_unilateral = 100, d0 = 0, h = c(0, 1, 2), model = model
  )
}), models)
print(power)
# Each model preserves its own native association away from the null.
# These values are not powers along one common true alternative path.
