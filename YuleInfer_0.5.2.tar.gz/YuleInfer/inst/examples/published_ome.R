# Four-model analysis of the published age-stratified otitis media data.
# Run after installation; this script prints results and writes no files.
library(YuleInfer)
data(otitis_media)

# Positive RD means a higher per-ear day-14 cure probability with cefaclor.
dat <- strat_data(otitis_media, reference = "Amoxicillin")
print(dat)
models <- c("yule", "dallal", "rosner", "donner")
methods <- c("LR", "score", "Wald")
fits <- setNames(lapply(models, function(model) strat_fit(dat, model = model)), models)
results <- setNames(lapply(models, function(model) {
  fit <- fits[[model]]
  setNames(lapply(methods, function(method) {
    list(test = tryCatch(strat_test(fit, d0 = 0, method = method),
                         error = conditionMessage),
         confidence_set = tryCatch(strat_confint(fit, method = method),
                                    error = conditionMessage))
  }), methods)
}), models)

for (model in models) {
  cat("\n", toupper(model), "\n", sep = "")
  print(summary(fits[[model]]))
  for (method in methods) {
    print(results[[model]][[method]]$test)
    print(results[[model]][[method]]$confidence_set)
  }
}

# Default global score inversion can be incomplete in this sparse example.
# Retain the full set and its diagnostics; finite central endpoints alone
# do not establish a complete confidence set.
# A complete LR analysis can also be obtained in one call:
print(yule_analyze(dat, model = "yule", method = "LR"))

# Published Dallal common-RD results, Liang et al. (2024), corresponding
# arXiv:2304.00162v2 Tables 28/29: d=.1742, LR (.0502,.2953),
# central score component (.0486,.2954), Wald (.0526,.2957).
# These differ from the df=2 homogeneity hypothesis in its Table 27.

