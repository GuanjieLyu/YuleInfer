#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Applic.h>
#include <R_ext/Memory.h>
#include <math.h>
#include <limits.h>
#include <stdint.h>
#include <string.h>

/* Keep separately rounded R products and additions. Use each supported
 * compiler's source directive instead of a non-portable package C flag. */
#if defined(__clang__)
#pragma clang fp contract(off)
#elif defined(__GNUC__)
#pragma GCC optimize("fp-contract=off")
#else
#pragma STDC FP_CONTRACT OFF
#endif

/*
 * Translation of .yule_evaluate_R and .classical_evaluate_R. Starting values,
 * information calculations and inference rules remain in R. The optional
 * optimizer bridge uses the same vmmin BFGS engine called by stats::optim.
 *
 * Preserve the R expression order, including separately rounded products
 * before long-double sums. Algebraically equivalent rearrangements can change
 * an optimizer path or a boundary diagnostic by a few floating-point bits.
 * Long-double accumulators reproduce the base-R sum/.rowSums kernels on the
 * supported toolchains; rowwise and columnwise likelihood sums intentionally
 * follow their respective R references.
 */

/* R's vector sqrt calls the platform library. GCC can substitute a hardware
 * builtin for a scalar sqrt, which differs by one ULP on some Windows inputs.
 * A volatile function pointer prevents this substitution without depending on
 * a compiler-specific no-builtin flag. */
static double (* volatile library_sqrt)(double) = sqrt;

static double reference_sqrt(double x)
{
    return library_sqrt(x);
}

static int is_numeric(SEXP x)
{
    return TYPEOF(x) == REALSXP || TYPEOF(x) == INTSXP;
}

static double numeric_scalar(SEXP x, const char *name)
{
    if (!is_numeric(x) || XLENGTH(x) != 1)
        error("%s must be a numeric scalar", name);
    return asReal(x);
}

static SEXP count_vector(SEXP counts, const char *key)
{
    SEXP names = getAttrib(counts, R_NamesSymbol);
    SEXP answer = R_NilValue;
    int matches = 0;

    for (R_xlen_t i = 0; i < XLENGTH(counts); i++) {
        if (!strcmp(CHAR(STRING_ELT(names, i)), key)) {
            answer = VECTOR_ELT(counts, i);
            matches++;
        }
    }
    if (matches == 1)
        return answer;
    if (matches > 1)
        error("Duplicate count vector %s", key);
    error("Missing count vector %s", key);
    return R_NilValue;
}

/* Public R input validation normalizes counts and their ordering. These
 * additional checks make direct malformed .Call invocations fail safely. */
static void validate_input(SEXP x, SEXP strata, SEXP active, SEXP model,
                           SEXP fixed, SEXP counts, SEXP derivatives)
{
    double J = numeric_scalar(strata, "J");
    double model_id = numeric_scalar(model, "model");

    if (!R_FINITE(J) || J < 1 || J != floor(J) || J > INT_MAX / 6)
        error("J must be a positive integer within matrix limits");
    if (!R_FINITE(model_id) || model_id != floor(model_id) ||
        model_id < 0 || model_id > 3)
        error("model must be an integer from zero to three");
    if (!is_numeric(x) || XLENGTH(x) > INT_MAX)
        error("x must be a numeric parameter vector");
    if (!is_numeric(active) || XLENGTH(active) > J)
        error("active must contain unique stratum indices");
    if (fixed != R_NilValue) {
        double d = numeric_scalar(fixed, "fixed");
        if (!R_FINITE(d) || fabs(d) >= 1)
            error("fixed must lie strictly between minus one and one");
    }
    if (XLENGTH(x) != (fixed == R_NilValue) + J + XLENGTH(active))
        error("Parameter vector has incompatible length");
    for (R_xlen_t i = 0; i < XLENGTH(active); i++) {
        double ai = TYPEOF(active) == INTSXP ?
            INTEGER(active)[i] : REAL(active)[i];
        if (!R_FINITE(ai) || ai != floor(ai) || ai < 1 || ai > J)
            error("Invalid active stratum index");
        for (R_xlen_t k = 0; k < i; k++) {
            double ak = TYPEOF(active) == INTSXP ?
                INTEGER(active)[k] : REAL(active)[k];
            if (ai == ak)
                error("Repeated active stratum index");
        }
    }
    if (TYPEOF(derivatives) != LGLSXP || XLENGTH(derivatives) != 1 ||
        LOGICAL(derivatives)[0] == NA_LOGICAL)
        error("derivatives must be TRUE or FALSE");

    SEXP names = getAttrib(counts, R_NamesSymbol);
    if (TYPEOF(counts) != VECSXP || TYPEOF(names) != STRSXP ||
        XLENGTH(names) != XLENGTH(counts))
        error("counts must be a named list");
    const char *keys[] = {
        "m0", "m1", "m2", "u0", "u1", "n_bilateral", "n_unilateral", "positive"
    };
    for (int k = 0; k < 8; k++) {
        SEXP value = count_vector(counts, keys[k]);
        if (!is_numeric(value) || XLENGTH(value) != 2 * J)
            error("Count vector %s has incompatible type or length", keys[k]);
    }
}

/* All allocated/coerced SEXPs remain protected until the evaluator returns. */
static double *numeric_data(SEXP x, int *nprotect)
{
    SEXP value = PROTECT(coerceVector(x, REALSXP));
    ++*nprotect;
    return REAL(value);
}

static SEXP numeric_vector(int n, int *nprotect)
{
    SEXP value = PROTECT(allocVector(REALSXP, n));
    ++*nprotect;
    return value;
}

static SEXP named_list(int n, const char **names, int *nprotect)
{
    SEXP value = PROTECT(allocVector(VECSXP, n));
    ++*nprotect;
    SEXP list_names = PROTECT(allocVector(STRSXP, n));
    ++*nprotect;
    for (int i = 0; i < n; i++)
        SET_STRING_ELT(list_names, i, mkChar(names[i]));
    setAttrib(value, R_NamesSymbol, list_names);
    return value;
}

static SEXP probability_matrix(int n, const char **columns, int *nprotect)
{
    SEXP value = PROTECT(allocMatrix(REALSXP, n, 3));
    ++*nprotect;
    if (columns) {
        SEXP dimnames = PROTECT(allocVector(VECSXP, 2));
        ++*nprotect;
        SEXP column_names = PROTECT(allocVector(STRSXP, 3));
        ++*nprotect;
        for (int k = 0; k < 3; k++)
            SET_STRING_ELT(column_names, k, mkChar(columns[k]));
        SET_VECTOR_ELT(dimnames, 1, column_names);
        setAttrib(value, R_DimNamesSymbol, dimnames);
    }
    return value;
}

static void parameter_names(SEXP output, SEXP input_names, int offset, int n,
                            int *nprotect)
{
    if (input_names == R_NilValue || n == 0)
        return;
    SEXP names = PROTECT(allocVector(STRSXP, n));
    ++*nprotect;
    for (int j = 0; j < n; j++)
        SET_STRING_ELT(names, j, STRING_ELT(input_names, offset + j));
    setAttrib(output, R_NamesSymbol, names);
}

static SEXP invalid_result(int nx, int *nprotect)
{
    const char *names[] = {"value", "gradient", "invalid"};
    SEXP answer = named_list(3, names, nprotect);
    SEXP gradient = numeric_vector(nx, nprotect);
    for (int i = 0; i < nx; i++)
        REAL(gradient)[i] = 0;
    SET_VECTOR_ELT(answer, 0, ScalarReal(1e100));
    SET_VECTOR_ELT(answer, 1, gradient);
    SET_VECTOR_ELT(answer, 2, ScalarLogical(1));
    return answer;
}

/* Immutable numeric inputs are resolved once for an optimizer invocation. */
typedef struct {
    double *m0, *m1, *m2, *u0, *u1, *nb, *nu, *positive;
    int *active;
    double *workspace;
} evaluation_inputs;

static SEXP strat_evaluate_impl(SEXP x_input, SEXP strata_input, SEXP active_input,
                      SEXP model_input, SEXP fixed_input, SEXP counts,
                      SEXP derivatives_input, const evaluation_inputs *inputs)
{
    int nprotect = 0;
    int compact = inputs != NULL;
    double *scratch = compact ? inputs->workspace : NULL;
    int J = asInteger(strata_input), n = 2 * J;
    int na = LENGTH(active_input), nx = LENGTH(x_input);
    int free = fixed_input == R_NilValue, model = asInteger(model_input);
    int derivatives = asLogical(derivatives_input);
    double *x = compact ? REAL(x_input) : numeric_data(x_input, &nprotect);
    SEXP x_names = getAttrib(x_input, R_NamesSymbol);
    int *active;
    if (compact) {
        active = inputs->active;
    } else {
        SEXP active_vector = PROTECT(coerceVector(active_input, INTSXP));
        ++nprotect;
        active = INTEGER(active_vector);
    }

    double d = free ? tanh(x[0]) : asReal(fixed_input);
    double gap = fabs(d);
    SEXP d_vector = R_NilValue;
    SEXP baseline = R_NilValue, association = R_NilValue, margins = R_NilValue;
    SEXP bh_vector = R_NilValue, bd_vector = R_NilValue, ar_vector = R_NilValue;
    double *b, *a, *pi, *bh, *bd, *ar, *ab, *ad;
    if (compact) {
        b = scratch; scratch += J;
        a = scratch; scratch += J;
        pi = scratch; scratch += n;
        bh = scratch; scratch += J;
        bd = scratch; scratch += J;
        ar = scratch; scratch += na;
    } else {
        d_vector = free ? numeric_vector(1, &nprotect) : fixed_input;
        if (free) {
            REAL(d_vector)[0] = d;
            parameter_names(d_vector, x_names, 0, 1, &nprotect);
        }
        baseline = numeric_vector(J, &nprotect);
        association = numeric_vector(J, &nprotect);
        margins = numeric_vector(n, &nprotect);
        bh_vector = numeric_vector(J, &nprotect);
        bd_vector = numeric_vector(J, &nprotect);
        ar_vector = numeric_vector(na, &nprotect);
        b = REAL(baseline); a = REAL(association); pi = REAL(margins);
        bh = REAL(bh_vector); bd = REAL(bd_vector); ar = REAL(ar_vector);
    }
    if (compact) {
        ab = scratch; scratch += na;
        ad = scratch; scratch += na;
    } else {
        ab = (double *) R_alloc(na, sizeof(double));
        ad = (double *) R_alloc(na, sizeof(double));
    }

    /* Smooth shared-RD margin coordinates; cells interleave the two groups. */
    for (int j = 0; j < J; j++) {
        double h = x[free + j], e = exp(-2 * fabs(h));
        double B = gap + e * (2 - gap);
        double small = 2 * e * (1 - gap) /
            (B + reference_sqrt(B * B + 4 * (1 - e) * e * (1 - gap)));
        if (h > 0)
            small = 1 - gap - small;
        b[j] = small + fmax(0, -d);
        pi[2 * j] = b[j];
        pi[2 * j + 1] = b[j] + d;
        double P1 = b[j] * (1 - b[j]);
        double P2 = (b[j] + d) * (1 - b[j] - d);
        double total = P1 + P2;
        bh[j] = 2 * P1 * P2 / total;
        bd[j] = -P1 / total;
        a[j] = NA_REAL;
        if (!R_FINITE(pi[2 * j]) || !R_FINITE(pi[2 * j + 1]) ||
            pi[2 * j] <= 0 || pi[2 * j] >= 1 ||
            pi[2 * j + 1] <= 0 || pi[2 * j + 1] >= 1) {
            SEXP answer = invalid_result(nx, &nprotect);
            UNPROTECT(nprotect);
            return answer;
        }
    }
    if (!compact) {
        parameter_names(baseline, x_names, free, J, &nprotect);
        parameter_names(bh_vector, x_names, free, J, &nprotect);
        parameter_names(bd_vector, x_names, free, J, &nprotect);
        if (model != 0)
            parameter_names(ar_vector, x_names, free + J, na, &nprotect);
    }

    /* Models: 0 Yule, 1 Dallal, 2 Rosner, 3 Donner. Classical bounds are
     * intersections across both groups, including signed Donner correlation. */
    for (int t = 0; t < na; t++) {
        int j = active[t] - 1;
        double p1 = pi[2 * j], p2 = pi[2 * j + 1];
        double lo = 0, hi = 1, lp1 = 0, lp2 = 0, hp1 = 0, hp2 = 0;
        if (model == 0) {
            a[j] = tanh(x[free + J + t]);
            ar[t] = 1 - a[j] * a[j];
            continue;
        }
        if (model == 1 || model == 2) {
            double maximum = d >= 0 ? p2 : p1;
            double w1 = p1 == maximum, w2 = p2 == maximum, total = w1 + w2;
            w1 /= total;
            w2 /= total;
            if (model == 1) {
                lo = fmax(0, 2 - 1 / maximum);
                double derivative = maximum > .5 ? 1 / (maximum * maximum) :
                    (maximum == .5 ? .5 / (maximum * maximum) : 0);
                lp1 = w1 * derivative;
                lp2 = w2 * derivative;
            } else {
                lo = fmax(0, (2 * maximum - 1) / (maximum * maximum));
                hi = 1 / maximum;
                double derivative = maximum > .5 ?
                    2 * (1 - maximum) / R_pow(maximum, 3) :
                    (maximum == .5 ? (1 - maximum) / R_pow(maximum, 3) : 0);
                lp1 = w1 * derivative;
                lp2 = w2 * derivative;
                hp1 = -w1 / (maximum * maximum);
                hp2 = -w2 / (maximum * maximum);
            }
        } else {
            double lower1 = p1 > .5 ? -(1 - p1) / p1 : -p1 / (1 - p1);
            double lower2 = p2 > .5 ? -(1 - p2) / p2 : -p2 / (1 - p2);
            lo = fmax(lower1, lower2);
            double w1 = lower1 == lo, w2 = lower2 == lo, total = w1 + w2;
            w1 /= total;
            w2 /= total;
            double derivative1 = p1 < .5 ? -1 / ((1 - p1) * (1 - p1)) :
                (p1 > .5 ? 1 / (p1 * p1) : 0);
            double derivative2 = p2 < .5 ? -1 / ((1 - p2) * (1 - p2)) :
                (p2 > .5 ? 1 / (p2 * p2) : 0);
            lp1 = w1 * derivative1;
            lp2 = w2 * derivative2;
        }
        double s = plogis(x[free + J + t], 0, 1, 1, 0), width = hi - lo;
        a[j] = lo + width * s;
        ar[t] = width * s * (1 - s);
        double ap1 = lp1 * (1 - s) + hp1 * s;
        double ap2 = lp2 * (1 - s) + hp2 * s;
        ab[t] = ap1 + ap2;
        ad[t] = ap2;
    }

    const char *p_columns[] = {"p0", "p1", "p2"};
    const char *pp_columns[] = {"", "", "qp"};
    const char *pa_columns[] = {"qa", "", "qa"};
    SEXP probability = R_NilValue, joint = R_NilValue, qa_vector = R_NilValue;
    SEXP qp_vector = R_NilValue, pp_matrix = R_NilValue, pa_matrix = R_NilValue;
    double *p, *q, *qa;
    double *qp = NULL, *pp = NULL, *pa = NULL;
    if (compact) {
        p = scratch; scratch += 3 * n;
        q = scratch; scratch += n;
        qa = scratch; scratch += n;
        if (model != 0 || derivatives) {
            qp = scratch; scratch += n;
            pp = scratch; scratch += 3 * n;
            pa = scratch; scratch += 3 * n;
        }
    } else {
        probability = probability_matrix(n, p_columns, &nprotect);
        joint = numeric_vector(n, &nprotect);
        qa_vector = numeric_vector(n, &nprotect);
        p = REAL(probability); q = REAL(joint); qa = REAL(qa_vector);
        if (model != 0 || derivatives) {
            qp_vector = numeric_vector(n, &nprotect);
            pp_matrix = probability_matrix(n, model == 0 ? NULL : pp_columns, &nprotect);
            pa_matrix = probability_matrix(n, pa_columns, &nprotect);
            qp = REAL(qp_vector);
            pp = REAL(pp_matrix);
            pa = REAL(pa_matrix);
        }
    }
    double *up, *ua;
    if (compact) {
        up = scratch; scratch += n;
        ua = scratch; scratch += n;
    } else {
        up = (double *) R_alloc(n, sizeof(double));
        ua = (double *) R_alloc(n, sizeof(double));
    }
    double *m0 = compact ? inputs->m0 : numeric_data(count_vector(counts, "m0"), &nprotect);
    double *m1 = compact ? inputs->m1 : numeric_data(count_vector(counts, "m1"), &nprotect);
    double *m2 = compact ? inputs->m2 : numeric_data(count_vector(counts, "m2"), &nprotect);
    double *u0 = compact ? inputs->u0 : numeric_data(count_vector(counts, "u0"), &nprotect);
    double *u1 = compact ? inputs->u1 : numeric_data(count_vector(counts, "u1"), &nprotect);
    double *nb = compact ? inputs->nb : numeric_data(count_vector(counts, "n_bilateral"), &nprotect);
    double *nu = compact ? inputs->nu : numeric_data(count_vector(counts, "n_unilateral"), &nprotect);
    double *positive = compact ? inputs->positive : numeric_data(count_vector(counts, "positive"), &nprotect);
    long double ll_bilateral = 0, ll_unilateral = 0;

    for (int i = 0; i < n; i++) {
        double v = pi[i], ass = a[i / 2], P = v * (1 - v);
        double p0, p1, p2, qpi = 0, qass;
        /* Independent placeholders carry zero bilateral weight for inactive
         * strata; their association parameter remains NA in natural output. */
        if (ISNA(ass))
            ass = model == 1 ? v : (model == 2 ? 1 : 0);
        if (model == 0) {
            double one_minus = 1 - ass, one_plus = 1 + ass;
            double D = one_minus * one_minus + 16 * ass * P;
            if (ass < 0) {
                double distance_signed = 1 - 2 * v;
                D = one_plus * one_plus - (4 * ass) *
                    (distance_signed * distance_signed);
            }
            double r = 2 * P * one_minus / (one_minus + reference_sqrt(D));
            double theta = (one_plus / one_minus) * (one_plus / one_minus);
            double product = theta * (r * r), distance = fabs(1 - 2 * v);
            double small = 2 * product /
                (distance + reference_sqrt(distance * distance + 4 * product));
            p0 = small + distance;
            p2 = small;
            if (v > .5) {
                p0 = small;
                p2 = small + distance;
            }
            p1 = 2 * r;
            double w0 = p1 * p2, w1 = 4 * p0 * p2, w2 = p0 * p1;
            double denominator = w0 + w1 + w2;
            qass = 4 * p0 * p2 * (p1 / denominator) / (one_minus * one_plus);
            if (derivatives) {
                pp[i] = -(w1 + 2 * w2) / denominator;
                pp[i + n] = 2 * (w2 - w0) / denominator;
                pp[i + 2 * n] = (2 * w0 + w1) / denominator;
                qpi = pp[i + 2 * n];
            }
        } else if (model == 1) {
            p2 = ass * v;
            p0 = 1 - 2 * v + p2;
            if (v > .5)
                p0 = v * (ass - (2 - 1 / v));
            p1 = 2 * v * (1 - ass);
            qpi = ass;
            qass = v;
        } else if (model == 2) {
            p2 = ass * (v * v);
            p0 = 1 - 2 * v + p2;
            if (v > .5)
                p0 = v * v * (ass - (2 * v - 1) / (v * v));
            p1 = 2 * v * (1 - ass * v);
            qpi = 2 * ass * v;
            qass = v * v;
        } else {
            p2 = v * (v + ass * (1 - v));
            p0 = (1 - v) * (1 - v + ass * v);
            p1 = 2 * P * (1 - ass);
            qpi = 2 * v + ass * (1 - 2 * v);
            qass = P;
        }
        p[i] = p0;
        p[i + n] = p1;
        p[i + 2 * n] = p2;
        q[i] = p2;
        qa[i] = qass;
        if (!R_FINITE(p0) || !R_FINITE(p1) || !R_FINITE(p2) ||
            p0 <= 0 || p1 <= 0 || p2 <= 0 || (model == 0 && !R_FINITE(qass))) {
            SEXP answer = invalid_result(nx, &nprotect);
            UNPROTECT(nprotect);
            return answer;
        }
        if (qp) {
            qp[i] = qpi;
            pa[i] = qass;
            pa[i + n] = -2 * qass;
            pa[i + 2 * n] = qass;
        }
        if (model != 0) {
            pp[i] = qpi - 2;
            pp[i + n] = 2 - 2 * qpi;
            pp[i + 2 * n] = qpi;
        }
        if (model == 0) {
            double t0 = 2 * v, t1 = 1 - 2 * v, t2 = 2 - 2 * v;
            double variance = p0 * (t0 * t0) + p1 * (t1 * t1) + p2 * (t2 * t2);
            up[i] = 2 * (positive[i] - 2 * nb[i] * v) / variance +
                (u1[i] - nu[i] * v) / P;
            ua[i] = qass * (m0[i] / p0 - 2 * m1[i] / p1 + m2[i] / p2);
            ll_bilateral += (double) (m0[i] * log(p0) + m1[i] * log(p1) +
                                     m2[i] * log(p2));
        } else {
            double w0 = m0[i] / p0, w1 = m1[i] / p1, w2 = m2[i] / p2;
            long double score_pi = (double) (w0 * pp[i]);
            score_pi += (double) (w1 * pp[i + n]);
            score_pi += (double) (w2 * pp[i + 2 * n]);
            long double score_a = (double) (w0 * pa[i]);
            score_a += (double) (w1 * pa[i + n]);
            score_a += (double) (w2 * pa[i + 2 * n]);
            up[i] = (double) score_pi + (u1[i] - nu[i] * v) / P;
            ua[i] = (double) score_a;
        }
        ll_unilateral += (double) (u1[i] * log(v) + u0[i] * log1p(-v));
    }
    if (model != 0) {
        /* R's sum(counts$m * log(pr$p)) traverses columns, not rows. */
        for (int column = 0; column < 3; column++) {
            for (int i = 0; i < n; i++) {
                double count = column == 0 ? m0[i] : (column == 1 ? m1[i] : m2[i]);
                ll_bilateral += (double) (count * log(p[i + column * n]));
            }
        }
    }
    double loglik = (double) ll_bilateral + (double) ll_unilateral;

    /* Natural scores followed by the unchanged transformed-coordinate chain
     * rule. Each R sum is rounded separately before combining its result. */
    SEXP score_vector = compact ? R_NilValue : numeric_vector(1 + J + na, &nprotect);
    SEXP gradient_vector = numeric_vector(nx, &nprotect);
    double *score = compact ? scratch : REAL(score_vector);
    double *gradient = REAL(gradient_vector);
    long double sum_ud = 0, sum_bd = 0, sum_ad = 0;
    for (int j = 0; j < J; j++) {
        score[1 + j] = up[2 * j] + up[2 * j + 1];
        sum_ud += up[2 * j + 1];
        sum_bd += (double) (score[1 + j] * bd[j]);
        gradient[free + j] = score[1 + j] * bh[j];
    }
    score[0] = (double) sum_ud;
    for (int t = 0; t < na; t++) {
        int j = active[t] - 1;
        score[1 + J + t] = ua[2 * j] + ua[2 * j + 1];
        double U = score[1 + J + t];
        if (model != 0) {
            gradient[free + j] = gradient[free + j] + U * ab[t] * bh[j];
            sum_ad += (double) (U * (ad[t] + ab[t] * bd[j]));
        }
        gradient[free + J + t] = U * ar[t];
    }
    if (free) {
        double gd = score[0] + (double) sum_bd;
        if (model != 0)
            gd = gd + (double) sum_ad;
        gradient[0] = (1 - d * d) * gd;
    }
    int invalid = !R_FINITE(loglik);
    for (int i = 0; i < nx; i++) {
        gradient[i] = -gradient[i];
        if (!R_FINITE(gradient[i]))
            invalid = 1;
    }
    if (x_names != R_NilValue) {
        SEXP names = PROTECT(allocVector(STRSXP, nx));
        ++nprotect;
        for (int i = 0; i < nx; i++)
            SET_STRING_ELT(names, i, mkChar(""));
        if (free)
            SET_STRING_ELT(names, 0, STRING_ELT(x_names, 0));
        for (int j = 0; j < J; j++)
            SET_STRING_ELT(names, free + j, STRING_ELT(x_names, free + j));
        if (model != 0) {
            for (int t = 0; t < na; t++)
                SET_STRING_ELT(names, free + J + t,
                               STRING_ELT(x_names, free + J + t));
        }
        setAttrib(gradient_vector, R_NamesSymbol, names);
    }

    if (compact) {
        const char *compact_names[] = {"value", "gradient", "invalid"};
        SEXP answer = named_list(3, compact_names, &nprotect);
        SET_VECTOR_ELT(answer, 0, ScalarReal(-loglik));
        SET_VECTOR_ELT(answer, 1, gradient_vector);
        SET_VECTOR_ELT(answer, 2, ScalarLogical(invalid));
        UNPROTECT(nprotect);
        return answer;
    }

    const char *natural_names[] = {
        "d", "baseline", "association", "pi", "bh", "bd", "ar", "free", "ab", "ad"
    };
    SEXP natural = named_list(model == 0 ? 8 : 10, natural_names, &nprotect);
    SET_VECTOR_ELT(natural, 0, d_vector);
    SET_VECTOR_ELT(natural, 1, baseline);
    SET_VECTOR_ELT(natural, 2, association);
    SET_VECTOR_ELT(natural, 3, margins);
    SET_VECTOR_ELT(natural, 4, bh_vector);
    SET_VECTOR_ELT(natural, 5, bd_vector);
    SET_VECTOR_ELT(natural, 6, ar_vector);
    SET_VECTOR_ELT(natural, 7, ScalarLogical(free));
    if (model != 0) {
        SEXP ab_vector = numeric_vector(na, &nprotect);
        SEXP ad_vector = numeric_vector(na, &nprotect);
        for (int t = 0; t < na; t++) {
            REAL(ab_vector)[t] = ab[t];
            REAL(ad_vector)[t] = ad[t];
        }
        parameter_names(ab_vector, x_names, free + J, na, &nprotect);
        parameter_names(ad_vector, x_names, free + J, na, &nprotect);
        SET_VECTOR_ELT(natural, 8, ab_vector);
        SET_VECTOR_ELT(natural, 9, ad_vector);
    }
    const char *full_probability_names[] = {"p", "q", "qp", "qa", "pp", "pa"};
    const char *brief_probability_names[] = {"p", "q", "qa"};
    int full_probability = model != 0 || derivatives;
    SEXP probabilities = named_list(full_probability ? 6 : 3,
        full_probability ? full_probability_names : brief_probability_names, &nprotect);
    SET_VECTOR_ELT(probabilities, 0, probability);
    SET_VECTOR_ELT(probabilities, 1, joint);
    if (full_probability) {
        SET_VECTOR_ELT(probabilities, 2, qp_vector);
        SET_VECTOR_ELT(probabilities, 3, qa_vector);
        SET_VECTOR_ELT(probabilities, 4, pp_matrix);
        SET_VECTOR_ELT(probabilities, 5, pa_matrix);
    } else {
        SET_VECTOR_ELT(probabilities, 2, qa_vector);
    }
    const char *result_names[] = {
        "value", "gradient", "score", "natural", "probability", "invalid"
    };
    SEXP answer = named_list(6, result_names, &nprotect);
    SET_VECTOR_ELT(answer, 0, ScalarReal(-loglik));
    SET_VECTOR_ELT(answer, 1, gradient_vector);
    SET_VECTOR_ELT(answer, 2, score_vector);
    SET_VECTOR_ELT(answer, 3, natural);
    SET_VECTOR_ELT(answer, 4, probabilities);
    SET_VECTOR_ELT(answer, 5, ScalarLogical(invalid));
    UNPROTECT(nprotect);
    return answer;
}

SEXP C_strat_evaluate(SEXP x_input, SEXP strata_input, SEXP active_input,
                      SEXP model_input, SEXP fixed_input, SEXP counts,
                      SEXP derivatives_input)
{
    validate_input(x_input, strata_input, active_input, model_input,
                   fixed_input, counts, derivatives_input);
    return strat_evaluate_impl(x_input, strata_input, active_input,
        model_input, fixed_input, counts, derivatives_input, NULL);
}

typedef struct {
    SEXP strata, active, model, fixed, counts, derivatives, state, x_names;
    SEXP last_symbol, val_symbol, compact_symbol, evaluations_symbol;
    evaluation_inputs inputs;
} optimizer_context;

static SEXP state_field(SEXP state, SEXP name)
{
    if (R_BindingIsActive(name, state))
        error("Optimizer state fields must not be active bindings");
    SEXP value = findVarInFrame(state, name);
    if (value == R_UnboundValue)
        error("Optimizer state is missing %s", CHAR(PRINTNAME(name)));
    if (R_BindingIsLocked(name, state))
        error("Optimizer state fields must not be locked");
    return value;
}

static SEXP cached_field(SEXP value, const char *name)
{
    if (TYPEOF(value) != VECSXP)
        error("Cached evaluation must be a named list");
    SEXP names = getAttrib(value, R_NamesSymbol);
    if (TYPEOF(names) != STRSXP || XLENGTH(names) != XLENGTH(value))
        error("Cached evaluation must be a named list");
    for (R_xlen_t i = 0; i < XLENGTH(value); i++)
        if (!strcmp(CHAR(STRING_ELT(names, i)), name))
            return VECTOR_ELT(value, i);
    error("Cached evaluation is missing %s", name);
    return R_NilValue;
}

/* R's optim BFGS entry point calls vmmin with the same unit scaling and
 * defaults below. Only the callback language boundary changes. All mutable
 * state belongs to this fit's environment; nothing is shared across workers.
 */
static SEXP optimizer_evaluate(int n, double *x, optimizer_context *context)
{
    void *scratch = vmaxget();
    SEXP point = PROTECT(allocVector(REALSXP, n));
    for (int i = 0; i < n; i++) {
        if (!R_FINITE(x[i]))
            error("non-finite value supplied by optim");
        REAL(point)[i] = x[i];
    }
    if (context->x_names != R_NilValue)
        setAttrib(point, R_NamesSymbol, context->x_names);
    SEXP last = findVarInFrame(context->state, context->last_symbol);
    if (last != R_NilValue && R_compute_identical(point, last, 16)) {
        SEXP value = findVarInFrame(context->state, context->val_symbol);
        UNPROTECT(1);
        vmaxset(scratch);
        return value;
    }
    SEXP value = PROTECT(strat_evaluate_impl(point, context->strata,
        context->active, context->model, context->fixed, context->counts,
        context->derivatives, &context->inputs));
    int count = asInteger(findVarInFrame(context->state, context->evaluations_symbol));
    if (count == INT_MAX)
        error("Optimizer evaluation count exceeds the integer limit");
    SEXP compact = PROTECT(ScalarLogical(1));
    SEXP evaluations = PROTECT(ScalarInteger(count + 1));
    defineVar(context->last_symbol, point, context->state);
    defineVar(context->val_symbol, value, context->state);
    defineVar(context->compact_symbol, compact, context->state);
    defineVar(context->evaluations_symbol, evaluations, context->state);
    /* The environment owns point/value before transient native scratch is
     * released. The vmmin workspace allocated before this callback survives.
     */
    vmaxset(scratch);
    UNPROTECT(4);
    return value;
}

static double optimizer_value(int n, double *x, void *extra)
{
    SEXP value = optimizer_evaluate(n, x, (optimizer_context *) extra);
    return asReal(cached_field(value, "value"));
}

static void optimizer_gradient(int n, double *x, double *gradient, void *extra)
{
    SEXP value = optimizer_evaluate(n, x, (optimizer_context *) extra);
    SEXP g = cached_field(value, "gradient");
    for (int i = 0; i < n; i++)
        gradient[i] = TYPEOF(g) == REALSXP ? REAL(g)[i] : INTEGER(g)[i];
}

SEXP C_strat_optim(SEXP x, SEXP strata, SEXP active, SEXP model,
                    SEXP fixed, SEXP counts, SEXP maxit, SEXP reltol, SEXP state)
{
    int nprotect = 0;
    SEXP derivatives = PROTECT(ScalarLogical(asInteger(model) != 0));
    ++nprotect;
    validate_input(x, strata, active, model, fixed, counts, derivatives);
    double iterations = numeric_scalar(maxit, "maxit");
    double tolerance = numeric_scalar(reltol, "reltol");
    if (!R_FINITE(iterations) || iterations < 1 || iterations != floor(iterations) ||
        iterations > INT_MAX)
        error("maxit must be a positive integer");
    if (!R_FINITE(tolerance) || tolerance <= 0 || tolerance >= 1)
        error("reltol must lie strictly between zero and one");
    if (TYPEOF(state) != ENVSXP || R_EnvironmentIsLocked(state))
        error("state must be an unlocked environment");
    optimizer_context context;
    context.strata = strata; context.active = active; context.model = model;
    context.fixed = fixed; context.counts = counts; context.derivatives = derivatives;
    context.state = state; context.x_names = getAttrib(x, R_NamesSymbol);
    context.last_symbol = install("last"); context.val_symbol = install("val");
    context.compact_symbol = install("compact");
    context.evaluations_symbol = install("evaluations");
    SEXP last = state_field(state, context.last_symbol);
    SEXP value = state_field(state, context.val_symbol);
    SEXP compact = state_field(state, context.compact_symbol);
    SEXP evaluations = state_field(state, context.evaluations_symbol);
    if (TYPEOF(compact) != LGLSXP || XLENGTH(compact) != 1 ||
        LOGICAL(compact)[0] == NA_LOGICAL)
        error("state$compact must be TRUE or FALSE");
    if (TYPEOF(evaluations) != INTSXP || XLENGTH(evaluations) != 1 ||
        INTEGER(evaluations)[0] == NA_INTEGER || INTEGER(evaluations)[0] < 0)
        error("state$evaluations must be a nonnegative integer");
    int n = LENGTH(x);
    if (last == R_NilValue) {
        if (value != R_NilValue || LOGICAL(compact)[0])
            error("An empty optimizer state must have val=NULL and compact=FALSE");
    } else {
        if (!is_numeric(last) || XLENGTH(last) != n)
            error("state$last has incompatible type or length");
        SEXP v = cached_field(value, "value");
        SEXP g = cached_field(value, "gradient");
        SEXP invalid = cached_field(value, "invalid");
        if (!is_numeric(v) || XLENGTH(v) != 1 || !is_numeric(g) || XLENGTH(g) != n ||
            TYPEOF(invalid) != LGLSXP || XLENGTH(invalid) != 1 ||
            LOGICAL(invalid)[0] == NA_LOGICAL)
            error("state$val has incompatible cached fields");
    }
    /* Coercions and count-name lookups happen once, while all resulting R
     * objects remain protected throughout vmmin and its callbacks.
     */
    SEXP indices = PROTECT(coerceVector(active, INTSXP)); ++nprotect;
    context.inputs.active = INTEGER(indices);
    context.inputs.m0 = numeric_data(count_vector(counts, "m0"), &nprotect);
    context.inputs.m1 = numeric_data(count_vector(counts, "m1"), &nprotect);
    context.inputs.m2 = numeric_data(count_vector(counts, "m2"), &nprotect);
    context.inputs.u0 = numeric_data(count_vector(counts, "u0"), &nprotect);
    context.inputs.u1 = numeric_data(count_vector(counts, "u1"), &nprotect);
    context.inputs.nb = numeric_data(count_vector(counts, "n_bilateral"), &nprotect);
    context.inputs.nu = numeric_data(count_vector(counts, "n_unilateral"), &nprotect);
    context.inputs.positive = numeric_data(count_vector(counts, "positive"), &nprotect);
    SEXP x_numeric = PROTECT(coerceVector(x, REALSXP)); ++nprotect;
    SEXP par = PROTECT(duplicate(x_numeric)); ++nprotect;
    /* One private scratch buffer survives all callbacks of this vmmin call.
     * The largest evaluator branch needs 35*J + 4*na + 1 doubles: natural
     * coordinates, probabilities and derivatives, marginal scores, and the
     * natural score vector. All slots are written before each read. Only
     * copied R result objects escape the callback; no scratch pointer does.
     */
    size_t scratch_capacity = SIZE_MAX / sizeof(double);
    size_t strata_length = (size_t) asInteger(strata);
    size_t active_length = (size_t) LENGTH(active);
    if (active_length > (scratch_capacity - 1) / 4 ||
        strata_length > (scratch_capacity - 1 - 4 * active_length) / 35)
        error("Optimizer workspace exceeds the addressable allocation size");
    size_t scratch_length = 35 * strata_length + 4 * active_length + 1;
    context.inputs.workspace = (double *) R_alloc(scratch_length, sizeof(double));
    int *mask = (int *) R_alloc(n, sizeof(int));
    for (int i = 0; i < n; i++) mask[i] = 1;
    double minimum;
    int fncount, grcount, fail;
    vmmin(n, REAL(par), &minimum, optimizer_value, optimizer_gradient,
        (int) iterations, 0, mask, R_NegInf, tolerance, 10,
        &context, &fncount, &grcount, &fail);
    const char *names[] = {"par", "value", "counts", "convergence", "message"};
    SEXP answer = named_list(5, names, &nprotect);
    SEXP count = PROTECT(allocVector(INTSXP, 2)); ++nprotect;
    INTEGER(count)[0] = fncount; INTEGER(count)[1] = grcount;
    SEXP count_names = PROTECT(allocVector(STRSXP, 2)); ++nprotect;
    SET_STRING_ELT(count_names, 0, mkChar("function"));
    SET_STRING_ELT(count_names, 1, mkChar("gradient"));
    setAttrib(count, R_NamesSymbol, count_names);
    SET_VECTOR_ELT(answer, 0, par);
    SET_VECTOR_ELT(answer, 1, ScalarReal(minimum));
    SET_VECTOR_ELT(answer, 2, count);
    SET_VECTOR_ELT(answer, 3, ScalarInteger(fail));
    SET_VECTOR_ELT(answer, 4, R_NilValue);
    UNPROTECT(nprotect);
    return answer;
}

static const R_CallMethodDef call_methods[] = {
    {"C_strat_evaluate", (DL_FUNC) &C_strat_evaluate, 7},
    {"C_strat_optim", (DL_FUNC) &C_strat_optim, 9},
    {NULL, NULL, 0}
};

void R_init_YuleInfer(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, call_methods, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
    R_forceSymbols(dll, TRUE);
}
