# YuleInfer

**Inference for correlated binary data using Yule's Colligation Coefficient.**

YuleInfer compares two groups with paired binary outcomes, such as responses in
two eyes or two ears. Subjects with only one observed outcome can also contribute.
Use one stratum for an unstratified analysis, or multiple strata sharing a common
risk difference. Yule's colligation coefficient (Yule's Y, not Yule's Q) describes
within-subject association. Dallal, Rosner and Donner likelihood models are also
available for comparison.

The effect is the response probability in the comparison group **minus** that
in the reference group. A difference of 0.05 means **5 percentage points**.
Whether a positive difference is beneficial depends on how the outcome is coded.

## Installation

YuleInfer 0.5.2 is distributed as a source archive and a Windows binary. It has
not been published to CRAN. With the release file in your working directory:

```r
# Windows binary built for R 4.5.x:
install.packages("YuleInfer_0.5.2.zip", repos = NULL, type = "win.binary")

# Other platforms, or a source installation (requires R's C build tools):
# install.packages("YuleInfer_0.5.2.tar.gz", repos = NULL, type = "source")

library(YuleInfer)
```

Requires R >= 4.0. Runtime dependencies are only R's standard stats and utils
packages. The compiled engine is included in the Windows binary. `knitr`,
`rmarkdown` and Pandoc are needed to rebuild vignettes from a development
checkout, but are not needed to run an analysis or read the supplied HTML.

## Documentation

The two vignettes provide a clinical walkthrough and a guide to model choices,
inference diagnostics, and efficient repeated analyses. A PDF reference manual
is included in the release.

```r
browseVignettes("YuleInfer")
vignette("getting-started", package = "YuleInfer")
vignette("models-and-inference", package = "YuleInfer")
help(package = "YuleInfer")
```

## Start with one row per subject

The included `paired_trial` dataset is synthetic: 500 independent subjects in
two groups and two strata, with paired and single observed outcomes.

```r
data(paired_trial)
head(paired_trial)

dat <- yule_import(
  paired_trial,
  group = "group", outcomes = c("left", "right"),
  stratum = "centre", reference = "control", id = "id"
)

result <- yule_analyze(dat)
result
as.data.frame(result)
```

This fits the Yule model, tests a zero risk difference with a two-sided
likelihood-ratio (LR) test, and constructs a 95% LR confidence set. The printed
report shows the group order, sample size, estimate, percentage-point difference,
p-value, interval components and availability diagnostics.

Outcome columns must contain 0/1 or FALSE/TRUE. Two observed outcomes form a
bilateral subject; one observed outcome forms a unilateral subject. A row with
neither outcome observed is rejected, rather than silently dropped. A missing
outcome must mean that only one response is observed: the importer does not
establish the statistical assumptions needed for that observation pattern.

Omit `stratum` for a single stratum. Supply one outcome column for entirely
unilateral data. If supplied, `id` must uniquely identify each subject across
the entire table; repeated visits are not independent subjects. Always choose
`reference` explicitly for a reproducible direction; the default is the first
observed group. Column selectors are quoted names.

## Start with a count table

```r
counts <- data.frame(
  group = c("control", "treatment"),
  m0 = c(70, 60), m1 = c(20, 25), m2 = c(10, 15),
  u0 = c(20, 18), u1 = c(5, 7)
)
result <- yule_analyze(counts, reference = "control")
```

Use one row per group in each stratum. Add a `stratum` column when there is more
than one stratum. Every stratum must include subjects from both groups.

- `m0`, `m1`, `m2`: bilateral subjects with zero, one or two positive responses.
- `u0`, `u1`: unilateral subjects with a negative or positive response.
- `m1` counts subjects, not the number of positive organs.
- Omit both unilateral columns for bilateral-only data, or all three bilateral
  columns for unilateral-only data. Partial sets of columns are rejected.
- Missing, negative, fractional or nonfinite counts are rejected.

`as.data.frame(dat)` returns the normalized count table for checking or export.
Total sample size counts subjects; each bilateral subject counts once.

## Use the published otitis media dataset

`otitis_media` contains the real age-stratified counts from the cefaclor versus
amoxicillin trial of Mandel et al. (1982), as tabulated by Liang et al. (2024).
It describes 203 children evaluable after 14 days: 75 bilateral and 128
unilateral subjects in three age groups. A positive outcome is an effusion-free
ear. This is an aggregated clinical table, distinct from the synthetic
`paired_trial` teaching records.

```r
data(otitis_media)
ome <- strat_data(otitis_media, reference = "Amoxicillin")
yule_analyze(ome)

# Run all four models, all three tests, and all three confidence sets:
source(system.file("examples", "published_ome.R", package = "YuleInfer"))
```

`?otitis_media` documents response coding, sample sizes and provenance. The
clinical trial is DOI 10.1097/00006454-198209000-00006; the tabulated source is
DOI 10.1007/s00362-024-01532-6 (Table 26 in arXiv:2304.00162v2). The installed
example preserves any incomplete score-inversion diagnostics in this sparse
sample. Use the original counts and explicit reference order for reproducibility.

## Choose the test, null and association model

```r
# Score inference against a nonzero null, with a 90% confidence set:
yule_analyze(dat, d0 = 0.02, method = "score", conf.level = 0.90)

# The same workflow under a classical association restriction:
yule_analyze(dat, model = "donner", method = "LR")

# Compare all four models without changing the input data or effect direction:
models <- c("yule", "dallal", "rosner", "donner")
analyses <- setNames(lapply(models, function(m) {
  yule_analyze(dat, model = m)
}), models)
comparison <- do.call(rbind, lapply(analyses, as.data.frame))

# Export scalar summaries; retain `analyses` for complete interval components:
# write.csv(comparison[setdiff(names(comparison), "intervals")],
#           "model_comparison.csv", row.names = FALSE)
```

Use `conf.level` in `yule_analyze()` and `level` in `strat_confint()` or
`confint()` to set the confidence level. Model and method names are quoted
strings; column selectors in `yule_import()` are also quoted column names.

Methods are `"LR"`, `"score"` and `"Wald"`; LR is the default, not a guarantee
of best finite-sample performance. All tests are two-sided. These functions do
not implement one-sided noninferiority tests. `d0` is the tested null; it does
not constrain the fitted effect or change the confidence level.

Each stratum has its own association parameter, shared across its two groups.
The native parameter is Yule's colligation coefficient, Dallal's conditional
response probability, Rosner's conditional-to-marginal risk ratio, or Donner's
within-pair correlation. The latter three have margin-dependent feasibility
bounds. Numerically equal parameters across different models do not generally
describe the same distribution. See `?strat_models` for definitions and bounds.

Selecting a model changes its shared-association assumption. Comparing outputs
does not validate that assumption. These are common-risk-difference likelihood
procedures under the four families, not reproductions of every published named
test. In particular, the Donner option is not `aod::donner`'s adjusted chi-square
test. No random effects, multiple treatment groups, regression covariates or
other effect measures are fitted.

## Inspect and reuse an analysis

```r
fit <- result$fit
summary(fit)
fitted(fit)
result$test
result$confint
result$diagnostics

# Reuse the fitted model for another inference request:
strat_test(fit, d0 = 0, method = "Wald")
strat_confint(fit, method = "score")
```

`yule_analyze()` keeps a fit, test and confidence-set object together. Invalid
input produces an error. A numerical failure or nonregular fit remains visible
in the result, with unavailable inference explicitly recorded. Check status
fields before using exported results in a report or simulation summary.

LR and score inversion can yield several disjoint intervals or an incomplete
search. `as.data.frame(result)` supplies scalar lower and upper endpoints only
for one complete finite interval; its list-column retains all interval
components. Inspect `result$confint` and its diagnostics in other cases.
Completeness describes the search at its reported numerical resolution; it is
not a proof that every arbitrarily narrow component has been found. Never turn
unavailable tests into nonrejections or incomplete intervals into ordinary CIs.

For simulations or customized workflows, use `strat_fit()`, `strat_test()` and
`strat_confint()` separately so you only compute what is needed. Recent null
fits and completed confidence sets are cached on the fitted object. Default
optimization and inversion controls should normally be retained; changing them
can affect numerical convergence or search completeness.

## Assumptions and troubleshooting

Subjects and strata must be independent. The two responses within a bilateral
subject are exchangeable with equal marginal probabilities. The risk difference
is common across strata, and the selected native association is shared between
groups within each stratum. Unilateral and bilateral subjects in the same group
and stratum must have the same per-unit marginal response probability. Outcome-
dependent missingness can violate this assumption.

Inference uses large-sample reference distributions. Small, sparse or boundary
samples can give imperfect calibration or unavailable regular inference. The
package checks numerical regularity; it does not test common-effect homogeneity
or protect against arbitrary model misspecification.

- **Wrong effect direction:** set `reference` and check the printed group order.
- **Nonregular fit:** inspect `result$diagnostics` and the observed counts;
  all-zero/all-one cells or boundary association can prevent regular inference.
- **Incomplete CI:** inspect `result$confint$diagnostics`; finite central
  endpoints alone do not certify a complete confidence set.
- **Unilateral-only stratum:** association is unidentifiable there and is omitted
  from fitting; the subjects still inform the common risk difference.

## Further functions and migration

`strat_simulate()` generates aggregated counts and `strat_probabilities()`
checks a model's paired probabilities. `strat_power()` supplies an own-model
local asymptotic approximation, not a simulated finite-sample power curve.

YuleInfer succeeds StratYule 0.4.2. Replace `library(StratYule)` with
`library(YuleInfer)` and change qualified calls from `StratYule::` to
`YuleInfer::`. Existing `strat_*` and `yule_*` functions and fit classes remain.
The original `yule_fit`, `yule_simulate`, `yule_probabilities` and `yule_power`
entry points remain Yule-only; the new `yule_analyze` explicitly selects a model.
Refit saved analyses from their original counts when migrating between package
names; do not rely on serialized private cache environments. Avoid attaching
both packages in the same session because they export shared function names.

```r
help(package = "YuleInfer")
browseVignettes("YuleInfer")
source(system.file("examples", "published_ome.R", package = "YuleInfer"))
citation("YuleInfer")
```

## Development and contact

Authors: Guanjie Lyu and Xinwei Huang.

Maintainer: Guanjie Lyu, <lvg@uwindsor.ca>. MIT license. See `CONTRIBUTING.md`
for reproducible issue reports, numerical validation and build instructions.
The source contains base-R tests, independent likelihood checks, R reference
implementations of the compiled engine, and a Windows/macOS/Linux CI workflow.
The workflow runs after publication to a repository; its presence does not
imply that every platform has already passed.
