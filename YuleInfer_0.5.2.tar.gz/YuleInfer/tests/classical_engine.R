library(YuleInfer)

internal <- function(name) getFromNamespace(name, "YuleInfer")
prob <- internal(".model_prob")
fit_classical <- internal(".classical_fit")
make_data <- internal(".make_yule_data")
encode <- internal(".classical_encode")
evaluate <- internal(".classical_evaluate")
counts_for <- internal(".yule_fit_counts")
information <- internal(".classical_information")
bounds <- internal(".classical_bounds")

near <- function(x, y, tol = 1e-7) {
  stopifnot(length(x) == length(y), all(is.finite(x)), all(is.finite(y)),
            max(abs(x - y)) < tol)
}
must_error <- function(expr) {
  stopifnot(inherits(tryCatch({ force(expr); NULL }, error = identity), "error"))
}

# These tables and Jacobians are constructed directly from the native laws,
# independently of the engine's feasible transformation and information blocks.
oracle <- function(pi, a, model) {
  a <- rep(a, length.out = length(pi))
  q <- switch(model, dallal = a * pi, rosner = a * pi^2,
              donner = pi^2 + a * pi * (1 - pi))
  qp <- switch(model, dallal = a, rosner = 2 * a * pi,
               donner = 2 * pi + a * (1 - 2 * pi))
  qa <- switch(model, dallal = pi, rosner = pi^2, donner = pi * (1 - pi))
  list(p = cbind(1 - 2 * pi + q, 2 * pi - 2 * q, q),
       pp = cbind(qp - 2, 2 - 2 * qp, qp), pa = cbind(qa, -2 * qa, qa))
}
expected_data <- function(b, d, a, n, u, model) {
  pi <- as.vector(rbind(b, b + d)); J <- length(b)
  p <- oracle(pi, rep(a, each = 2L), model)$p
  n <- rep(n, length.out = 2L * J); u <- rep(u, length.out = 2L * J)
  make_data(data.frame(stratum = rep(seq_len(J), each = 2L),
    group = rep(c("1", "2"), J), m0 = n * p[, 1L], m1 = n * p[, 2L],
    m2 = n * p[, 3L], u0 = u * (1 - pi), u1 = u * pi), integer = FALSE)
}
dense_information <- function(pi, a, n, u, active, model) {
  J <- length(a); p <- oracle(pi, rep(a, each = 2L), model)
  ans <- matrix(0, 1L + J + length(active), 1L + J + length(active))
  for (k in seq_along(pi)) {
    j <- (k + 1L) %/% 2L; second <- k %% 2L == 0L
    jac <- matrix(0, 3L, ncol(ans)); margin <- numeric(ncol(ans))
    margin[1L] <- second; margin[1L + j] <- 1
    jac[, 1L + j] <- p$pp[k, ]
    if (second) jac[, 1L] <- p$pp[k, ]
    if (j %in% active) jac[, 1L + J + match(j, active)] <- p$pa[k, ]
    ans <- ans + n[k] * crossprod(jac / sqrt(p$p[k, ])) +
      u[k] * tcrossprod(margin) / (pi[k] * (1 - pi[k]))
  }
  ans
}

native <- list(dallal = c(.45, .65, .8), rosner = c(1.3, 1.35, 1.35),
               donner = c(.3, -.15, .2))
n <- c(250, 320, 280, 310, 350, 270); u <- c(70, 40, 80, 55, 30, 95)
for (model in names(native)) {
  a <- native[[model]]; b <- c(.2, .4, .6)
  for (d in c(-.08, 0, .08)) {
    pi <- as.vector(rbind(b, b + d)); active <- 1:3
    p <- prob(pi, rep(a, each = 2L), model)
    op <- oracle(pi, rep(a, each = 2L), model)
    near(p$p, op$p, 2e-15); near(p$pp, op$pp, 2e-15); near(p$pa, op$pa, 2e-15)
    # A scalar association must produce one derivative row for every margin.
    near(prob(pi, a[3L], model)$pp, oracle(pi, a[3L], model)$pp, 2e-15)
    bd <- bounds(pi, model)
    stopifnot(all(a > bd$lower), all(a < bd$upper), all(p$p > 0))
    data <- expected_data(b, d, a, n, u, model)
    info <- information(pi, a, n, u, active, data$strata, model)
    dense <- dense_information(pi, a, n, u, active, model)
    near(info$matrix, dense, 2e-10)
    near(info$efficient, 1 / solve(dense)[1L, 1L], 2e-10)
    f <- fit_classical(data, model)
    stopifnot(f$convergence$regular, f$convergence$scaled_gradient <= 1e-5)
    near(f$d, d, 2e-7); near(f$baseline, b, 2e-7); near(f$association, a, 2e-7)
    near(f$information, dense, 1e-3)
    restricted <- fit_classical(data, model, d = d, start = f)
    stopifnot(restricted$convergence$regular, restricted$fixed)
    near(restricted$logLik_kernel, f$logLik_kernel, 2e-9)
    # Transform derivatives include the moving intersection-of-bounds terms.
    counts <- counts_for(data); counts$m <- cbind(counts$m0, counts$m1, counts$m2)
    for (fixed in list(NULL, d)) {
      x <- encode(d, b, a, active, model, fixed)
      x <- x + seq_along(x) * .003
      if (d == 0 && is.null(fixed)) x[1L] <- 0
      val <- evaluate(x, data, active, model, fixed, counts)
      fd <- vapply(seq_along(x), function(k) {
        xp <- xm <- x; xp[k] <- xp[k] + 1e-5; xm[k] <- xm[k] - 1e-5
        (evaluate(xp, data, active, model, fixed, counts)$value -
           evaluate(xm, data, active, model, fixed, counts)$value) / 2e-5
      }, numeric(1L))
      near(val$gradient, fd, if (d == 0) 2e-3 else 2e-6)
    }
    # The same native family is invariant to exchanging the two groups.
    swapped <- make_data(data$counts, reference = "2", integer = FALSE)
    fs <- fit_classical(swapped, model)
    stopifnot(fs$convergence$regular)
    near(fs$d, -f$d, 2e-7); near(fs$baseline, f$baseline + f$d, 2e-7)
    near(fs$association, f$association, 2e-7)
    near(fs$logLik_kernel, f$logLik_kernel, 2e-9)
    near(fs$efficient_information, f$efficient_information, 2e-5)
    must_error(fit_classical(data, model, start = 1))
    wrong <- f; wrong$model <- if (model == "donner") "rosner" else "donner"
    must_error(fit_classical(data, model, start = wrong))
  }
}

# Inactive associations remain unidentified; their hypothetical tables cannot
# corrupt information when there are no bilateral observations in a stratum.
for (model in names(native)) {
  a <- native[[model]]; b <- c(.2, .4, .6); d <- .04
  nn <- c(250, 320, 0, 0, 0, 270)
  data <- expected_data(b, d, a, nn, u, model)
  fit <- fit_classical(data, model)
  stopifnot(fit$convergence$regular, identical(fit$active_association, c(1L, 3L)),
            is.na(fit$association[2L]), all(is.na(fit$probabilities$p0[3:4])))
  near(fit$d, d, 2e-7); near(fit$association[c(1, 3)], a[c(1, 3)], 2e-7)
  all_uni <- expected_data(b, d, a, rep(0, 6), u, model)
  fu <- fit_classical(all_uni, model)
  stopifnot(fu$convergence$regular, all(is.na(fu$association)))
  near(fu$d, d, 2e-7); near(fu$baseline, b, 2e-7)
  iu <- information(as.vector(rbind(b, b + d)), rep(NA_real_, 3), rep(0, 6),
                    u, integer(), all_uni$strata, model)
  near(iu$matrix, fu$information, 1e-3)
}

# A sample consisting solely of negative outcomes must not report regular
# normal/chi-square inference, even when transformed optimization settles.
degenerate <- data.frame(stratum = rep(1:2, each = 2), group = rep(c("1", "2"), 2),
                         m0 = 100, m1 = 0, m2 = 0, u0 = 30, u1 = 0)
for (model in names(native)) {
  f <- fit_classical(make_data(degenerate), model)
  stopifnot(!f$convergence$regular, is.na(f$se))
}
