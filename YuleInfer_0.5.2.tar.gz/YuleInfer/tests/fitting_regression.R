library(YuleInfer)

# Synthetic rare-outcome counts reproduce a 0.1.0 fit whose likelihood
# stopping rule left its standardized score above the default tolerance.
# Keep the counts fixed so the regression does not depend on RNG settings.
counts <- data.frame(
  stratum = rep(c("1", "2", "3"), each = 2),
  group = rep(c("1", "2"), 3),
  m0 = c(290, 212, 267, 205, 248, 180),
  m1 = c(9, 47, 26, 54, 33, 62),
  m2 = c(1, 41, 7, 41, 19, 58),
  u0 = c(30, 24, 26, 24, 26, 21),
  u1 = c(0, 6, 4, 6, 4, 9)
)
fit <- yule_fit(counts)
null <- yule_fit(counts, d = .2)
stopifnot(isTRUE(fit$convergence$regular), isTRUE(null$convergence$regular),
          fit$convergence$scaled_gradient <= fit$controls$gradient_tol,
          null$convergence$scaled_gradient <= null$controls$gradient_tol,
          abs(fit$d - .178290318603822) < 1e-6,
          abs(fit$logLik_kernel + 1194.86905756004) < 1e-7,
          abs(null$logLik_kernel + 1196.18304635011) < 1e-7)
tests <- lapply(c("LR", "score", "Wald"), function(method)
  yule_test(fit, d0 = .2, method = method))
stopifnot(all(vapply(tests, function(test)
  is.finite(test$statistic) && is.finite(test$p.value) &&
    test$p.value >= 0 && test$p.value <= 1, logical(1))),
  abs(unname(tests[[1L]]$statistic) - 2.62797758014) < 1e-6)
cat("Rare-outcome fitting regression passed.\n")
