library(YuleInfer)

# Clone the real package closures into an isolated environment so that we can
# count actual constrained fits without changing the installed namespace.
ns <- asNamespace("YuleInfer")
probe <- new.env(parent = ns)
for (nm in ls(ns, all.names = TRUE)) {
  f <- get(nm, envir = ns, inherits = FALSE)
  if (is.function(f) && !is.primitive(f)) {
    environment(f) <- probe
    assign(nm, f, envir = probe)
  }
}
calls <- new.env(parent = emptyenv()); calls$n <- 0L
real_fit <- probe$.yule_fit
probe$.yule_fit <- function(...) {
  calls$n <- calls$n + 1L
  real_fit(...)
}
expect_calls <- function(n) stopifnot(identical(calls$n, as.integer(n)))
same_statistic <- function(x, y) {
  stopifnot(isTRUE(all.equal(unname(x$statistic), unname(y$statistic),
                            tolerance = 1e-8)),
            isTRUE(all.equal(x$p.value, y$p.value, tolerance = 1e-8)))
}
without_cache <- function(fit) { attr(fit, ".yule_cache") <- NULL; fit }
fresh_cache <- function(fit) {
  attr(fit, ".yule_cache") <- new.env(parent = emptyenv())
  fit
}

dat <- yule_simulate(c(.15, .35, .55), .07, c(-.3, .4, .7),
                     n_bilateral = 400, n_unilateral = 120, seed = 6102043)
fit <- probe$yule_fit(dat)
stopifnot(isTRUE(fit$convergence$regular))
calls$n <- 0L
lr <- probe$yule_test(fit, d0 = .05, method = "LR")
expect_calls(1L)
score <- probe$yule_test(fit, d0 = .05, method = "score")
expect_calls(1L)
cold_score <- probe$yule_test(without_cache(fit), d0 = .05, method = "score")
expect_calls(2L); same_statistic(score, cold_score)
same_statistic(lr, probe$yule_test(fit, d0 = .05, method = "LR"))
expect_calls(2L)
probe$yule_test(fit, d0 = .04, method = "score")
expect_calls(3L)
probe$yule_test(fit, d0 = .05, method = "score")
expect_calls(3L) # A recently used null remains reusable.

# A serialized fit restores a matching snapshot; the statistic is unchanged.
saved <- tempfile(fileext = ".rds")
saveRDS(fit, saved)
restored <- readRDS(saved)
unlink(saved)
same_statistic(score, probe$yule_test(restored, d0 = .05, method = "score"))
expect_calls(3L)

# Legacy fits without the private attribute remain usable and refit each time.
legacy <- without_cache(fit)
same_statistic(score, probe$yule_test(legacy, d0 = .05, method = "score"))
same_statistic(score, probe$yule_test(legacy, d0 = .05, method = "score"))
expect_calls(5L)

# Every input affecting the restricted likelihood or its starting values
# invalidates the snapshot, even when fit copies share the cache environment.
for (kind in c("baseline", "association", "controls", "data", "d")) {
  original <- probe$yule_fit(dat)
  probe$yule_test(original, d0 = .05, method = "score")
  changed <- original
  if (kind == "baseline") changed$baseline[1L] <- changed$baseline[1L] + .002
  if (kind == "association") changed$association[1L] <- changed$association[1L] + .02
  if (kind == "controls") changed$controls$reltol <- 1e-9
  if (kind == "d") changed$d <- changed$d + .002
  if (kind == "data") {
    changed$data$counts$m0[1L] <- changed$data$counts$m0[1L] + 1L
    changed$data$counts$n_bilateral[1L] <- changed$data$counts$n_bilateral[1L] + 1L
    changed$data$N <- changed$data$N + 1L
  }
  before <- calls$n
  changed_score <- probe$yule_test(changed, d0 = .05, method = "score")
  expect_calls(before + 1L)
  same_statistic(changed_score,
    probe$yule_test(without_cache(changed), d0 = .05, method = "score"))
  expect_calls(before + 2L)
  # The changed copy shares the cache, but the original snapshot is retained.
  # Returning to it must reuse its fit and agree with an uncached original.
  original_score <- probe$yule_test(original, d0 = .05, method = "score")
  expect_calls(before + 2L)
  same_statistic(original_score,
    probe$yule_test(without_cache(original), d0 = .05, method = "score"))
  expect_calls(before + 3L)
}

# At most four recent null fits are retained, with least-recent-use eviction.
recent <- fresh_cache(fit)
before <- calls$n
for (d0 in c(.01, .02, .03, .04))
  probe$yule_test(recent, d0 = d0, method = "LR")
expect_calls(before + 4L)
probe$yule_test(recent, d0 = .01, method = "score")
expect_calls(before + 4L)
probe$yule_test(recent, d0 = .05, method = "score")
expect_calls(before + 5L)
probe$yule_test(recent, d0 = .02, method = "score")
expect_calls(before + 6L)
stopifnot(length(attr(recent, ".yule_cache")$null_entries) == 4L,
          identical(attr(recent, ".yule_cache")$entry$key$d0, .02))

# Failed/nonregular restricted fits never become reusable entries. This
# physical RD forces at least one margin below the unchanged boundary cutoff.
guard <- probe$yule_fit(dat)
before <- calls$n
for (method in c("LR", "score")) {
  failed <- try(probe$yule_test(guard, d0 = 1 - 5e-9, method = method), silent = TRUE)
  stopifnot(inherits(failed, "try-error"),
            is.null(attr(guard, ".yule_cache", exact = TRUE)$entry))
}
expect_calls(before + 2L)

# Wald needs no constrained fit, and individual CI profile evaluations retain
# their separate starts and controls rather than using public-null cache fits.
before <- calls$n
probe$yule_test(fit, d0 = .05, method = "Wald")
expect_calls(before)
profile <- probe$.yule_profile_statistic(fit, d0 = .05, method = "score",
                                       use.cache = FALSE)
expect_calls(before + 1L)
stopifnot(abs(profile$statistic - unname(score$statistic)) < 1e-8)
custom_start <- list(d = fit$d, baseline = fit$baseline,
                     association = fit$association)
custom_start$baseline[1L] <- custom_start$baseline[1L] + .002
before <- calls$n
custom <- probe$.yule_profile_statistic(fit, d0 = .05, method = "score",
                                       start = custom_start, use.cache = TRUE)
expect_calls(before + 1L)
stopifnot(abs(custom$statistic - unname(score$statistic)) < 1e-7)

# A completed CI can be reused exactly, while an uncached scan performs the
# same grid, root solves and fit evaluations. Keep these diagnostic controls
# small solely to make the regression test quick; public defaults are unchanged.
ci_control <- list(grid.length = 9L, refinements = 0L)
ci_fit <- fresh_cache(fit)
before <- calls$n
ci <- probe$yule_confint(ci_fit, method = "LR", control = ci_control)
stopifnot(ci$complete, calls$n > before,
          calls$n - before == ci$diagnostics$evaluations)
before <- calls$n
stopifnot(identical(ci, probe$yule_confint(ci_fit, method = "LR", control = ci_control)))
expect_calls(before)
cold_ci <- probe$yule_confint(without_cache(ci_fit), method = "LR", control = ci_control)
stopifnot(identical(ci, cold_ci), calls$n > before)

# R's value semantics also protect the retained answer from user edits.
edited_ci <- ci
edited_ci$intervals[1L] <- edited_ci$intervals[1L] + .1
before <- calls$n
stopifnot(identical(ci, probe$yule_confint(ci_fit, method = "LR", control = ci_control)))
expect_calls(before)

# CI snapshots include every full-fit field used by the search or its starts.
# Copies share an environment, but each changed input must trigger a fresh scan.
for (kind in c("data", "d", "baseline", "association", "controls", "se",
               "efficient_information", "logLik", "logLik_kernel", "convergence")) {
  changed <- ci_fit
  if (kind == "baseline") changed$baseline[1L] <- changed$baseline[1L] + .002
  if (kind == "association") changed$association[1L] <- changed$association[1L] + .02
  if (kind == "controls") changed$controls$reltol <- 1e-9
  if (kind == "d") changed$d <- changed$d + .002
  if (kind == "se") changed$se <- changed$se * 1.05
  if (kind == "efficient_information")
    changed$efficient_information <- changed$efficient_information * 1.01
  if (kind == "logLik") changed$logLik <- changed$logLik + 1e-6
  if (kind == "logLik_kernel") changed$logLik_kernel <- changed$logLik_kernel + 1e-6
  if (kind == "convergence") changed$convergence$reason <- "Copied regular fit."
  if (kind == "data") {
    changed$data$counts$m0[1L] <- changed$data$counts$m0[1L] + 1L
    changed$data$counts$n_bilateral[1L] <- changed$data$counts$n_bilateral[1L] + 1L
    changed$data$N <- changed$data$N + 1L
  }
  before <- calls$n
  changed_ci <- probe$yule_confint(changed, method = "LR", control = ci_control)
  stopifnot(calls$n > before)
  cold <- probe$yule_confint(without_cache(changed), method = "LR", control = ci_control)
  stopifnot(identical(changed_ci, cold))
}

# Confidence level, test family and numerical controls all distinguish entries.
for (kind in c("level", "method", "root.tol", "fit.control")) {
  args <- list(object = ci_fit, method = "LR", control = ci_control)
  if (kind == "level") args$level <- .9
  if (kind == "method") args$method <- "score"
  if (kind == "root.tol") args$control$root.tol <- 2e-6
  if (kind == "fit.control") args$control$fit.control <- list(reltol = 5e-11)
  before <- calls$n
  changed_ci <- do.call(probe$yule_confint, args)
  stopifnot(calls$n > before)
  args$object <- without_cache(ci_fit)
  stopifnot(identical(changed_ci, do.call(probe$yule_confint, args)))
}

# A nonregular full fit is rejected before any cached result can be returned.
nonregular <- ci_fit
nonregular$convergence$regular <- FALSE
before <- calls$n
failed <- try(probe$yule_confint(nonregular, method = "LR", control = ci_control),
              silent = TRUE)
stopifnot(inherits(failed, "try-error"))
expect_calls(before)

# Incomplete confidence sets are never memoized; preserve their unknown grid
# regions and repeat the same finite evaluation budget on the next request.
limited <- fresh_cache(fit)
before <- calls$n
incomplete <- probe$yule_confint(limited, method = "LR",
                               control = list(max.evaluations = 25L))
stopifnot(!incomplete$complete, incomplete$diagnostics$evaluations == 25L,
          is.null(attr(limited, ".yule_cache")$ci_entries))
expect_calls(before + 25L)
again <- probe$yule_confint(limited, method = "LR",
                          control = list(max.evaluations = 25L))
stopifnot(identical(incomplete, again))
expect_calls(before + 50L)

# CI retention is bounded at four completed sets, with matching snapshots
# restored by serialization and least-recent-use eviction after four entries.
recent_ci <- fresh_cache(fit)
for (level in c(.85, .875, .9, .925))
  probe$yule_confint(recent_ci, level = level, method = "LR", control = ci_control)
stopifnot(length(attr(recent_ci, ".yule_cache")$ci_entries) == 4L)
before <- calls$n
retained <- probe$yule_confint(recent_ci, level = .85, method = "LR", control = ci_control)
expect_calls(before)
probe$yule_confint(recent_ci, level = .95, method = "LR", control = ci_control)
before <- calls$n
probe$yule_confint(recent_ci, level = .875, method = "LR", control = ci_control)
stopifnot(calls$n > before, length(attr(recent_ci, ".yule_cache")$ci_entries) == 4L)
saved <- tempfile(fileext = ".rds")
saveRDS(recent_ci, saved)
restored <- readRDS(saved)
unlink(saved)
before <- calls$n
stopifnot(identical(retained, probe$yule_confint(restored, level = .85,
                                             method = "LR", control = ci_control)))
expect_calls(before)
cat("Restricted-fit and confidence-set cache tests passed.\n")
