library(YuleInfer)

must_error <- function(expr) {
  stopifnot(inherits(tryCatch(force(expr), error = identity), "error"))
}

# Optional structural columns must produce exactly the same analysis inputs.
bilateral <- data.frame(group = c("control", "treatment"),
                       m0 = c(70, 60), m1 = c(20, 25), m2 = c(10, 15))
prepared <- strat_data(bilateral, reference = "control")
explicit <- bilateral
explicit$stratum <- "1"
stopifnot(identical(prepared, strat_data(explicit, reference = "control")),
          identical(as.data.frame(prepared), prepared$counts), prepared$J == 1L)
unilateral <- data.frame(group = c("control", "treatment"),
                        u0 = c(75, 60), u1 = c(25, 40))
explicit <- unilateral
explicit$stratum <- "1"
explicit$m0 <- explicit$m1 <- explicit$m2 <- 0
stopifnot(identical(strat_data(unilateral), strat_data(explicit)))
for (model in c("yule", "dallal", "rosner", "donner")) {
  a <- strat_fit(unilateral, model = model)
  b <- strat_fit(explicit, model = model)
  stopifnot(identical(coef(a), coef(b)), identical(a$information, b$information),
            isTRUE(a$convergence$regular), all(is.na(a$association)))
}
must_error(strat_data(bilateral[c("group", "m0", "m1")]))
must_error(strat_data(unilateral[c("group", "u0")]))
must_error(strat_data(unilateral["group"]))

# At independence and equal margins, total efficient information is n/P
# for n bilateral subjects per group. The intermediate product used to overflow.
tiny <- yule_power(1e-155, 0, n_bilateral = 100, h = 0)
stopifnot(is.finite(tiny$total_information),
          abs(tiny$total_information / 1e157 - 1) < 1e-12,
          abs(tiny$power - .05) < 1e-12)
stopifnot(identical(strat_power(1e-155, 0, 100, h = 0)$power, tiny$power))
must_error(yule_power(1e-300, 0, n_bilateral = 1e100, h = 0))
for (model in c("yule", "dallal", "rosner", "donner")) {
  association <- c(yule = 0, dallal = .2, rosner = 1, donner = 0)[[model]]
  null_power <- strat_power(.2, association, 100, h = 0, alpha = 1e-20, model = model)
  stopifnot(abs(null_power$power / 1e-20 - 1) < 1e-12)
}
set.seed(917)
old_seed <- .Random.seed
must_error(yule_simulate(1e-200, 0, 0, 10, seed = 1))
stopifnot(identical(old_seed, .Random.seed))
cat("Single-stratum, unilateral-only and extreme-information checks passed.\n")
