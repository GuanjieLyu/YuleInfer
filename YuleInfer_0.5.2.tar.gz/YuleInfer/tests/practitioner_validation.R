library(YuleInfer)

counts <- data.frame(group = c("control", "treatment"),
                     m0 = c(10, 20), m1 = c(5, 4), m2 = c(2, 3))
must_error <- function(expr, pattern) {
  value <- tryCatch({force(expr); NULL}, error = identity)
  stopifnot(inherits(value, "error"), grepl(pattern, conditionMessage(value), fixed = TRUE))
}

# Matrix-valued columns used to be accepted and could double the subject total.
matrix_counts <- counts
matrix_counts$m0 <- I(matrix(c(10, 20, 30, 40), nrow = 2))
for (prepare in list(yule_data, strat_data, yule_analyze))
  must_error(prepare(matrix_counts), "Count column 'm0' must be a numeric vector")
bad <- counts; bad$m0 <- as.list(bad$m0)
must_error(strat_data(bad), "Count column 'm0' must be a numeric vector")
bad <- counts; bad$m0 <- as.character(bad$m0)
must_error(strat_data(bad), "Count column 'm0' must be a numeric vector")
bad <- counts; bad$m0 <- as.complex(bad$m0)
must_error(strat_data(bad), "Count column 'm0' must be a numeric vector")
bad <- counts; bad$m0 <- factor(bad$m0)
must_error(strat_data(bad), "Count column 'm0' must be a numeric vector")

# Label checks match the subject-level importer; no lists or missing labels
# are silently turned into treatment names.
bad <- counts; bad$group <- I(list("control", "treatment"))
must_error(strat_data(bad), "The 'group' column must be a vector of labels")
bad <- counts; bad$group <- I(matrix(c("control", "treatment"), ncol = 1))
must_error(strat_data(bad), "The 'group' column must be a vector of labels")
bad <- counts; bad$group[1] <- "  "
must_error(strat_data(bad), "nonempty labels")
bad <- counts; bad$stratum <- c("  ", "  ")
must_error(strat_data(bad), "nonempty labels")
bad <- counts; bad$group <- c(1, Inf)
must_error(strat_data(bad), "finite labels")
bad <- counts; bad$group[1] <- NA_character_
must_error(strat_data(bad), "nonmissing")
bad <- counts; bad$unused <- 1; names(bad)[5] <- NA_character_
must_error(strat_data(bad), "Column names must be nonmissing and unique")
must_error(strat_data(counts, reference = list("control")), "one observed treatment group")
must_error(strat_data(counts, reference = matrix("control")), "one observed treatment group")
must_error(yule_analyze(data.frame(group = c("a", "b"), response = c(0, 1))), "yule_import()")

# Valid inputs retain their values and reference semantics exactly.
prepared <- strat_data(counts, reference = "control")
factored <- counts
factored$group <- factor(factored$group, levels = c("unused", "treatment", "control"))
stopifnot(identical(strat_data(factored, reference = factor("control")), prepared))
integer_counts <- counts
integer_counts[c("m0", "m1", "m2")] <- lapply(integer_counts[c("m0", "m1", "m2")], as.integer)
stopifnot(isTRUE(all.equal(strat_data(integer_counts), prepared)), prepared$N == 44)
numeric_groups <- counts; numeric_groups$group <- c(5, 10)
stopifnot(identical(strat_data(numeric_groups, reference = 10)$groups, c("10", "5")))
spaced <- counts; spaced$group <- paste0(" ", spaced$group, " ")
stopifnot(identical(strat_data(spaced, reference = " control ")$reference, " control "))

# A complete interval can legitimately retain a boundary-profile diagnostic.
# Check the real otitis example rather than a fabricated diagnostic object.
data(otitis_media)
analysis <- yule_analyze(otitis_media, reference = "Amoxicillin", model = "rosner", method = "LR")
row <- as.data.frame(analysis)
printed <- capture.output(print(analysis))
stopifnot(row$ci_available, row$ci_complete, nzchar(row$ci_message),
          any(grepl("Confidence-set diagnostic:", printed, fixed = TRUE)),
          any(grepl(row$ci_message, printed, fixed = TRUE)),
          identical(row$intervals[[1L]], analysis$confint$intervals))

cat("Practitioner validation and complete-confidence-set diagnostic tests passed.\n")
