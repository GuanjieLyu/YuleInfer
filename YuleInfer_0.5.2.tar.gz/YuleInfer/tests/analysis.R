library(YuleInfer)

counts <- data.frame(
  stratum = rep(c("A", "B"), each = 2),
  group = rep(c("control", "treatment"), 2),
  m0 = c(70, 60, 55, 48), m1 = c(20, 25, 28, 30),
  m2 = c(10, 15, 17, 22), u0 = c(20, 18, 16, 14),
  u1 = c(5, 7, 9, 11)
)
prepared <- strat_data(counts, reference = "control")
same <- function(x, y) isTRUE(all.equal(x, y, tolerance = 1e-12))

# The one-call result must preserve the actual likelihood inference. Exercise
# every model and all three inference methods.
for (model in c("yule", "dallal", "rosner", "donner")) {
  for (method in c("LR", "score", "Wald")) {
    fit <- strat_fit(prepared, model = model)
    test <- strat_test(fit, d0 = .03, method = method)
    interval <- strat_confint(fit, level = .90, method = method)
    analysis <- yule_analyze(counts, reference = "control", model = model,
                             d0 = .03, method = method, conf.level = .90)
    row <- as.data.frame(analysis)
    stopifnot(inherits(analysis, "yule_analysis"), nrow(row) == 1L,
      same(analysis$fit$coefficients, fit$coefficients),
      same(analysis$test$statistic, test$statistic), same(analysis$test$p.value, test$p.value),
      same(analysis$confint$intervals, interval$intervals),
      identical(analysis$confint$complete, interval$complete),
      row$test_available, row$ci_available, row$fit_regular,
      row$reference == "control", row$comparison == "treatment",
      row$direction == "treatment minus control",
      same(row$percentage_points, 100 * row$estimate),
      identical(row$intervals[[1L]], analysis$confint$intervals))
  }
}

# Prepared inputs retain their reference unless the caller overrides it.
original <- yule_analyze(prepared, method = "Wald")
reverse_data <- strat_data(counts, reference = "treatment")
reversed <- yule_analyze(reverse_data, method = "Wald")
override <- yule_analyze(reverse_data, reference = "control", method = "Wald")
stopifnot(original$direction == "treatment minus control",
  reversed$direction == "control minus treatment",
  abs(reversed$fit$d + original$fit$d) < 1e-8,
  same(override$fit$d, original$fit$d),
  identical(rownames(as.data.frame(original, row.names = "study")), "study"))
printed <- capture.output(print(reversed))
stopifnot(any(grepl("control minus treatment", printed, fixed = TRUE)),
  any(grepl("percentage points", printed, fixed = TRUE)),
  any(grepl("Risk difference: -", printed, fixed = TRUE)))

# Test the display/storage contract for disconnected and unresolved sets
# without inventing a second numerical confidence-set implementation.
disconnected <- original
disconnected$confint$intervals <- matrix(c(-.2, -.1, .1, .2), ncol = 2L, byrow = TRUE,
  dimnames = list(c("component1", "component2"), c("lower", "upper")))
disconnected$confint$complete <- TRUE
disconnected$confint$connected <- FALSE
row <- as.data.frame(disconnected)
stopifnot(nrow(row) == 1L, row$ci_available, !row$ci_connected, row$ci_components == 2L,
  is.na(row$lower), is.na(row$upper), same(row$width, .2),
  identical(row$intervals[[1L]], disconnected$confint$intervals))
stopifnot(any(grepl("2 separate components", capture.output(print(disconnected)), fixed = TRUE)))
incomplete <- disconnected
incomplete$confint$complete <- FALSE
incomplete$confint$connected <- NA
incomplete$confint$intervals[2L, 2L] <- NA_real_
incomplete$confint$diagnostics$messages <- "Unresolved endpoint."
row <- as.data.frame(incomplete)
stopifnot(nrow(row) == 1L, !row$ci_available, !row$ci_complete,
  is.na(row$lower), is.na(row$upper), is.na(row$width), row$ci_components == 2L,
  row$ci_message == "Unresolved endpoint.",
  identical(row$intervals[[1L]], incomplete$confint$intervals))

# Force the existing engine's boundary diagnostic, rather than silently
# inventing regular inference for a fit that the engine rejects.
nonregular <- yule_analyze(prepared, method = "Wald", control = list(boundary_tol = .49))
row <- as.data.frame(nonregular)
stopifnot(!is.null(nonregular$fit), !nonregular$fit$convergence$regular,
  nrow(row) == 1L, !row$fit_regular, !row$test_available, !row$ci_available,
  is.na(row$p.value), is.na(row$lower), is.na(row$upper), is.na(row$std.error),
  nzchar(row$test_message), nzchar(row$ci_message))
stopifnot(any(grepl("Test unavailable:", capture.output(print(nonregular)), fixed = TRUE)))

# A failed numerical fit must also print and export one explicit result row.
# Exercise the representation directly, avoiding a toolchain-dependent
# deliberately pathological optimizer example.
failed <- original
failed$fit <- failed$test <- failed$confint <- NULL
failed$diagnostics$fit$error <- "Numerical fit failed."
failed$diagnostics$test$error <- failed$diagnostics$confint$error <- "Inference unavailable because fitting failed."
row <- as.data.frame(failed)
stopifnot(nrow(row) == 1L, row$fit_status == "fit_error", !row$fit_regular,
  !row$test_available, !row$ci_available, is.na(row$estimate), is.na(row$p.value),
  is.na(row$lower), is.na(row$upper), nrow(row$intervals[[1L]]) == 0L,
  any(grepl("Numerical fit failed.", capture.output(print(failed)), fixed = TRUE)))

# Capturing warning text must preserve the warning condition for callers.
capture_analysis <- getFromNamespace(".yule_analysis_capture", "YuleInfer")
emitted <- character()
warning_result <- withCallingHandlers(capture_analysis({warning("Recorded warning."); 17}),
  warning = function(w) {emitted <<- c(emitted, conditionMessage(w)); invokeRestart("muffleWarning")})
stopifnot(identical(warning_result$value, 17), identical(emitted, "Recorded warning."),
  identical(warning_result$warnings, "Recorded warning."), warning_result$error == "")
warned <- original
warned$diagnostics$fit$warnings <- warning_result$warnings
stopifnot(any(grepl("Recorded warnings: Recorded warning.", capture.output(print(warned)), fixed = TRUE)))

# Validation errors must escape before they could be mistaken for numerical
# inference failures in an otherwise successful analysis object.
bad <- function(...) inherits(try(yule_analyze(counts, ...), silent = TRUE), "try-error")
stopifnot(bad(d0 = 1), bad(d0 = NA_real_), bad(method = "invalid"),
  bad(model = "invalid"), bad(conf.level = 1), bad(reference = "absent"),
  bad(control = list(maxit = 0)), bad(ci_control = list(unknown = 1)),
  bad(ci_control = list(fit.control = list(unknown = 1))))
invalid_counts <- counts
invalid_counts$m0[1L] <- -1
stopifnot(inherits(try(yule_analyze(invalid_counts), silent = TRUE), "try-error"))

cat("One-call analysis, direction, inference parity, confidence-set preservation and validation tests passed.\n")
