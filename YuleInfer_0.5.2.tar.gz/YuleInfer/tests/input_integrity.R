library(YuleInfer)

dat <- yule_simulate(c(.12, .35, .65), .06, c(-.2, .3, .7),
                     n_bilateral = 300, n_unilateral = 150, seed = 6102061)
object <- yule_data(dat, reference = "1")
must_fail <- function(x) stopifnot(inherits(try(yule_fit(x), silent = TRUE), "try-error"))
negative <- object; negative$counts$m0[1L] <- -1
must_fail(negative)
fractional <- object; fractional$counts$m1[1L] <- fractional$counts$m1[1L] + .5
must_fail(fractional)
missing <- object; missing$counts$m2 <- NULL
must_fail(missing)
nonfinite <- object; nonfinite$counts$u0[1L] <- Inf
must_fail(nonfinite)

# Previously created data objects remain mutable R lists. Public fitting must
# validate their counts again and derive metadata from the current counts.
changed <- object
changed$counts$m0[1L] <- changed$counts$m0[1L] + 4L
changed$counts$u1[2L] <- changed$counts$u1[2L] + 2L
changed$counts$n_bilateral <- rep(1, nrow(changed$counts))
changed$counts$n_unilateral <- rep(0, nrow(changed$counts))
changed$N <- 0L; changed$J <- 99L
changed$strata <- "stale"; changed$groups <- c("stale1", "stale2")
fit <- yule_fit(changed)
clean <- yule_fit(yule_data(changed$counts, reference = "1"))
stopifnot(isTRUE(fit$convergence$regular),
          identical(fit$data$J, 3L), fit$data$N == object$N + 6L,
          identical(fit$data$strata, object$strata),
          identical(fit$data$groups, object$groups),
          all(fit$data$counts$n_bilateral == rowSums(fit$data$counts[c("m0", "m1", "m2")])),
          all(fit$data$counts$n_unilateral == rowSums(fit$data$counts[c("u0", "u1")])),
          abs(fit$d - clean$d) < 1e-8,
          abs(fit$logLik_kernel - clean$logLik_kernel) < 1e-8)
cat("Mutable data integrity tests passed.\n")
