library(YuleInfer)

# The optimizer's temporary arrays are private and reusable. Exercise varying
# stratum counts and omitted association coordinates against the independently
# allocated evaluator, including a named start and cache reuse across calls.
ns <- asNamespace("YuleInfer")
optimizer <- get("C_strat_optim", ns)
evaluator <- get("C_strat_evaluate", ns)
ids <- c(yule=0L, dallal=1L, rosner=2L, donner=3L)
state <- function() {
  x <- new.env(parent=emptyenv())
  x$last <- x$val <- NULL
  x$compact <- FALSE
  x$evaluations <- 0L
  x
}
for (J in c(1L, 4L, 11L)) for (pattern in c("all", "mixed", "none")) {
  counts <- data.frame(stratum=rep(seq_len(J), each=2L),
    group=rep(c("reference", "comparison"), J),
    m0=rep(c(10L, 8L), J), m1=rep(c(3L, 4L), J),
    m2=rep(c(4L, 6L), J), u0=12L, u1=8L)
  inactive <- if (pattern == "none") seq_len(J) else
    if (pattern == "mixed") seq_len(J)[seq_len(J) %% 2L == 0L] else integer()
  counts[counts$stratum %in% inactive, c("m0", "m1", "m2")] <- 0L
  data <- yule_data(counts, reference="reference")
  ct <- get(".yule_fit_counts", ns)(data)
  active <- which(ct$n_bilateral[ct$odd] + ct$n_bilateral[ct$even] > 0)
  for (model in names(ids)) for (free in c(TRUE, FALSE)) {
    fixed <- if (free) NULL else .02
    baseline <- seq(.15, .45, length.out=J)
    association <- rep(switch(model, yule=.3, dallal=.65, rosner=1.1, donner=.2), J)
    association[inactive] <- NA_real_
    start <- if (model == "yule")
      get(".yule_encode", ns)(.02, baseline, association, active, fixed) else
      get(".classical_encode", ns)(.02, baseline, association, active, model, fixed)
    names(start) <- paste0("x", seq_along(start))
    native <- state(); reference <- state()
    evaluate <- function(x) {
      if (is.null(reference$last) || !identical(x, reference$last)) {
        reference$val <- .Call(evaluator, x, J, active, unname(ids[model]),
          fixed, ct, model != "yule")
        reference$last <- x
        reference$evaluations <- reference$evaluations + 1L
      }
      reference$val
    }
    for (pass in 1:2) {
      a <- stats::optim(start, function(x)evaluate(x)$value,
        function(x)evaluate(x)$gradient, method="BFGS",
        control=list(maxit=5L, reltol=1e-10))
      b <- .Call(optimizer, start, J, active, unname(ids[model]), fixed,
        ct, 5L, 1e-10, native)
      stopifnot(identical(a, b), identical(native$last, reference$last),
        identical(native$evaluations, reference$evaluations),
        identical(native$val[c("value", "gradient", "invalid")],
          reference$val[c("value", "gradient", "invalid")]))
      start <- a$par
    }
  }
}
