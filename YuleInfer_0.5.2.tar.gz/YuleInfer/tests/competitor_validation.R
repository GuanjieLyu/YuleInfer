# Independent probability and mixed-likelihood regression for all native models.
library(YuleInfer)
close <- function(actual, expected, tolerance = 1e-7)
  stopifnot(length(actual) == length(expected), max(abs(actual-expected)) <= tolerance)
fails <- function(expression) stopifnot(inherits(tryCatch(force(expression), error=identity), "error"))
native <- function(pi, a, model) {
  if(model == "yule") {
    theta <- ((1+a)/(1-a))^2
    q <- vapply(seq_along(pi), function(k)uniroot(function(q)
      q*(1-2*pi[k]+q)-theta[k]*(pi[k]-q)^2,
      c(max(0,2*pi[k]-1),pi[k]),tol=1e-14)$root,numeric(1))
    fq <- 1/q+1/(1-2*pi+q)+2/(pi-q)
    qp <- (2/(1-2*pi+q)+2/(pi-q))/fq
    qa <- 4/((1-a^2)*fq)
  } else if(model == "dallal") { q <- a*pi; qp <- a; qa <- pi
  } else if(model == "rosner") { q <- a*pi^2; qp <- 2*a*pi; qa <- pi^2
  } else { q <- pi^2+a*pi*(1-pi); qp <- 2*pi+a*(1-2*pi); qa <- pi*(1-pi) }
  list(p=cbind(1-2*pi+q,2*(pi-q),q),pp=cbind(-2+qp,2-2*qp,qp),pa=cbind(qa,-2*qa,qa))
}
raw_information <- function(fit) {
  ct <- fit$data$counts; J <- fit$data$J
  pi <- as.vector(rbind(fit$baseline,fit$baseline+fit$d))
  pr <- native(pi,rep(fit$association,each=2),fit$model)
  m <- as.matrix(ct[c("m0","m1","m2")]); n <- rowSums(m); u <- ct$u0+ct$u1
  score <- numeric(1+2*J); information <- matrix(0,1+2*J,1+2*J)
  for(j in seq_len(J)) for(arm in 1:2) {
    k <- 2*j-2+arm
    x <- numeric(1+2*J); x[1] <- as.integer(arm==2); x[1+j] <- 1
    z <- numeric(1+2*J); z[1+J+j] <- 1
    g <- outer(pr$pp[k,],x)+outer(pr$pa[k,],z)
    score <- score+x*(sum(m[k,]*pr$pp[k,]/pr$p[k,])+ct$u1[k]/pi[k]-ct$u0[k]/(1-pi[k]))+
      z*sum(m[k,]*pr$pa[k,]/pr$p[k,])
    information <- information+n[k]*crossprod(g,g/pr$p[k,])+u[k]/(pi[k]*(1-pi[k]))*tcrossprod(x)
  }
  kernel <- sum(m*log(pr$p))+sum(ct$u1*log(pi)+ct$u0*log1p(-pi))
  list(kernel=kernel,score=score,information=information,efficient=1/solve(information)[1,1])
}

# Factual counts from Liang et al.arXiv2304.00162v2, Table26.
# Common-RD estimates/intervals below refer to Tables28/29, not its df2 homogeneity tests.
ome <- data.frame(stratum=rep(c("under2","age2to5","age6plus"),each=2),
  group=rep(c("Amoxicillin","Cefaclor"),3),
  m0=c(11,8,3,6,1,0),m1=c(2,2,1,6,0,1),m2=c(2,8,5,10,6,3),
  u0=c(10,9,22,7,7,8),u1=c(2,3,14,24,11,11))
dat <- strat_data(ome,reference="Amoxicillin")
fits <- list()
for(model in c("yule","dallal","rosner","donner")) {
  a <- switch(model,yule=-.3,dallal=.2,rosner=.75,donner=-.2)
  p <- strat_probabilities(c(.3,.35),a,model)
  close(as.matrix(p[c("p0","p1","p2")]),native(c(.3,.35),rep(a,2),model)$p,1e-11)
  fit <- strat_fit(dat,model=model); fits[[model]] <- fit
  stopifnot(fit$convergence$regular,fit$model==model,inherits(fit,"strat_fit"))
  k <- raw_information(fit)
  close(fit$logLik_kernel,k$kernel,1e-8)
  close(fit$score,k$score,1e-5)
  close(fit$information,k$information,1e-5)
  close(fit$efficient_information,k$efficient,1e-7)
  close(vcov(fit),solve(k$information),1e-7)
  d0 <- .1
  null <- strat_fit(dat,d=d0,model=model); kn <- raw_information(null)
  for(method in c("LR","score","Wald")) {
    expected <- switch(method,LR=2*(k$kernel-kn$kernel),score=kn$score[1]^2/kn$efficient,
      Wald=(fit$d-d0)^2*k$efficient)
    close(unname(strat_test(fit,d0,method)$statistic),unname(expected),1e-6)
  }
  swapped <- strat_fit(strat_data(ome,reference="Cefaclor"),model=model)
  close(swapped$d,-fit$d,2e-6)
  close(as.numeric(logLik(swapped)),as.numeric(logLik(fit)),2e-6)
  close(strat_test(swapped,-d0,"score")$statistic,strat_test(fit,d0,"score")$statistic,1e-5)
  fails(strat_test(null)); fails(strat_confint(null))
  bad <- dat; bad$counts$m0[1] <- -.5
  fails(strat_fit(bad,model=model))
}

df <- fits$dallal
close(df$d,.1742,8e-5)
close(unname(df$baseline),c(.2105,.4823,.5682),8e-5)
close(unname(df$association),c(.8104,.8208,.9120),8e-5)
for(method in c("LR","score","Wald")) {
  ci <- strat_confint(df,method=method)
  stopifnot(all(is.finite(ci$intervals)),nrow(ci$intervals)==1L,
    is.logical(ci$complete),length(ci$complete)==1L)
  if(!ci$complete)stopifnot(length(ci$diagnostics$messages)>0L)
  target <- switch(method,LR=c(.0502,.2953),score=c(.0486,.2954),Wald=c(.0526,.2957))
  close(as.numeric(ci$intervals),target,2e-4)
  for(endpoint in as.vector(ci$intervals))
    close(unname(strat_test(df,endpoint,method)$statistic),qchisq(.95,1),5e-4)
  stopifnot(strat_test(df,df$d,method)$p.value>.99,
    strat_test(df,min(ci$intervals)-.002,method)$p.value<.05,
    strat_test(df,max(ci$intervals)+.002,method)$p.value<.05)
}

# Shared cache environments must never reuse a different model's null fit.
shared <- attr(fits$dallal,".yule_cache",exact=TRUE)
invisible(strat_test(fits$dallal,.1,"LR"))
reference_stat <- strat_test(fits$rosner,.1,"score")$statistic
copy <- fits$rosner; attr(copy,".yule_cache") <- shared
close(strat_test(copy,.1,"score")$statistic,reference_stat,1e-10)
close(strat_test(fits$dallal,.1,"score")$statistic,
  raw_information(strat_fit(dat,d=.1,model="dallal"))$score[1]^2/
    raw_information(strat_fit(dat,d=.1,model="dallal"))$efficient,1e-6)

# Missing bilateral information must omit unidentifiable association coordinates.
uni <- ome; uni[c("m0","m1","m2")] <- 0
uni$u0 <- c(40,38,30,25,28,22); uni$u1 <- c(12,14,20,25,30,36)
for(model in c("yule","dallal","rosner","donner")) {
  fit <- strat_fit(strat_data(uni,reference="Amoxicillin"),model=model)
  stopifnot(fit$convergence$regular,all(is.na(fit$association)),length(coef(fit))==4L)
  close(fit$d,strat_fit(strat_data(uni,reference="Amoxicillin"),model="yule")$d,1e-7)
  stopifnot(is.finite(strat_test(fit,0,"score")$statistic))
}
fails(strat_probabilities(.8,.4,"dallal"))
fails(strat_probabilities(.8,2,"rosner"))
fails(strat_probabilities(.1,-.5,"donner"))
close(strat_probabilities(.3,-.25,"donner")$q,.0375,1e-14)
fails(strat_fit(dat,model="unknown"))

# A seeded simulator preserves the caller's RNG state and the original Yule API.
set.seed(20261002);before <- .Random.seed
z <- strat_simulate(c(.2,.4),.05,c(-.1,.3),100,20,seed=613,model="yule")
stopifnot(identical(.Random.seed,before),identical(z,yule_simulate(c(.2,.4),.05,c(-.1,.3),100,20,seed=613)))
