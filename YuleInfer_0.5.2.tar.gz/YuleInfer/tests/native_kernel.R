library(YuleInfer)
internal <- function(name) getFromNamespace(name, "YuleInfer")
data <- data.frame(stratum = rep(1:3, each = 2L), group = rep(1:2, 3L),
                   m0 = c(28, 25, 19, 16, 12, 10),
                   m1 = c(13, 17, 18, 20, 15, 18),
                   m2 = c(9, 8, 13, 14, 23, 22),
                   u0 = c(8, 7, 6, 5, 4, 3), u1 = c(2, 3, 4, 5, 6, 7))
data <- internal(".as_yule_data")(data)
counts <- internal(".yule_fit_counts")(data)
counts$m <- cbind(counts$m0, counts$m1, counts$m2)

compare <- function(x, active, model, fixed, counts) {
  if (model == "yule") {
    reference <- internal(".yule_evaluate_R")(x, data, active, fixed, counts)
    native <- internal(".yule_evaluate")(x, data, active, fixed, counts)
  } else {
    reference <- internal(".classical_evaluate_R")(x, data, active, model, fixed, counts)
    native <- internal(".classical_evaluate")(x, data, active, model, fixed, counts)
  }
  stopifnot(identical(reference$invalid, native$invalid),
            isTRUE(all.equal(reference, native, tolerance = 2e-12)))
  invisible(list(reference = reference, native = native))
}

# Includes equal and half margins, inactive strata, signed associations,
# named parameters, fixed RD and integer-valued native count vectors.
for (model in c("yule", "dallal", "rosner", "donner")) {
  for (active in list(1:3, c(1L, 3L), integer())) {
    for (fixed in list(NULL, 0, .25, -.25)) {
      for (offset in c(0, 1, -1, 6, -6)) {
        x <- c(if (is.null(fixed)) .2 * offset,
               c(-.5, 0, .5) + offset, rep(offset, length(active)))
        names(x) <- paste0("parameter", seq_along(x))
        compare(x, active, model, fixed, counts)
      }
      x <- c(if (is.null(fixed)) .1, -.5, 0, .5, rep(-1, length(active)))
      integer_counts <- counts
      for (key in c("m0", "m1", "m2", "u0", "u1", "n_bilateral",
                    "n_unilateral", "positive"))
        integer_counts[[key]] <- as.integer(integer_counts[[key]])
      compare(x, active, model, fixed, integer_counts)
    }
  }
}

# A Windows vector-sqrt versus scalar-builtin regression coordinate. Earlier
# intermediates agree exactly; the platform sqrt must retain that agreement.
x <- c(-0.37560142390429974, 11.80911071598529816, 1.84105487354099751,
       1.96543963439762592, 8.90037528052926064, 4.58890997059643269,
       11.81527403555810452)
result <- compare(x, 1:3, "yule", NULL, counts)
if (.Platform$OS.type == "windows")
  stopifnot(identical(result$reference$probability, result$native$probability))
compare(x, 1:3, "yule", NULL, NULL) # Full probability derivatives.

# Extreme coordinates return the same invalid sentinel without named gradients.
for (model in c("yule", "dallal", "rosner", "donner")) {
  x <- setNames(rep(1000, 7L), paste0("parameter", 1:7))
  compare(x, 1:3, model, NULL, counts)
}

# The entry guards also protect researchers who call an internal routine
# directly. Public count/model validation remains in the R interface.
call <- internal("C_strat_evaluate")
bad <- function(...) inherits(try(.Call(call, ...), silent = TRUE), "try-error")
x <- c(.1, -.5, 0, .5, -1, 0, 1)
stopifnot(bad(x, 0L, 1:3, 0L, NULL, counts, TRUE),
          bad(x, 3L, c(1L, 1L, 3L), 0L, NULL, counts, TRUE),
          bad(x, 3L, c(1L, 2L, 4L), 0L, NULL, counts, TRUE),
          bad(x, 3L, 1:3, 4L, NULL, counts, TRUE),
          bad(x[-1], 3L, 1:3, 0L, NULL, counts, TRUE),
          bad(x, 3L, 1:3, 0L, NULL, unname(counts), TRUE),
          bad(x, 3L, 1:3, 0L, NULL, counts, NA),
          bad(x[-1], 3L, 1:3, 0L, 1, counts, TRUE))
