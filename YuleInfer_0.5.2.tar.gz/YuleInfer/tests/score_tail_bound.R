library(YuleInfer)
ns <- asNamespace('YuleInfer')
tail_bound <- get('.yule_ci_tail_bound', ns)
bound_value <- get('.yule_ci_bound_value', ns)
critical <- qchisq(.95, 1)

# A deterministic-margin data configuration has no evidence to exclude its
# matching tail. The opposite tail still has a valid rejection certificate.
extreme_counts <- data.frame(n_bilateral = c(20,20), n_unilateral = c(10,10),
  m0 = c(20,0), m1 = c(0,0), m2 = c(0,20), u0 = c(10,0), u1 = c(0,10))
object <- list(model = 'dallal', data = list(counts = extreme_counts))
bound <- tail_bound(object, 'score', critical)
stopifnot(bound$range[2] == 1, bound$tail_radius['positive'] == 0,
  bound_value(bound, .99999) == 0, bound_value(bound, -.99999) > critical,
  bound_value(bound, .5) == 0)

# Real mixed data: certify both tails, then verify against independently
# fitted public score tests. Neither the critical roots nor the accepted
# confidence-set component may use the analytic lower bound as a statistic.
counts <- yule_simulate(c(.10,.20,.30), .30, c(.50,.60,.70),
  n_bilateral = 200, n_unilateral = 50, seed = 2026100309)
for (model in c('dallal','rosner','donner')) {
  fit <- strat_fit(counts, model = model)
  stopifnot(fit$convergence$regular)
  bound <- tail_bound(fit, 'score', critical)
  stopifnot(bound$type == 'Classical efficient score',
    all(bound$tail_radius > 0 & bound$tail_radius < 1/6),
    all(vapply(bound$range, function(d)
      abs(bound_value(bound,d) - critical) < 1e-9, logical(1))))
  for (d in c(-.95,-.9,.9,.95)) {
    stat <- unname(strat_test(fit,d0=d,method='score')$statistic)
    stopifnot(is.finite(stat), bound_value(bound,d) <= stat + 1e-6)
  }
  ci <- strat_confint(fit, method = 'score')
  stopifnot(ci$complete, ci$connected, nrow(ci$intervals) == 1L,
    all(is.finite(ci$intervals)),
    ci$intervals[1,1] < fit$d, ci$intervals[1,2] > fit$d,
    identical(ci$diagnostics$certified_tail_bound$type, 'Classical efficient score'))
  for (d in as.numeric(ci$intervals))
    stopifnot(abs(unname(strat_test(fit,d0=d,method='score')$statistic) - critical) < 1e-3)
  grid <- ci$diagnostics$grid
  stopifnot(all(grid$status[which(grid$accepted)] == 'ok'))
  # Reversing group order must reverse the two certificate ranges exactly.
  swapped <- fit
  swapped$data$counts <- fit$data$counts[as.vector(rbind(seq(2,6,2),seq(1,5,2))),]
  other <- tail_bound(swapped, 'score', critical)
  stopifnot(max(abs(other$range + rev(bound$range))) < 1e-14)
}

# Confidence levels change only the certified cutoff, in the correct order.
low <- tail_bound(fit, 'score', qchisq(.90,1))
high <- tail_bound(fit, 'score', qchisq(.99,1))
stopifnot(high$range[1] < low$range[1], high$range[2] > low$range[2])

# Bounds retain unilateral data and work when no association is identifiable.
unilateral <- data.frame(stratum = rep(c('a','b'), each=2), group=rep(c('1','2'),2),
  m0=0, m1=0, m2=0, u0=c(75,50,65,40), u1=c(25,50,35,60))
fit <- strat_fit(unilateral, model='rosner')
ci <- strat_confint(fit, method='score')
stopifnot(fit$convergence$regular, ci$complete,
  all(is.finite(ci$intervals)), ci$intervals[1,1] < fit$d, ci$intervals[1,2] > fit$d)
cat('Classical score tail bounds, inversion, group symmetry and unilateral checks passed.\n')
