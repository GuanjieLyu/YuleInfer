library(YuleInfer)

# Exercise the real confidence-set search against profiles with independently
# known geometry. A child environment isolates mock profile evaluations;
# package namespace bindings and installed function environments are unchanged.
namespace <- asNamespace("YuleInfer")
original_confint <- get("yule_confint", envir = namespace)
original_profile <- get(".yule_profile_statistic", envir = namespace)
sandbox <- new.env(parent = namespace)
invert <- original_confint
environment(invert) <- sandbox
sandbox$.yule_ci_tail_bound <- function(object, method, critical) NULL

object <- structure(list(data = list(), d = 0, fixed = FALSE, logLik = 0,
                         efficient_information = 100, se = .1, controls = list(),
                         convergence = list(ok = TRUE, regular = TRUE, reason = "")),
                    class = "yule_fit")

profile_value <- function(d) 800 * d^2 * (d - .6)^2
sandbox$.yule_profile_statistic <- function(object, d0, method, start = object,
                                           fit.control = NULL, strict = TRUE) {
  list(statistic = profile_value(d0),
       fit = list(convergence = list(ok = TRUE)), message = "")
}

# T(d) <= c has two disjoint components with four analytic endpoints.
critical <- qchisq(.95, df = 1)
radius <- sqrt(critical / 800)
expected <- matrix(c(.3 - sqrt(.09 + radius), .3 - sqrt(.09 - radius),
                     .3 + sqrt(.09 - radius), .3 + sqrt(.09 + radius)),
                   nrow = 2L, byrow = TRUE)
for (method in c("LR", "score")) {
  result <- invert(object, method = method)
  stopifnot(result$complete, identical(result$connected, FALSE),
            identical(dim(result$intervals), c(2L, 2L)),
            max(abs(result$intervals - expected)) < 1e-5,
            max(abs(profile_value(result$intervals) - critical)) < 1e-4,
            result$diagnostics$evaluations <= 300L)
}

# An unresolved region removes the inner endpoints. The implementation must
# retain the known portions separately and must not bridge the failed region.
sandbox$.yule_profile_statistic <- function(object, d0, method, start = object,
                                           fit.control = NULL, strict = TRUE) {
  if (d0 > .14 && d0 < .48)
    return(list(statistic = NA_real_, fit = NULL,
                message = "Deliberate remote constrained-fit failure."))
  list(statistic = profile_value(d0),
       fit = list(convergence = list(ok = TRUE)), message = "")
}
unresolved <- invert(object)
stopifnot(!unresolved$complete, is.na(unresolved$connected),
          identical(dim(unresolved$intervals), c(2L, 2L)),
          is.na(unresolved$intervals[1L, "upper"]),
          is.na(unresolved$intervals[2L, "lower"]),
          abs(unresolved$intervals[1L, "lower"] - expected[1L, 1L]) < 1e-5,
          abs(unresolved$intervals[2L, "upper"] - expected[2L, 2L]) < 1e-5,
          anyNA(unresolved$diagnostics$grid$accepted),
          nrow(unresolved$diagnostics$failed) > 0L,
          unresolved$diagnostics$evaluations <= 300L)

# The user-selected budget is respected, with an explicit incomplete result.
sandbox$.yule_profile_statistic <- function(object, d0, method, start = object,
                                           fit.control = NULL, strict = TRUE) {
  list(statistic = profile_value(d0),
       fit = list(convergence = list(ok = TRUE)), message = "")
}
limited <- invert(object, control = list(max.evaluations = 25L))
stopifnot(!limited$complete, limited$diagnostics$evaluations == 25L,
          anyNA(limited$diagnostics$grid$accepted),
          any(grepl("budget", limited$diagnostics$messages, ignore.case = TRUE)))

stopifnot(identical(get("yule_confint", envir = namespace), original_confint),
          identical(environment(original_confint), namespace),
          identical(get(".yule_profile_statistic", envir = namespace), original_profile))
cat("Disconnected confidence-set, unresolved-region, and budget audits passed.\n")
