library(YuleInfer)

must_error <- function(expr, pattern) {
  error <- tryCatch({force(expr); NULL}, error = identity)
  stopifnot(inherits(error, "error"), grepl(pattern, conditionMessage(error), fixed = TRUE))
}

# Include every count category, both discordant bilateral orientations, and
# unilateral observations in either outcome column.
subjects <- data.frame(
  subject = paste0("p", 1:18),
  site = c(rep("South", 10), rep("North", 8)),
  arm = c(rep("Tx", 5), rep("Control", 5), rep("Tx", 4), rep("Control", 4)),
  left = c(0,0,1,NA,1, 0,1,1,0,NA, 0,1,NA,1, 0,0,NA,1),
  right = c(0,1,1,0,NA, 0,0,1,NA,1, 1,1,0,NA, 0,1,1,NA)
)
manual <- data.frame(stratum = rep(c("South", "North"), each = 2),
  group = rep(c("Tx", "Control"), 2),
  m0 = c(1L,1L,0L,1L), m1 = c(1L,1L,1L,1L), m2 = c(1L,1L,1L,0L),
  u0 = c(1L,1L,1L,0L), u1 = c(1L,1L,1L,2L))
import <- function(data = subjects, reference = "Control", id = "subject")
  yule_import(data, "arm", c("left", "right"), "site", reference, id)
actual <- import()
expected <- strat_data(manual, reference = "Control")
stopifnot(identical(actual, expected), actual$N == nrow(subjects),
          identical(actual$strata, c("South", "North")),
          identical(actual$groups, c("Control", "Tx")))
stopifnot(identical(import(id = NULL), expected),
          identical(import(reference = NULL)$reference, "Tx"),
          identical(yule_import(subjects, "arm", c("right", "left"), "site", "Control", "subject"), expected))

# Group order comes from observed rows, not alphabetical order or factor levels.
factored <- subjects
factored$arm <- factor(factored$arm, levels = c("unused", "Control", "Tx"))
factored$site <- factor(factored$site, levels = c("North", "South", "unused"))
stopifnot(identical(import(factored), expected),
          identical(import(factored, reference = NULL)$reference, "Tx"))
reordered <- subjects[c(6:10, 1:5, 15:18, 11:14), ]
stopifnot(identical(import(reordered), expected),
          identical(import(reordered, reference = NULL)$reference, "Control"))
logical_data <- subjects
logical_data$left <- as.logical(logical_data$left)
logical_data$right <- as.logical(logical_data$right)
stopifnot(identical(import(logical_data), expected))

# One outcome creates a single stratum with unilateral counts and can be fitted.
single <- data.frame(arm = c(rep("A", 6), rep("B", 8)),
  response = c(0,0,0,1,1,1, 0,0,0,1,1,1,1,1))
unilateral <- yule_import(single, "arm", "response", reference = "A")
single_counts <- data.frame(stratum = c("1", "1"), group = c("A", "B"),
  m0 = 0L, m1 = 0L, m2 = 0L, u0 = c(3L,3L), u1 = c(3L,5L))
stopifnot(identical(unilateral, strat_data(single_counts, reference = "A")), unilateral$N == 14)
single$unobserved <- NA_real_
stopifnot(identical(yule_import(single, "arm", c("response", "unobserved"), reference = "A"), unilateral))
for (model in c("yule", "dallal", "rosner", "donner")) {
  fit <- strat_fit(unilateral, model = model)
  stopifnot(isTRUE(fit$convergence$regular), abs(fit$d - .125) < 1e-6)
}

# Numeric labels and non-syntactic column names are supported without guessing.
renamed <- subjects
names(renamed)[names(renamed) == "left"] <- "left response"
renamed$arm <- ifelse(renamed$arm == "Control", 0, 1)
numeric_group <- yule_import(renamed, "arm", c("left response", "right"), "site", 0, "subject")
stopifnot(identical(numeric_group$groups, c("0", "1")),
          identical(numeric_group$counts[, c("m0","m1","m2","u0","u1")],
                    expected$counts[, c("m0","m1","m2","u0","u1")]))

must_error(yule_import(matrix(0, 2, 2), "arm", "left"), "nonempty data frame")
must_error(import(subjects[FALSE, ]), "nonempty data frame")
duplicate_names <- subjects; names(duplicate_names)[2] <- "arm"
must_error(import(duplicate_names), "Column names")
must_error(yule_import(subjects, 1, "left"), "one column name")
must_error(yule_import(subjects, c("arm", "site"), "left"), "one column name")
must_error(yule_import(subjects, "missing", "left"), "Unknown column")
must_error(yule_import(subjects, "arm", character()), "one or two distinct column names")
must_error(yule_import(subjects, "arm", c("left", "right", "site")), "one or two distinct column names")
must_error(yule_import(subjects, "arm", c("left", "left")), "one or two distinct column names")
must_error(yule_import(subjects, "arm", c("left", NA_character_)), "one or two distinct column names")
must_error(yule_import(subjects, "arm", "left", id = "arm"), "must be distinct")
must_error(yule_import(subjects, "arm", "left", stratum = "absent"), "Unknown column")
must_error(import(reference = "absent"), "one observed treatment group")
must_error(import(reference = c("Control", "Tx")), "one observed treatment group")
must_error(import(reference = NA_character_), "one observed treatment group")

bad <- subjects; bad$left <- as.character(bad$left)
must_error(import(bad), "recode factors and text explicitly")
bad <- subjects; bad$left <- factor(bad$left)
must_error(import(bad), "recode factors and text explicitly")
bad <- subjects; bad$left[1] <- 2
must_error(import(bad), "other than 0, 1, or NA")
bad <- subjects; bad$right[1] <- Inf
must_error(import(bad), "other than 0, 1, or NA")
bad <- subjects; bad$left <- I(matrix(bad$left, ncol = 1))
must_error(import(bad), "must be numeric 0/1 or logical")
bad <- subjects; bad$left <- as.complex(bad$left)
must_error(import(bad), "must be numeric 0/1 or logical")
bad <- subjects; bad$left[1] <- bad$right[1] <- NA_real_
must_error(import(bad), "No observed outcomes in row(s): 1")
must_error(yule_import(subjects, "arm", "left"), "No rows were dropped")

bad <- subjects; bad$arm[1] <- NA_character_
must_error(import(bad), "nonmissing")
bad <- subjects; bad$site[1] <- "  "
must_error(import(bad), "nonempty")
bad <- subjects; bad$arm <- as.list(bad$arm)
must_error(import(bad), "vector of subject labels")
bad <- subjects; bad$arm[1] <- "Third"
must_error(import(bad), "Exactly two observed treatment groups")
must_error(import(subjects[subjects$arm == "Control", ]), "Exactly two observed treatment groups")
must_error(import(subjects[!(subjects$site == "North" & subjects$arm == "Control"), ]),
           "Each stratum must contain subjects from both")
bad <- subjects; bad$subject[11] <- bad$subject[1]
must_error(import(bad), "unique") # ID duplicates across strata still identify the same subject.
bad <- subjects; bad$subject[2] <- NA_character_
must_error(import(bad), "nonmissing")
bad <- subjects; bad$subject[2] <- ""
must_error(import(bad), "nonempty")

cat("Individual-subject import tests passed.\n")
