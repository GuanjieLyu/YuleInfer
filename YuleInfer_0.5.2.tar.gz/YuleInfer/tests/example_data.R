library(YuleInfer)
data(paired_trial)
prepared <- yule_import(paired_trial, group = "group", outcomes = c("left", "right"),
                       stratum = "centre", reference = "control", id = "id")
stopifnot(prepared$N == 500L, prepared$J == 2L,
          all(prepared$counts$n_bilateral == 100),
          all(prepared$counts$n_unilateral == 25),
          identical(prepared$counts$m0, c(70L, 60L, 55L, 48L)),
          identical(prepared$counts$m1, c(20L, 25L, 28L, 30L)))
fit <- strat_fit(prepared)
stopifnot(isTRUE(fit$convergence$regular))
cat("Installed synthetic example data and importer checks passed.\n")
