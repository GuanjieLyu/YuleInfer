library(YuleInfer)

# Exercise the real default inversion with known profile geometry. The mock
# replaces only constrained fitting and analytic tail certification; neither
# the installed namespace nor its function environments are modified.
namespace <- asNamespace("YuleInfer")
original <- get("yule_confint", envir = namespace)
sandbox <- new.env(parent = namespace)
invert <- original
environment(invert) <- sandbox
sandbox$.yule_ci_tail_bound <- function(object, method, critical) NULL
calls <- new.env(parent = emptyenv())
calls$n <- 0L
sandbox$.yule_profile_statistic <- function(object, d0, method, start = object,
                                           fit.control = NULL, strict = TRUE,
                                           use.cache = FALSE) {
  calls$n <- calls$n + 1L
  # Unknown classical score tails reproduce the numerical-search situation
  # without expensive or platform-dependent optimization failures.
  if (method == "score" && object$model != "yule" && abs(d0) > .8)
    return(list(statistic = NA_real_, fit = NULL,
                message = "Deliberate nonregular constrained score tail."))
  list(statistic = 1000 * (d0 - object$d - object$data$shift)^2,
       fit = list(d = d0, model = object$model,
                  convergence = list(ok = TRUE, regular = TRUE, boundary = FALSE)),
       message = "")
}
make_fit <- function(model) {
  fit <- structure(list(model = model, data = list(shift = 0), d = .07,
                        baseline = .3, association = .2, fixed = FALSE,
                        logLik = 0, logLik_kernel = 0, se = 1 / sqrt(1000),
                        efficient_information = 1000,
                        controls = get(".yule_fit_control", namespace)(list()),
                        convergence = list(ok = TRUE, regular = TRUE,
                                           boundary = FALSE, reason = "Interior fit.")),
                   class = "yule_fit")
  attr(fit, ".yule_cache") <- new.env(parent = emptyenv())
  fit
}
without_cache <- function(fit) { attr(fit, ".yule_cache") <- NULL; fit }
critical <- qchisq(.95, 1)
expected <- .07 + c(-1, 1) * sqrt(critical / 1000)

for (model in c("yule", "dallal", "rosner", "donner")) {
  fit <- make_fit(model)
  before <- calls$n
  lr <- invert(fit, method = "LR")
  stopifnot(lr$complete, lr$connected, lr$model == model,
            max(abs(lr$intervals - expected)) < 1e-5,
            calls$n - before == lr$diagnostics$evaluations,
            identical(lr$diagnostics$settings$grid.length, 33L),
            identical(lr$diagnostics$settings$refinements, 1L),
            identical(lr$diagnostics$settings$root.tol, 1e-6),
            identical(lr$diagnostics$settings$boundary.eps, 1e-5),
            identical(lr$diagnostics$settings$max.evaluations, 300L),
            identical(lr$diagnostics$settings$fit.control, fit$controls),
            identical(lr$diagnostics$search_domain, c(-1 + 1e-5, 1 - 1e-5)),
            all(seq(-1 + 1e-5, 1 - 1e-5, length.out = 33L) %in%
                  lr$diagnostics$grid$d))
  before <- calls$n
  stopifnot(identical(lr, invert(fit, method = "LR")), calls$n == before)
  cold <- invert(without_cache(fit), method = "LR")
  stopifnot(identical(lr, cold), calls$n > before)

  before <- calls$n
  score <- invert(fit, method = "score")
  stopifnot(calls$n - before == score$diagnostics$evaluations,
            max(abs(score$intervals - expected)) < 1e-5)
  before <- calls$n
  again <- invert(fit, method = "score")
  stopifnot(identical(score, again))
  if (model == "yule") {
    stopifnot(score$complete, calls$n == before)
  } else {
    stopifnot(!score$complete, is.na(score$connected), calls$n > before,
              anyNA(score$diagnostics$grid$accepted),
              nrow(score$diagnostics$failed) > 0L,
              !any(vapply(attr(fit, ".yule_cache")$ci_entries,
                          function(z) z$key$method == "score", logical(1))))
  }
  # Incomplete score requests must not displace or corrupt a completed LR set.
  before <- calls$n
  stopifnot(identical(lr, invert(fit, method = "LR")), calls$n == before)
}

# A changed copy shares the environment but must not receive the original CI.
# The deliberately shifted profile has independently known new endpoints.
fit <- make_fit("yule")
lr <- invert(fit, method = "LR")
changed <- fit
changed$data$shift <- .02
before <- calls$n
shifted <- invert(changed, method = "LR")
stopifnot(calls$n > before,
          max(abs(shifted$intervals - (expected + .02))) < 1e-5,
          identical(shifted, invert(without_cache(changed), method = "LR")))
before <- calls$n
stopifnot(identical(lr, invert(fit, method = "LR")), calls$n == before)

# Default controls, requested level and requested root tolerance are all part
# of the retained snapshot; a changed request requires its own profile scan.
before <- calls$n
narrower <- invert(fit, level = .9, method = "LR")
stopifnot(calls$n > before,
          max(abs(narrower$intervals - (.07 + c(-1, 1) * sqrt(qchisq(.9, 1) / 1000)))) < 1e-5)
before <- calls$n
stopifnot(identical(narrower, invert(fit, level = .9, method = "LR")),
          calls$n == before)
before <- calls$n
other_tolerance <- invert(fit, method = "LR", control = list(root.tol = 2e-6))
stopifnot(calls$n > before, identical(other_tolerance$diagnostics$settings$root.tol, 2e-6))

# The inference guard still runs before a cached completed set can be returned.
nonregular <- fit
nonregular$convergence$regular <- FALSE
before <- calls$n
stopifnot(inherits(try(invert(nonregular, method = "LR"), silent = TRUE), "try-error"),
          calls$n == before, identical(get("yule_confint", namespace), original),
          identical(environment(original), namespace))
cat("Default-grid, completed/incomplete CI cache and mutation tests passed.\n")
