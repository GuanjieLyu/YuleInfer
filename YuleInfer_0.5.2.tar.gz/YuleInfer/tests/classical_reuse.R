library(YuleInfer)
internal <- function(name) getFromNamespace(name, "YuleInfer")
bounds <- internal(".classical_bounds")
decode <- internal(".classical_decode")
probability <- internal(".classical_probability")
components <- internal(".classical_components")
information <- internal(".classical_information")

# The compact optimizer path must retain the same columns, including the
# half-weight derivatives at equal margins and at pi = 1/2.
pi <- c(.2, .2, .5, .5, .3, .7, .65, .8)
for (model in c("dallal", "rosner", "donner")) {
  full <- bounds(pi, model)
  compact <- bounds(pi, model, compact = TRUE)
  stopifnot(identical(full$lower, compact$lower),
            identical(full$upper, compact$upper),
            identical(full$lower_derivative[, 1L], compact$lp1),
            identical(full$lower_derivative[, 2L], compact$lp2),
            identical(full$upper_derivative[, 1L], compact$hp1),
            identical(full$upper_derivative[, 2L], compact$hp2))
  no_derivatives <- bounds(pi, model, derivatives = FALSE)
  stopifnot(identical(no_derivatives, full[c("lower", "upper")]))
}

# Reusing components is an internal optimization, with exactly the same
# information matrix and stable efficient-information calculation.
pi <- c(.2, .25, .4, .45, .6, .65)
a <- list(dallal = c(.5, .65, .8), rosner = c(1.3, 1.35, 1.35),
          donner = c(.3, -.15, .2))
n <- c(250, 320, 280, 310, 350, 270)
u <- c(70, 40, 80, 55, 30, 95)
for (model in names(a)) {
  for (active in list(1:3, c(1L, 3L), integer())) {
    nn <- n
    inactive <- setdiff(1:3, active)
    if (length(inactive)) nn[as.vector(rbind(2L * inactive - 1L, 2L * inactive))] <- 0
    aa <- a[[model]]
    aa[inactive] <- NA_real_
    pr <- probability(pi, aa, active, model)
    parts <- components(pi, pr, nn, u, active)
    ordinary <- information(pi, aa, nn, u, active, as.character(1:3), model)
    reused <- information(pi, aa, nn, u, active, as.character(1:3), model,
                          probability = pr, components = parts)
    stopifnot(identical(ordinary, reused))
  }
  for (fixed in list(NULL, .05)) {
    x <- c(if (is.null(fixed)) atanh(.05), .1, -.2, .3)
    z <- decode(x, 3L, integer(), model, d = fixed)
    stopifnot(length(z$association) == 3L, all(is.na(z$association)),
              identical(z$ar, numeric()), identical(z$ab, numeric()),
              identical(z$ad, numeric()), identical(z$free, is.null(fixed)))
  }
}
