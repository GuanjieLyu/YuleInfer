library(YuleInfer)

namespace <- asNamespace("YuleInfer")
prepare <- get(".model_fit_context", namespace)
fit_model <- get(".model_fit", namespace)
invert <- get("yule_confint", namespace)
fresh <- function(fit) {
  attr(fit, ".yule_cache") <- new.env(parent = emptyenv())
  fit
}
inference_fields <- c("model", "data", "d", "baseline", "association", "logLik",
                      "logLik_kernel", "score", "information", "efficient_information",
                      "convergence", "fixed", "controls", "active_association")
dat <- yule_simulate(c(.2, .4, .6), 0, c(.2, .4, .6),
                     n_bilateral = 300, n_unilateral = 80, seed = 6103011)
for (model in c("yule", "dallal", "rosner", "donner")) {
  full <- strat_fit(dat, model = model)
  stopifnot(full$convergence$regular, is.data.frame(full$probabilities),
            is.numeric(full$coefficients), is.numeric(full$se),
            is.environment(attr(full, ".yule_cache")))
  context <- prepare(full$data, model, full$controls)
  for (d in c(-.06, 0, .06)) {
    ordinary <- fit_model(full$data, model, d = d, start = full, control = full$controls)
    compact <- fit_model(full$data, model, d = d, start = full, control = full$controls,
                         prepared = context, profile = TRUE)
    stopifnot(identical(ordinary[inference_fields], compact[inference_fields]),
              is.null(compact$probabilities), is.null(compact$coefficients),
              is.null(attr(compact, ".yule_cache")))
    # A compact successful profile is a valid next warm start. Match both
    # starts against the same public full result at a different signed null.
    next_d <- if (d <= 0) .03 else -.03
    ordinary_next <- fit_model(full$data, model, d = next_d, start = ordinary,
                              control = full$controls)
    compact_next <- fit_model(full$data, model, d = next_d, start = compact,
                             control = full$controls, prepared = context, profile = TRUE)
    stopifnot(identical(ordinary_next[inference_fields], compact_next[inference_fields]))
  }
  # Controls are prepared anew; a context from different controls is never
  # reused by inversion. This materially changes the required start count.
  changed <- full$controls
  changed$multistart <- FALSE
  changed$reltol <- 1e-9
  changed_context <- prepare(full$data, model, changed)
  ordinary <- fit_model(full$data, model, d = .02, start = full, control = changed)
  compact <- fit_model(full$data, model, d = .02, start = full, control = changed,
                       prepared = changed_context, profile = TRUE)
  stopifnot(identical(changed_context$controls, changed),
            identical(ordinary[inference_fields], compact[inference_fields]),
            compact$convergence$starts == 1L)
}

# Force preparation to return NULL in a child environment to exercise the
# ordinary full-profile path. This leaves every real fitting function and
# inference rule unchanged, and never modifies the installed namespace.
plain_environment <- new.env(parent = namespace)
plain_environment$.model_fit_context <- function(...) NULL
plain <- invert
environment(plain) <- plain_environment
cache_dat <- yule_simulate(c(.15, .35, .55), .07, c(-.3, .4, .7),
                           n_bilateral = 400, n_unilateral = 120, seed = 6102043)
for (model in c("yule", "dallal")) {
  method <- if (model == "yule") "LR" else "score"
  full <- strat_fit(cache_dat, model = model)
  stopifnot(full$convergence$regular)
  ordinary <- plain(fresh(full), method = method)
  compact <- invert(fresh(full), method = method)
  stopifnot(identical(ordinary, compact),
            isTRUE(compact$complete),
            identical(compact$diagnostics$settings$grid.length, 33L),
            identical(compact$diagnostics$settings$refinements, 1L))
  if (model == "dallal")
    stopifnot(identical(compact$diagnostics$certified_tail_bound$type,
                        "Classical efficient score"))
}

full <- strat_fit(cache_dat, model = "yule")
for (control in list(list(max.evaluations = 25L),
                     list(grid.length = 9L, refinements = 0L,
                          fit.control = list(unsupported = 1)))) {
  ordinary <- plain(fresh(full), method = "LR", control = control)
  compact <- invert(fresh(full), method = "LR", control = control)
  stopifnot(identical(ordinary, compact), !compact$complete,
            anyNA(compact$diagnostics$grid$accepted))
}
stopifnot(identical(get("yule_confint", namespace), invert),
          identical(environment(invert), namespace))
cat("Prepared full/compact profiles, warm starts, controls and CI geometry tests passed.\n")
