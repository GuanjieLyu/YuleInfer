library(YuleInfer)
data(otitis_media, package = "YuleInfer")

# Published Table 26: retain the exact six aggregate rows and treatment order.
expected <- data.frame(
  stratum = rep(c("age < 2", "age 2-5", "age >= 6"), each = 2),
  group = rep(c("Amoxicillin", "Cefaclor"), 3),
  m0 = c(11, 8, 3, 6, 1, 0), m1 = c(2, 2, 1, 6, 0, 1),
  m2 = c(2, 8, 5, 10, 6, 3), u0 = c(10, 9, 22, 7, 7, 8),
  u1 = c(2, 3, 14, 24, 11, 11)
)
stopifnot(identical(otitis_media, expected),
          identical(names(otitis_media), c("stratum", "group", "m0", "m1", "m2", "u0", "u1")))
dat <- strat_data(otitis_media, reference = "Amoxicillin")
stopifnot(dat$N == 203, dat$J == 3L,
          identical(dat$strata, c("age < 2", "age 2-5", "age >= 6")),
          identical(dat$groups, c("Amoxicillin", "Cefaclor")),
          identical(strat_data(otitis_media)$reference, "Amoxicillin"),
          sum(dat$counts$n_bilateral) == 75,
          sum(dat$counts$n_unilateral) == 128,
          sum(2 * dat$counts$n_bilateral + dat$counts$n_unilateral) == 278)
subjects_by_group <- tapply(dat$counts$n_bilateral + dat$counts$n_unilateral,
                            dat$counts$group, sum)
stopifnot(subjects_by_group[["Amoxicillin"]] == 97,
          subjects_by_group[["Cefaclor"]] == 106)
# The original report's fully effusion-free child totals provide another check.
fully_cured <- tapply(dat$counts$m2 + dat$counts$u1, dat$counts$group, sum)
stopifnot(fully_cured[["Amoxicillin"]] == 40, fully_cured[["Cefaclor"]] == 59)

# Reproduce the rounded published Dallal estimate with the declared direction.
fit <- strat_fit(dat, model = "dallal")
stopifnot(isTRUE(fit$convergence$regular), fit$d > 0,
          abs(fit$d - .1742) < 5e-5)
reversed <- strat_fit(strat_data(otitis_media, reference = "Cefaclor"), model = "dallal")
stopifnot(isTRUE(reversed$convergence$regular), reversed$d < 0,
          abs(fit$d + reversed$d) < 1e-6,
          abs(fit$logLik - reversed$logLik) < 1e-6)
cat("Published otitis media counts, totals and treatment direction passed.\n")
