library(YuleInfer)
ns <- asNamespace('YuleInfer')
invert <- get('yule_confint', ns)
sandbox <- new.env(parent = ns)
environment(invert) <- sandbox
sandbox$.yule_ci_tail_bound <- function(...) NULL
object <- structure(list(model='dallal', data=list(), d=0, fixed=FALSE,
  logLik=0, logLik_kernel=0, efficient_information=100, se=.1,
  controls=list(), convergence=list(ok=TRUE,regular=TRUE,reason='')), class='yule_fit')
calls <- 0L
mode <- 'retry'
sandbox$.yule_profile_statistic <- function(object, d0, method, start=object,
                                           fit.control=NULL, strict=TRUE) {
  calls <<- calls + 1L
  trouble <- d0 > .08 && d0 < .15
  boundary <- trouble && mode == 'boundary'
  failure <- boundary || (trouble && !identical(start,object))
  fit <- list(logLik_kernel=-50*d0^2,
    convergence=list(ok=!failure || boundary, regular=!failure,
      boundary=boundary, status=if(boundary)'boundary' else if(failure)'not_converged' else 'converged'))
  list(statistic=if(failure)NA_real_ else 100*d0^2, fit=fit,
    message=if(failure)'Deliberate profile failure.' else '')
}
result <- invert(object,method='score')
stopifnot(result$complete, result$connected,
  max(abs(as.numeric(result$intervals)-c(-1,1)*sqrt(qchisq(.95,1)/100))) < 1e-5,
  nrow(result$diagnostics$profile_retries) > 0,
  all(result$diagnostics$profile_retries$recovered),
  calls == result$diagnostics$evaluations)

# Retry attempts respect the same budget as original profile attempts.
calls <- 0L
limited <- invert(object,method='score',control=list(max.evaluations=25L))
stopifnot(!limited$complete,calls == 25L,limited$diagnostics$evaluations == 25L)

# A genuine boundary does not receive a retry or become an accepted point.
mode <- 'boundary'; calls <- 0L
unresolved <- invert(object,method='score')
stopifnot(!unresolved$complete, is.null(unresolved$diagnostics$profile_retries),
  anyNA(unresolved$diagnostics$grid$accepted),nrow(unresolved$diagnostics$failed)>0,
  calls == unresolved$diagnostics$evaluations)

# Frozen regression: the old nearby-profile start narrowly missed stationarity
# far from the central component. All observations, including zeros, are kept.
counts <- data.frame(stratum=rep(1:3,each=2),group=rep(c('1','2'),3),
  m0=c(41,10,36,9,42,10),m1=c(39,64,43,62,38,60),m2=c(0,6,1,9,0,10),
  u0=c(14,14,16,10,15,12),u1=c(6,6,4,10,5,8))
fit <- strat_fit(counts,model='dallal')
ci <- strat_confint(fit,method='score')
stopifnot(ci$complete,ci$connected,
  max(abs(as.numeric(ci$intervals)-c(.1596521,.2401204))) < 2e-6)
if (!is.null(ci$diagnostics$profile_retries))
  stopifnot(all(ci$diagnostics$profile_retries$recovered))
cat('Classical score retries, budget accounting and boundary safeguards passed.\n')
