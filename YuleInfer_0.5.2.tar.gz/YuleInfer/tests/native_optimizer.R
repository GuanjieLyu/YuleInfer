library(YuleInfer)

# R exposes the BFGS routine used by stats::optim through its documented C
# interface. Check the bridge against the original R callback path, including
# optimizer counts and the consecutive-point likelihood cache, not just MLEs.
ns <- asNamespace("YuleInfer")
native_optimizer <- get("C_strat_optim", ns)
native_evaluator <- get("C_strat_evaluate", ns)
prepare_counts <- get(".yule_fit_counts", ns)
model_ids <- c(yule = 0L, dallal = 1L, rosner = 2L, donner = 3L)

new_state <- function() {
  state <- new.env(parent = emptyenv())
  state$last <- NULL
  state$val <- NULL
  state$compact <- FALSE
  state$evaluations <- 0L
  state
}

make_case <- function(model, n = c(40, 40, 40), u = c(10, 10, 10),
                      fixed = NULL, named = FALSE, seed = 6104201L) {
  J <- length(n)
  data <- yule_data(yule_simulate(
    baseline = c(.18, .38, .60)[seq_len(J)], d = .04,
    association = c(.2, -.25, .5)[seq_len(J)],
    n_bilateral = matrix(rep(n, 2L), J, 2L),
    n_unilateral = matrix(rep(u, 2L), J, 2L), seed = seed))
  counts <- prepare_counts(data)
  counts$m <- cbind(counts$m0, counts$m1, counts$m2)
  active <- which(counts$n_bilateral[counts$odd] +
                    counts$n_bilateral[counts$even] > 0)
  d <- if (is.null(fixed)) .02 else fixed
  b <- c(.22, .37, .52)[seq_len(J)]
  association <- rep(switch(model, yule = .3, dallal = .65,
                             rosner = 1.2, donner = .2), J)
  association[setdiff(seq_len(J), active)] <- NA_real_
  x <- if (model == "yule")
    get(".yule_encode", ns)(d, b, association, active, fixed) else
    get(".classical_encode", ns)(d, b, association, active, model, fixed)
  if (named) names(x) <- paste0("coordinate", seq_along(x))
  list(x = x, J = as.integer(J), active = active,
       model = unname(model_ids[model]), fixed = fixed, counts = counts)
}

evaluate_reference <- function(x, case, state) {
  if (is.null(state$last) || !identical(x, state$last)) {
    state$val <- .Call(native_evaluator, x, case$J, case$active,
                      case$model, case$fixed, case$counts, case$model != 0L)
    state$last <- x
    state$evaluations <- state$evaluations + 1L
    state$compact <- FALSE
  }
  state$val
}

reference_optim <- function(x, case, state, maxit, reltol) {
  stats::optim(x, function(x) evaluate_reference(x, case, state)$value,
               function(x) evaluate_reference(x, case, state)$gradient,
               method = "BFGS", control = list(maxit = maxit, reltol = reltol))
}

bridge_optim <- function(x, case, state, maxit, reltol) {
  .Call(native_optimizer, x, case$J, case$active, case$model, case$fixed,
        case$counts, maxit, reltol, state)
}

compare_call <- function(x, case, native_state, reference_state,
                         maxit = 1000L, reltol = 1e-10) {
  original <- x
  reference <- reference_optim(x, case, reference_state, maxit, reltol)
  native <- bridge_optim(x, case, native_state, maxit, reltol)
  fields <- c("par", "value", "counts", "convergence", "message")
  stopifnot(identical(original, x),
            identical(native[fields], reference[fields]),
            identical(native_state$last, reference_state$last),
            identical(native_state$evaluations, reference_state$evaluations),
            identical(native_state$val[c("value", "gradient", "invalid")],
                      reference_state$val[c("value", "gradient", "invalid")]))
  invisible(native)
}

# Each model is exercised with free/fixed signed RD, unnamed/named coordinates,
# an inactive association stratum and a fully unilateral dataset. Continuing
# from the same state also checks the cache carried between optimizer starts.
cases_checked <- 0L
for (model in names(model_ids)) {
  cases <- list(
    make_case(model),
    make_case(model, fixed = -.04, named = TRUE),
    make_case(model, n = c(40, 0, 40), named = TRUE),
    make_case(model, n = c(0, 0, 0), fixed = .04),
    make_case(model, n = 3, u = 1, fixed = -.04, named = TRUE,
              seed = 6104202L))
  for (case in cases) {
    native_state <- new_state()
    reference_state <- new_state()
    compare_call(case$x, case, native_state, reference_state)
    # A second start preserves the previous evaluator state. A deliberately
    # tiny iteration budget also exercises nonconvergence without fallback.
    changed <- case$x
    changed[length(changed)] <- changed[length(changed)] + .05
    compare_call(changed, case, native_state, reference_state, maxit = 1L)
    cases_checked <- cases_checked + 1L
  }
}

# A prepopulated full cache is accepted; changing only coordinate names must
# invalidate it exactly as identical() does in the R reference.
case <- make_case("yule", fixed = .02, named = TRUE)
native_state <- new_state()
reference_state <- new_state()
invisible(evaluate_reference(case$x, case, native_state))
invisible(evaluate_reference(case$x, case, reference_state))
compare_call(case$x, case, native_state, reference_state, maxit = 1L)
renamed <- case$x
names(renamed) <- paste0("changed", seq_along(renamed))
compare_call(renamed, case, native_state, reference_state, maxit = 1L)

# Malformed direct calls must raise R errors, not reach vmmin with incompatible
# buffers or quietly bypass the native evaluator's dimensional checks.
valid_arguments <- list(case$x, case$J, case$active, case$model, case$fixed,
                         case$counts, 20L, 1e-10, new_state())
bad <- function(position, value) {
  args <- valid_arguments
  args[position] <- list(value)
  result <- try(do.call(.Call, c(list(native_optimizer), args)), silent = TRUE)
  inherits(result, "try-error")
}
bad_counts <- case$counts
bad_counts$m0 <- 1
stopifnot(bad(1L, "invalid"), bad(1L, case$x[-1L]),
          bad(2L, 0L), bad(2L, NA_integer_),
          bad(3L, c(1L, 1L)), bad(3L, case$J + 1L),
          bad(4L, 4L), bad(5L, 1), bad(5L, NA_real_),
          bad(6L, bad_counts), bad(7L, 0L), bad(7L, 1.5),
          bad(8L, 0), bad(8L, NA_real_), bad(9L, list()))
for (field in c("last", "val", "compact", "evaluations")) {
  missing <- new_state()
  rm(list = field, envir = missing)
  stopifnot(bad(9L, missing))
}
for (value in list(NA_integer_, -1L, 0, numeric())) {
  malformed <- new_state()
  malformed$evaluations <- value
  stopifnot(bad(9L, malformed))
}
malformed <- new_state()
malformed$compact <- NA
stopifnot(bad(9L, malformed))
malformed <- new_state()
malformed$last <- case$x
malformed$val <- list(value = 1, gradient = numeric(), invalid = FALSE)
stopifnot(bad(9L, malformed))
locked <- new_state()
lockEnvironment(locked)
stopifnot(bad(9L, locked))
locked_binding <- new_state()
lockBinding("evaluations", locked_binding)
stopifnot(bad(9L, locked_binding))
active_binding <- new_state()
rm("evaluations", envir = active_binding)
binding_calls <- 0L
makeActiveBinding("evaluations", function(value) {
  binding_calls <<- binding_calls + 1L
  stop("A native optimizer must not evaluate active state bindings.")
}, active_binding)
stopifnot(bad(9L, active_binding), identical(binding_calls, 0L))

# Force frequent collection around native callback results and the retained
# cache. Keep the workload small enough for routine package checks.
check_gc <- function() {
  case <- make_case("donner", n = 8, u = 2, fixed = .02, named = TRUE)
  native_state <- new_state()
  reference_state <- new_state()
  reference <- reference_optim(case$x, case, reference_state, 1L, 1e-10)
  gc()
  gctorture(TRUE)
  on.exit(gctorture(FALSE), add = TRUE)
  native <- bridge_optim(case$x, case, native_state, 1L, 1e-10)
  stopifnot(identical(native, reference),
            identical(native_state$last, reference_state$last),
            identical(native_state$evaluations, reference_state$evaluations))
  # Do not discard the first cache: its protected result must survive the next
  # native invocation and R allocations between the two calls.
  native <- bridge_optim(case$x, case, native_state, 1L, 1e-10)
  stopifnot(identical(native, reference))
}
check_gc()

cat("Native BFGS equivalence, cache, malformed-input and GC tests passed (",
    cases_checked, " fitting configurations).\n", sep = "")
