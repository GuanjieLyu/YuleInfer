library(YuleInfer)

near <- function(x,y,tol=1e-7)stopifnot(all(is.finite(x)),all(is.finite(y)),max(abs(x-y))<tol)
must_error <- function(expr)stopifnot(inherits(tryCatch({force(expr);NULL},error=identity),"error"))

# An independent odds-ratio quadratic checks probability accuracy, including
# tails where calculating a diagonal cell by subtraction would lose precision.
oracle <- function(pi,v) {
  k<-((1+v)/(1-v))^2; s<-pmin(pi,1-pi); P<-pi*(1-pi)
  small<-2*k*s^2/(1-2*s+2*k*s+sqrt((1-2*s)^2+4*k*s*(1-s)))
  t<-2*P/(1+sqrt((1-2*pi)^2+4*k*P))
  cbind(p0=ifelse(pi<=.5,1-2*pi+small,small),p1=2*t,
        p2=ifelse(pi<=.5,small,1-2*(1-pi)+small))
}
grid<-expand.grid(pi=c(1e-6,.01,.2,.5,.8,.99,1-1e-6),v=c(-.9999,-.6,0,.4,.9999))
p<-yule_probabilities(grid$pi,grid$v); expected<-oracle(grid$pi,grid$v)
near(as.matrix(p[,c("p0","p1","p2")]),expected,2e-12)
stopifnot(all(as.matrix(p[,c("p0","p1","p2")])>0))
near(rowSums(p[,c("p0","p1","p2")]),rep(1,nrow(p)),2e-12)
near(tanh((log(p$p0)+log(p$p2)-2*log(p$p1/2))/4),grid$v,2e-8)
reverse<-yule_probabilities(1-grid$pi,grid$v)
near(p$p0,reverse$p2,2e-12);near(p$p1,reverse$p1,2e-12)

raw<-yule_simulate(c(.15,.40,.65),.06,c(.4,-.2,.55),n_bilateral=150,n_unilateral=60,seed=271001)
fit<-yule_fit(raw)
stopifnot(fit$convergence$ok,fit$convergence$regular,is.finite(fit$se),fit$efficient_information>0)
tests<-lapply(c("LR","score","Wald"),function(m)yule_test(fit,d0=.06,method=m))
stopifnot(all(vapply(tests,inherits,logical(1),"htest")))
for(t in tests)stopifnot(is.finite(t$statistic),t$statistic>=0,t$p.value>=0,t$p.value<=1)

# The full information matrix is orthogonal in the Yule association coordinate.
if(any(grepl("association",rownames(fit$information),fixed=TRUE))) {
  ai<-grep("association",rownames(fit$information),fixed=TRUE)
  near(fit$information[-ai,ai,drop=FALSE],matrix(0,nrow(fit$information)-length(ai),length(ai)),1e-6)
}

# Changing the reference arm reverses the estimand, preserving two-sided tests.
groups<-unique(as.character(raw$group))
revfit<-yule_fit(yule_data(raw,reference=groups[2]))
near(revfit$d,-fit$d,2e-6)
for(m in c("LR","score","Wald"))near(unname(yule_test(fit,.06,m)$statistic),
  unname(yule_test(revfit,-.06,m)$statistic),2e-4)

alluni<-yule_simulate(c(.2,.45),.04,c(.2,-.3),n_bilateral=0,n_unilateral=500,seed=271002)
ufit<-yule_fit(alluni)
stopifnot(ufit$convergence$regular,all(is.na(ufit$association)),nrow(ufit$information)==3L)
ut<-yule_test(ufit,.04,"LR");stopifnot(is.finite(ut$statistic))

wc<-yule_confint(fit,method="Wald")
stopifnot(inherits(wc,"yule_ci"),wc$complete,wc$connected,ncol(wc$intervals)==2,
          wc$intervals[1,1]<=fit$d,wc$intervals[1,2]>=fit$d)
for(m in c("LR","score")) {
  ci<-yule_confint(fit,method=m)
  stopifnot(ci$complete,any(fit$d>=ci$intervals[,1] & fit$d<=ci$intervals[,2]),
            all(is.finite(ci$intervals)))
  for(endpoint in as.vector(ci$intervals))near(unname(yule_test(fit,endpoint,m)$statistic),qchisq(.95,1),.003)
}
ap<-yule_power(c(.03,.06,.10),association=.6,n_bilateral=1000,n_unilateral=100,delta=.01)
near(ap$lambda,5.15620587478056,2e-8);near(ap$power,.622021653697232,2e-8)

bad<-raw;bad$m0[1]<--1;must_error(yule_data(bad))
bad<-raw;bad$m1[1]<-.5;must_error(yule_data(bad))
bad<-raw;bad$u1[1]<-NA;must_error(yule_data(bad))
must_error(yule_data(rbind(raw,raw[1,,drop=FALSE])))
must_error(yule_probabilities(.5,1));must_error(yule_probabilities(0,.4))
must_error(yule_test(yule_fit(raw,d=.06),.06,"LR"))

# A wholly unsuccessful sample has a boundary maximum; regular inference must
# either be blocked by fitting or be blocked by the explicit convergence flag.
boundary<-raw;for(nm in c("m1","m2","u1"))boundary[[nm]]<-0
bf<-tryCatch(yule_fit(boundary),error=identity)
if(!inherits(bf,"error")) {
  stopifnot(!bf$convergence$regular)
  must_error(yule_test(bf,0,"LR"))
}
