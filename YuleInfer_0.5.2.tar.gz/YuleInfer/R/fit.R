# A smooth margin coordinate preserves pi_2 - pi_1 = d. Association
# coordinates are omitted in strata without bilateral observations.
.yule_fit_control <- function(control) {
  defaults <- list(maxit = 1000L, reltol = 1e-10, gradient_tol = 1e-5,
                   boundary_tol = 1e-7, multistart = TRUE)
  if (!is.list(control) || (length(control) &&
      (is.null(names(control)) || any(!nzchar(names(control))) ||
       anyDuplicated(names(control)) || any(!names(control) %in% names(defaults)))))
    stop("control must be a named list of supported fitting controls.", call. = FALSE)
  out <- utils::modifyList(defaults, control, keep.null = TRUE)
  scalar <- function(x) is.numeric(x) && length(x) == 1L && is.finite(x)
  if (!scalar(out$maxit) || out$maxit < 1 || out$maxit != floor(out$maxit) ||
      out$maxit > .Machine$integer.max)
    stop("control$maxit must be a positive integer.", call. = FALSE)
  for (nm in c("reltol", "gradient_tol", "boundary_tol")) {
    if (!scalar(out[[nm]]) || out[[nm]] <= 0 || out[[nm]] >= 1)
      stop("control$", nm, " must be a number strictly between zero and one.",
           call. = FALSE)
  }
  if (!is.logical(out$multistart) || length(out$multistart) != 1L ||
      is.na(out$multistart))
    stop("control$multistart must be TRUE or FALSE.", call. = FALSE)
  out$maxit <- as.integer(out$maxit)
  out
}

.yule_decode <- function(x, J, active, d = NULL) {
  free <- is.null(d)
  offset <- as.integer(free)
  if (free) d <- tanh(x[1L])
  h <- x[offset + seq_len(J)]
  # Solve the product-of-odds quadratic for the smaller margin; this
  # avoids cancellation in rare-margin starting values.
  gap <- abs(d)
  e <- exp(-2 * abs(h))
  B <- gap + e * (2 - gap)
  small <- 2 * e * (1 - gap) /
    (B + sqrt(B * B + 4 * (1 - e) * e * (1 - gap)))
  small[h > 0] <- 1 - gap - small[h > 0]
  b <- small + max(0, -d)
  pi <- as.vector(rbind(b, b + d))
  P1 <- b * (1 - b)
  P2 <- (b + d) * (1 - b - d)
  total <- P1 + P2
  a <- rep(NA_real_, J)
  if (length(active)) a[active] <- tanh(x[offset + J + seq_along(active)])
  list(d = d, baseline = b, association = a, pi = pi,
       bh = 2 * P1 * P2 / total, bd = -P1 / total,
       ar = 1 - a[active]^2, free = free)
}

.yule_encode <- function(d, baseline, association, active, fixed = NULL) {
  clip <- function(x, low, high) pmax(low, pmin(high, x))
  lo <- max(0, -d)
  hi <- min(1, 1 - d)
  baseline <- clip(baseline, lo + (hi - lo) * 1e-8,
                   hi - (hi - lo) * 1e-8)
  pi1 <- clip(baseline, 1e-12, 1 - 1e-12)
  pi2 <- clip(baseline + d, 1e-12, 1 - 1e-12)
  h <- (stats::qlogis(pi1) + stats::qlogis(pi2)) / 2
  c(if (is.null(fixed)) atanh(clip(d, -1 + 1e-8, 1 - 1e-8)), h,
    atanh(clip(association[active], -.999999, .999999)))
}

.yule_initial <- function(data, active, d = NULL, prepared = NULL) {
  ct <- data$counts
  pi <- if (is.null(prepared))
    (ct$m1 + 2 * ct$m2 + ct$u1 + .5) /
      (2 * ct$n_bilateral + ct$n_unilateral + 1) else prepared$initial_pi
  odd <- if (is.null(prepared)) seq.int(1L, 2L * data$J, by = 2L) else prepared$counts$odd
  even <- odd + 1L
  if (is.null(d)) {
    w <- 1 / (1 / (2 * ct$n_bilateral[odd] + ct$n_unilateral[odd]) +
              1 / (2 * ct$n_bilateral[even] + ct$n_unilateral[even]))
    d <- sum(w * (pi[even] - pi[odd])) / sum(w)
  }
  lo <- max(0, -d)
  hi <- min(1, 1 - d)
  b <- pmax(lo + .001 * (hi - lo),
            pmin(hi - .001 * (hi - lo), (pi[odd] + pi[even] - d) / 2))
  if (!is.null(prepared))
    return(list(d = d, baseline = b, association = prepared$initial_association))
  a <- rep(NA_real_, data$J)
  for (j in active) {
    ix <- c(2L * j - 1L, 2L * j)
    ix <- ix[ct$n_bilateral[ix] > 0]
    # A small multinomial continuity adjustment supplies only a start;
    # the fitted likelihood always uses the original counts.
    m0 <- ct$m0[ix] + .5
    m1 <- ct$m1[ix] + .5
    m2 <- ct$m2[ix] + .5
    s <- sqrt(m0 * m2)
    raw <- (s - m1 / 2) / (s + m1 / 2)
    a[j] <- sum(ct$n_bilateral[ix] * raw) / sum(ct$n_bilateral[ix])
  }
  list(d = d, baseline = b, association = a)
}

.yule_information_components <- function(z, pr, ct, active, odd, even) {
  P <- z$pi * (1 - z$pi)
  variance <- pr$p[, 1L] * (2 * z$pi)^2 +
    pr$p[, 2L] * (1 - 2 * z$pi)^2 +
    pr$p[, 3L] * (2 - 2 * z$pi)^2
  A <- 4 * ct$n_bilateral / variance + ct$n_unilateral / P
  association <- z$association
  association[is.na(association)] <- 0
  # Summing the multinomial association information simplifies exactly to
  # 4*dq/dY/(1-Y^2), avoiding squared derivatives and reciprocal tiny cells.
  ar <- rep((1 - association) * (1 + association), each = 2L)
  C <- 4 * ct$n_bilateral * pr$qa / ar
  list(A = A, B = A[odd] + A[even],
       C = (C[odd] + C[even])[active], variance = variance,
       efficient = sum(1 / (1 / A[odd] + 1 / A[even])))
}

.yule_expected_information <- function(z, pr, ct, active, strata, parts = NULL) {
  J <- length(strata)
  odd <- seq.int(1L, 2L * J, by = 2L)
  even <- odd + 1L
  if (is.null(parts))
    parts <- .yule_information_components(z, pr, ct, active, odd, even)
  A <- parts$A
  nm <- c("d", paste0("baseline[", strata, "]"),
          if (length(active)) paste0("association[", strata[active], "]"))
  info <- matrix(0, length(nm), length(nm), dimnames = list(nm, nm))
  info[1L, 1L] <- sum(A[even])
  info[1L, 1L + seq_len(J)] <- A[even]
  info[1L + seq_len(J), 1L] <- A[even]
  diag(info)[1L + seq_len(J)] <- parts$B
  if (length(active)) diag(info)[1L + J + seq_along(active)] <- parts$C
  # The Yule marginal and association scores are exactly orthogonal.
  list(matrix = info, efficient = parts$efficient, A = A,
       variance = parts$variance)
}

.yule_fit_counts <- function(data) {
  ct <- data$counts
  list(m0 = ct$m0, m1 = ct$m1, m2 = ct$m2, positive = ct$m1 + 2 * ct$m2,
       u0 = ct$u0, u1 = ct$u1, n_bilateral = ct$n_bilateral,
       n_unilateral = ct$n_unilateral,
       odd = seq.int(1L, 2L * data$J, by = 2L),
       even = seq.int(2L, 2L * data$J, by = 2L))
}

.yule_evaluate_R <- function(x, data, active, fixed = NULL, counts = NULL) {
  z <- .yule_decode(x, data$J, active, fixed)
  derivatives <- is.null(counts)
  if (is.null(counts)) counts <- .yule_fit_counts(data)
  if (any(!is.finite(z$pi)) || any(z$pi <= 0 | z$pi >= 1))
    return(list(value = 1e100, gradient = rep(0, length(x)), invalid = TRUE))
  a <- z$association
  a[is.na(a)] <- 0
  pr <- .yule_prob(z$pi, rep(a, each = 2L), derivatives = derivatives)
  if (any(!is.finite(pr$p)) || any(pr$p <= 0) ||
      any(!is.finite(pr$qa)))
    return(list(value = 1e100, gradient = rep(0, length(x)), invalid = TRUE))
  p0 <- pr$p[, 1L]; p1 <- pr$p[, 2L]; p2 <- pr$p[, 3L]
  ll <- sum(counts$m0 * log(p0) + counts$m1 * log(p1) +
            counts$m2 * log(p2)) +
    sum(counts$u1 * log(z$pi) + counts$u0 * log1p(-z$pi))
  P <- z$pi * (1 - z$pi)
  variance <- p0 * (2 * z$pi)^2 + p1 * (1 - 2 * z$pi)^2 +
    p2 * (2 - 2 * z$pi)^2
  # At fixed Yule association, K is an exponential family with mean 2*pi.
  # Its exact marginal score needs only the observed positive-response total.
  up <- 2 * (counts$positive - 2 * counts$n_bilateral * z$pi) / variance +
    (counts$u1 - counts$n_unilateral * z$pi) / P
  ua <- pr$qa * (counts$m0 / p0 - 2 * counts$m1 / p1 + counts$m2 / p2)
  odd <- counts$odd
  even <- counts$even
  Ub <- up[odd] + up[even]
  Ua <- (ua[odd] + ua[even])[active]
  Ud <- sum(up[even])
  score <- c(Ud, Ub, Ua)
  grad <- c(if (z$free) (1 - z$d^2) * (Ud + sum(Ub * z$bd)),
            Ub * z$bh, Ua * z$ar)
  list(value = -ll, gradient = -grad, score = score, natural = z,
       probability = pr, invalid = !is.finite(ll) || any(!is.finite(grad)))
}

#' Fit the stratified shared-Yule common risk difference model
#'
#' @param data A yule_data object or a count data frame accepted by yule_data.
#' @param d NULL to estimate the common risk difference, or an interior value
#'   to fix it and maximize the nuisance likelihood.
#' @param control A named list of fitting controls. See the package manual.
#' @return An object of class yule_fit, including convergence diagnostics.
#' @export
yule_fit <- function(data, d = NULL, control = list()) {
  if (inherits(data, "yule_data"))
    data <- .make_yule_data(data$counts, reference = data$reference, integer = TRUE)
  .yule_fit(data, d = d, control = control)
}

.yule_fit <- function(data, d = NULL, start = NULL, control = list(),
                      prepared = NULL, profile = FALSE) {
  data <- if (is.null(prepared)) .as_yule_data(data) else prepared$data
  ctl <- if (is.null(prepared)) .yule_fit_control(control) else prepared$controls
  if (!is.null(d) && (!is.numeric(d) || length(d) != 1L || !is.finite(d) || abs(d) >= 1))
    stop("d must be NULL or a number strictly between -1 and 1.", call. = FALSE)
  ct <- data$counts
  counts <- if (is.null(prepared)) .yule_fit_counts(data) else prepared$counts
  active <- if (is.null(prepared))
    which(ct$n_bilateral[seq.int(1L, 2L * data$J, 2L)] +
            ct$n_bilateral[seq.int(2L, 2L * data$J, 2L)] > 0) else prepared$active
  initial <- .yule_initial(data, active, d, prepared)
  seeds <- list(initial)
  if (!is.null(start)) {
    if (inherits(start, "yule_fit")) {
      if (!identical(start$data$strata, data$strata) ||
          !identical(start$data$groups, data$groups))
        stop("start has incompatible stratum or group ordering.", call. = FALSE)
      start <- list(d = start$d, baseline = start$baseline,
                    association = start$association)
    }
    if (!is.list(start) || !is.numeric(start$d) || length(start$d) != 1L ||
        !is.finite(start$d) || abs(start$d) >= 1 ||
        !is.numeric(start$baseline) || length(start$baseline) != data$J ||
        any(!is.finite(start$baseline)) || !is.numeric(start$association) ||
        length(start$association) != data$J ||
        any(!is.finite(start$association[active])) ||
        any(abs(start$association[active]) >= 1))
      stop("start must contain compatible d, baseline, and association values.", call. = FALSE)
    if (!is.null(d)) start$d <- d
    seeds <- if (ctl$multistart) c(list(start), seeds) else list(start)
  }
  if (ctl$multistart && length(active)) {
    for (v in c(0, .6, -.6)) {
      s <- initial
      s$association[active] <- v
      seeds[[length(seeds) + 1L]] <- s
    }
  }
  xstarts <- lapply(seeds, function(s)
    .yule_encode(s$d, s$baseline, s$association, active, fixed = d))
  xstarts <- xstarts[!duplicated(vapply(xstarts, paste, collapse = ",", character(1L)))]
  engine <- .native_fit_evaluator(data, active, "yule", d, counts)
  evaluate <- engine$evaluate
  optimize <- function(x, reltol) {
    tryCatch(engine$optimize(x, ctl$maxit, reltol),
             error = function(e) NULL)
  }
  candidates <- lapply(xstarts, optimize, reltol = ctl$reltol)
  candidates <- Filter(function(o) !is.null(o) && is.finite(o$value) &&
                         !evaluate(o$par)$invalid, candidates)
  if (!length(candidates))
    stop("No finite interior likelihood fit was found; check sparse or degenerate data.",
         call. = FALSE)
  best <- candidates[[which.min(vapply(candidates, function(o) o$value, numeric(1L)))]]
  # Likelihood stopping alone may leave appreciable standardized scores.
  # A safeguarded Fisher step solves the natural-information arrowhead block
  # analytically, then maps it into the same feasible optimization coordinates.
  # No dense matrix inversion or repeated BFGS restart is needed near the MLE.
  fisher_iterations <- 0L
  fisher_backtracks <- 0L
  target <- min(ctl$gradient_tol / 10, 1e-7)
  score_scale <- function(fit, parts) {
    diagonal <- c(sum(parts$A[counts$even]), parts$B, parts$C)
    checked <- if (is.null(d)) seq_along(diagonal) else seq.int(2L, length(diagonal))
    max(abs(fit$score[checked]) / sqrt(pmax(diagonal[checked], 1)))
  }
  near_boundary <- function(fit) {
    z <- fit$natural
    used <- counts$n_bilateral > 0
    min(c(z$pi, 1 - z$pi,
          if (any(used)) fit$probability$p[used, , drop = FALSE] else Inf,
          if (length(active)) 1 - abs(z$association[active]) else Inf)) <=
      ctl$boundary_tol
  }
  fit <- evaluate(best$par)
  parts <- .yule_information_components(fit$natural, fit$probability, counts,
                                         active, counts$odd, counts$even)
  for (k in seq_len(min(20L, ctl$maxit))) {
    scaled <- score_scale(fit, parts)
    if (!is.finite(scaled) || near_boundary(fit) ||
        any(!is.finite(c(parts$A, parts$C, parts$efficient))) ||
        any(c(parts$B, parts$C, parts$efficient) <= 0)) break
    if (scaled <= target) {
      best$convergence <- 0L
      break
    }
    z <- fit$natural
    Ub <- fit$score[1L + seq_len(data$J)]
    A2 <- parts$A[counts$even]
    dd <- if (is.null(d))
      (fit$score[1L] - sum(A2 * Ub / parts$B)) / parts$efficient else 0
    db <- (Ub - A2 * dd) / parts$B
    da <- if (length(active)) fit$score[1L + data$J + seq_along(active)] / parts$C
    direction <- c(if (is.null(d)) dd / (1 - z$d^2),
                   (db - z$bd * dd) / z$bh, da / z$ar)
    if (any(!is.finite(direction))) break
    accepted <- FALSE
    slope <- -sum(fit$gradient * direction)
    if (!is.finite(slope) || slope <= 0) break
    roundoff <- 32 * .Machine$double.eps * max(1, abs(fit$value))
    for (backtrack in 0:24) {
      step <- 2^(-backtrack)
      trial <- evaluate(best$par + step * direction)
      if (!trial$invalid && trial$value <= fit$value + roundoff) {
        trial_parts <- .yule_information_components(trial$natural, trial$probability,
          counts, active, counts$odd, counts$even)
        trial_scaled <- score_scale(trial, trial_parts)
        if (trial$value <= fit$value - 1e-4 * step * slope ||
            (is.finite(trial_scaled) && trial_scaled < scaled)) {
          best$par <- best$par + step * direction
          best$value <- trial$value
          fit <- trial
          parts <- trial_parts
          fisher_iterations <- fisher_iterations + 1L
          fisher_backtracks <- fisher_backtracks + backtrack
          accepted <- TRUE
          break
        }
      }
    }
    if (!accepted) break
  }
  # Preserve BFGS as a fallback for a boundary estimate or an unsuccessful
  # scoring polish. Selection still uses likelihood, never status alone.
  if (near_boundary(fit) || !is.finite(score_scale(fit, parts)) ||
      score_scale(fit, parts) > ctl$gradient_tol || best$convergence != 0L) {
    for (k in seq_len(2L)) {
      polished <- optimize(best$par, min(ctl$reltol, 1e-13))
      if (!is.null(polished) && polished$value <= best$value + 1e-9 &&
          !evaluate(polished$par)$invalid) best <- polished
    }
    fit <- evaluate(best$par)
    parts <- .yule_information_components(fit$natural, fit$probability, counts,
                                           active, counts$odd, counts$even)
  }
  z <- fit$natural
  pr <- fit$probability
  info <- .yule_expected_information(z, pr, ct, active, data$strata, parts)
  names(z$baseline) <- names(z$association) <- data$strata
  coefficients <- c(z$d, z$baseline, z$association[active])
  names(coefficients) <- names(fit$score) <- colnames(info$matrix)
  checked <- if (is.null(d)) seq_along(fit$score) else seq.int(2L, length(fit$score))
  scaled <- max(abs(fit$score[checked]) / sqrt(pmax(diag(info$matrix)[checked], 1)))
  rawgradient <- max(abs(fit$gradient))
  margins <- pmin(z$pi, 1 - z$pi)
  used <- ct$n_bilateral > 0
  minprob <- if (any(used)) min(pr$p[used, , drop = FALSE]) else Inf
  mina <- if (length(active)) min(1 - abs(z$association[active])) else Inf
  boundary <- min(c(margins, minprob, mina)) <= ctl$boundary_tol
  nonsingular <- all(is.finite(info$matrix)) && all(diag(info$matrix) > 0) &&
    is.finite(info$efficient) && info$efficient > 0
  stationary <- is.finite(scaled) && scaled <= ctl$gradient_tol
  boundary_stationary <- boundary && is.finite(rawgradient) &&
    rawgradient / sqrt(max(1, data$N)) <= ctl$gradient_tol
  ok <- best$convergence == 0L && (stationary || boundary_stationary)
  regular <- ok && !boundary && nonsingular
  status <- if (!ok) "not_converged" else if (boundary) "boundary" else
    if (!nonsingular) "singular_information" else "converged"
  reason <- switch(status, converged = "Interior likelihood maximum with stationary scores.",
                   boundary = "The estimate is near a parameter or probability boundary; regular inference is unavailable.",
                   singular_information = "Expected information is singular; regular inference is unavailable.",
                   not_converged = "Optimization did not satisfy the stationary-score criterion.")
  # Compact fits stay inside CI inversion and its warm starts. Public fitting
  # and testing always request full objects with display fields and caches.
  if (profile) {
    constant <- if (!is.null(prepared)) prepared$constant else
      sum(lgamma(ct$n_bilateral + 1) - lgamma(ct$m0 + 1) - lgamma(ct$m1 + 1) -
        lgamma(ct$m2 + 1) + lgamma(ct$n_unilateral + 1) - lgamma(ct$u0 + 1) - lgamma(ct$u1 + 1))
    return(structure(list(model = "yule", data = data, d = z$d, baseline = z$baseline,
      association = z$association, logLik = -fit$value + constant, logLik_kernel = -fit$value,
      score = fit$score, information = info$matrix, efficient_information = info$efficient,
      convergence = list(ok = ok, regular = regular, status = status,
        gradient = rawgradient, scaled_gradient = scaled, iterations = NA_integer_,
        evaluations = best$counts, boundary = boundary, reason = reason, starts = length(xstarts),
        likelihood_evaluations = engine$evaluations(), fisher_iterations = fisher_iterations,
        fisher_backtracks = fisher_backtracks, minimum_probability = minprob),
      fixed = !is.null(d), controls = ctl, active_association = active), class = "yule_fit"))
  }
  ptable <- data.frame(stratum = ct$stratum, group = ct$group, pi = z$pi,
                       association = rep(z$association, each = 2L),
                       p0 = pr$p[, 1L], p1 = pr$p[, 2L], p2 = pr$p[, 3L], q = pr$q)
  noassociation <- is.na(ptable$association)
  ptable[noassociation, c("p0", "p1", "p2", "q")] <- NA_real_
  constant <- sum(lgamma(ct$n_bilateral + 1) - lgamma(ct$m0 + 1) -
                    lgamma(ct$m1 + 1) - lgamma(ct$m2 + 1) +
                    lgamma(ct$n_unilateral + 1) - lgamma(ct$u0 + 1) -
                    lgamma(ct$u1 + 1))
  structure(list(model = "yule", data = data, d = z$d, baseline = z$baseline,
                 association = z$association, probabilities = ptable,
                 coefficients = coefficients, logLik = -fit$value + constant,
                 logLik_kernel = -fit$value, logLik_constant = constant,
                 score = fit$score, information = info$matrix,
                 efficient_information = info$efficient,
                 se = if (regular) 1 / sqrt(info$efficient) else NA_real_,
                 convergence = list(ok = ok, regular = regular, status = status,
                   gradient = rawgradient, scaled_gradient = scaled,
                   iterations = NA_integer_, evaluations = best$counts, boundary = boundary,
                   reason = reason, starts = length(xstarts),
                   likelihood_evaluations = engine$evaluations(),
                   fisher_iterations = fisher_iterations,
                   fisher_backtracks = fisher_backtracks,
                   minimum_probability = minprob),
                 parameter_count = length(coefficients) - as.integer(!is.null(d)),
                 fixed = !is.null(d), controls = ctl, active_association = active),
            class = "yule_fit", .yule_cache = new.env(parent = emptyenv()))
}
