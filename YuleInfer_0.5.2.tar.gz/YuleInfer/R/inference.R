# Inference for the common marginal risk difference.

.yule_check_inference_fit <- function(object) {
  if (!inherits(object, "yule_fit"))
    stop("'object' must be a yule_fit result.", call. = FALSE)
  if (isTRUE(object$fixed))
    stop("Inference requires an unconstrained fit; refit with d = NULL.",
         call. = FALSE)
  if (!isTRUE(object$convergence$regular)) {
    reason <- object$convergence$reason
    if (is.null(reason) || !length(reason)) reason <- "nonregular fit"
    stop("Chi-square inference requires a converged interior fit with ",
         "nonsingular information: ", paste(reason, collapse = "; "),
         ".", call. = FALSE)
  }
  if (!is.finite(object$efficient_information) ||
      object$efficient_information <= 0)
    stop("The efficient information must be finite and positive.",
         call. = FALSE)
  invisible(object)
}

.yule_check_null <- function(d0) {
  if (!is.numeric(d0) || length(d0) != 1L || !is.finite(d0) ||
      d0 <= -1 || d0 >= 1)
    stop("'d0' must be a finite number strictly between -1 and 1.",
         call. = FALSE)
  invisible(d0)
}

# Public LR and score tests can share regular null fits at recently used nulls.
# Keep at most four entries, and compare every input that affects refitting.
# A copied fit may share the environment; the snapshot prevents stale reuse.
.yule_null_cache_key <- function(object, d0, fit.control) {
  list(model = .fit_model(object), d0 = d0, data = object$data, d = object$d,
       baseline = object$baseline, association = object$association,
       controls = object$controls, fit.control = fit.control,
       logLik = object$logLik, logLik_kernel = object$logLik_kernel,
       convergence = object$convergence)
}

.yule_profile_statistic <- function(object, d0, method, start = object,
                                    fit.control = NULL, strict = TRUE,
                                    use.cache = FALSE, prepared = NULL) {
  fail <- function(message, fit = NULL) {
    if (strict) stop(message, call. = FALSE)
    list(statistic = NA_real_, fit = fit, message = message)
  }
  if (is.null(fit.control)) fit.control <- object$controls
  if (is.null(fit.control)) fit.control <- list()
  cache <- if (use.cache && identical(start, object))
    attr(object, ".yule_cache", exact = TRUE) else NULL
  key <- restricted <- NULL
  if (is.environment(cache)) {
    key <- .yule_null_cache_key(object, d0, fit.control)
    entry <- cache$entry
    if (!is.null(entry) && identical(entry$key, key) &&
        isTRUE(entry$fit$convergence$regular)) {
      restricted <- entry$fit
    } else {
      cache$entry <- NULL
      entries <- cache$null_entries
      if (length(entries)) {
        matching <- which(vapply(entries, function(z)
          identical(z$key, key) && isTRUE(z$fit$convergence$regular), logical(1)))
        if (length(matching)) restricted <- entries[[matching[1L]]]$fit
      }
    }
  }
  if (is.null(restricted))
    restricted <- tryCatch(
      .model_fit(object$data, model = .fit_model(object), d = d0,
                 start = start, control = fit.control, prepared = prepared,
                 profile = !is.null(prepared)),
      error = function(e) e)
  if (inherits(restricted, "error"))
    return(fail(conditionMessage(restricted)))
  if (!isTRUE(restricted$convergence$ok))
    return(fail(paste("The constrained fit is unusable:",
                     paste(restricted$convergence$reason, collapse = "; ")),
                restricted))
  if ((strict || method == "score") &&
      !isTRUE(restricted$convergence$regular))
    return(fail("The constrained fit is nonregular; chi-square inference is unavailable.",
                restricted))
  if (method == "LR") {
    difference <- 2 * (object$logLik - restricted$logLik)
    tolerance <- 1e-7 * (1 + abs(object$logLik))
    if (!is.finite(difference) || difference < -tolerance)
      return(fail("The constrained log likelihood exceeds the full maximum; refit before inference.",
                  restricted))
    statistic <- max(0, difference)
  } else {
    information <- restricted$efficient_information
    score <- unname(restricted$score["d"])
    if (length(score) != 1L || !is.finite(score) ||
        !is.finite(information) || information <= 0)
      return(fail("The constrained score or efficient information is unusable.",
                  restricted))
    statistic <- score^2 / information
  }
  if (is.environment(cache) && isTRUE(restricted$convergence$regular)) {
    entry <- list(key = key, fit = restricted)
    cache$entry <- entry
    entries <- cache$null_entries
    if (length(entries)) entries <- entries[!vapply(entries, function(z)
      identical(z$key, key), logical(1))]
    entries[[length(entries) + 1L]] <- entry
    cache$null_entries <- tail(entries, 4L)
  }
  list(statistic = statistic, fit = restricted, message = "")
}

#' Test a common risk difference under the fitted association model
#'
#' @param object An unconstrained, regular result from yule_fit or strat_fit.
#' @param d0 Null common risk difference, strictly between -1 and 1.
#' @param method One of `"LR"`, `"score"`, or `"Wald"`.
#' @return An object of class `htest`, using an asymptotic chi-square reference
#'   distribution with one degree of freedom. No confidence interval is fitted
#'   automatically. Boundary or otherwise nonregular fits produce an error.
#' @export
yule_test <- function(object, d0 = 0, method = c("LR", "score", "Wald")) {
  .yule_check_inference_fit(object)
  .yule_check_null(d0)
  method <- match.arg(method)
  restricted <- NULL
  if (method == "Wald") {
    statistic <- (object$d - d0)^2 * object$efficient_information
  } else {
    result <- .yule_profile_statistic(object, d0, method, use.cache = TRUE)
    statistic <- result$statistic
    restricted <- result$fit
  }
  labels <- c(LR = "likelihood-ratio", score = "score", Wald = "Wald")
  statistic.name <- if (method == "score") "Score" else method
  structure(list(
    statistic = stats::setNames(statistic, statistic.name),
    parameter = c(df = 1),
    p.value = stats::pchisq(statistic, df = 1, lower.tail = FALSE),
    estimate = c("common risk difference" = object$d),
    null.value = c("common risk difference" = d0),
    alternative = "two.sided",
    method = paste(.model_label(.fit_model(object)), labels[[method]],
                   "test for a common risk difference"),
    data.name = paste(deparse(substitute(object)), collapse = " "),
    diagnostics = list(full = object$convergence,
                       null = if (is.null(restricted)) NULL else restricted$convergence)
  ), class = "htest")
}

.yule_ci_control <- function(control) {
  defaults <- list(grid.length = 33L, refinements = 1L, root.tol = 1e-6,
                   boundary.eps = 1e-5, max.evaluations = 300L,
                   fit.control = list())
  if (!is.list(control) || (length(control) &&
      (is.null(names(control)) || any(!nzchar(names(control))) ||
       anyDuplicated(names(control)))))
    stop("'control' must be a uniquely named list.", call. = FALSE)
  unknown <- setdiff(names(control), names(defaults))
  if (length(unknown))
    stop("Unknown confidence-set control: ", paste(unknown, collapse = ", "),
         ".", call. = FALSE)
  answer <- utils::modifyList(defaults, control)
  integer.control <- function(x, minimum, maximum, label) {
    if (!is.numeric(x) || length(x) != 1L || !is.finite(x) ||
        x != round(x) || x < minimum || x > maximum)
      stop("Invalid confidence-set control '", label, "'.", call. = FALSE)
    as.integer(x)
  }
  answer$grid.length <- integer.control(answer$grid.length, 9, 1001, "grid.length")
  answer$refinements <- integer.control(answer$refinements, 0, 8, "refinements")
  answer$max.evaluations <- integer.control(answer$max.evaluations, 25, 100000,
                                           "max.evaluations")
  for (field in c("root.tol", "boundary.eps")) {
    value <- answer[[field]]
    maximum <- if (field == "root.tol") 0.01 else 0.1
    if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
        value <= 0 || value >= maximum)
      stop("Invalid confidence-set control '", field, "'.", call. = FALSE)
  }
  if (!is.list(answer$fit.control))
    stop("'fit.control' must be a list of yule_fit controls.", call. = FALSE)
  answer
}

.yule_accepted_runs <- function(accepted) {
  good <- !is.na(accepted) & accepted
  if (!any(good)) return(matrix(integer(), 0L, 2L))
  bounds <- cbind(which(good & !c(FALSE, head(good, -1L))),
                  which(good & !c(tail(good, -1L), FALSE)))
  colnames(bounds) <- c("start", "end")
  bounds
}

# Global lower bounds certify exclusion of the distant tails. Pinsker's
# inequality for K/2 in [0,1] gives deviance >= 4 N (pi - empirical_mean)^2.
# For score inversion, stationarity gives U_d = sum W_A (tilde_difference-d),
# with tilde margins between their bilateral and unilateral empirical margins;
# A_i >= 4 N_i then gives I_eff >= 4 sum W_N.
.yule_ci_tail_bound <- function(object, method, critical) {
  # The stationary-score argument uses Yule's marginal score identity.
  # Pinsker's LR bound uses only the observed means and applies to all models.
  if (method == "score" && .fit_model(object) != "yule")
    return(.classical_score_tail_bound(object, critical))
  ct <- object$data$counts
  if (is.null(ct) || !is.data.frame(ct) || !nrow(ct)) return(NULL)
  odd <- seq.int(1L, nrow(ct), 2L)
  even <- odd + 1L
  N <- ct$n_bilateral + ct$n_unilateral
  weights <- 1 / (1 / N[odd] + 1 / N[even])
  minimum.information <- 4 * sum(weights)
  if (method == "LR") {
    if (is.null(object$logLik_kernel) || !is.finite(object$logLik_kernel)) return(NULL)
    counts <- as.matrix(ct[, c("m0", "m1", "m2", "u0", "u1")])
    totals <- cbind(ct$n_bilateral, ct$n_bilateral, ct$n_bilateral,
                    ct$n_unilateral, ct$n_unilateral)
    positive <- counts > 0
    saturated <- sum(counts[positive] * log(counts[positive] / totals[positive]))
    deviance <- max(0, 2 * (saturated - object$logLik_kernel))
    empirical <- (ct$m1 / 2 + ct$m2 + ct$u1) / N
    difference <- empirical[even] - empirical[odd]
    center <- sum(weights * difference) / sum(weights)
    offset <- 4 * sum(weights * (difference - center)^2)
    radius2 <- (critical + deviance - offset) / minimum.information
    if (!is.finite(radius2) || radius2 < 0) return(NULL)
    list(type = "Pinsker deviance", range = center + c(-1, 1) * sqrt(radius2),
         center = center, weights = weights, difference = difference,
         fitted_saturated_deviance = deviance)
  } else {
    minimum <- maximum <- numeric(nrow(ct))
    for (k in seq_len(nrow(ct))) {
      components <- c(if (ct$n_bilateral[k] > 0)
        (ct$m1[k] + 2 * ct$m2[k]) / (2 * ct$n_bilateral[k]),
        if (ct$n_unilateral[k] > 0) ct$u1[k] / ct$n_unilateral[k])
      minimum[k] <- min(components)
      maximum[k] <- max(components)
    }
    lower <- min(minimum[even] - maximum[odd])
    upper <- max(maximum[even] - minimum[odd])
    radius <- sqrt(critical / minimum.information)
    list(type = "Stationary efficient score", range = c(lower - radius, upper + radius),
         empirical_difference_range = c(lower, upper),
         minimum_information = minimum.information)
  }
}

# A separate bound for the three classical families. With e = 1 - abs(d),
# scale both margins toward their deterministic limits while holding the
# relative margin and association coordinates fixed. For 0 < e <= 1/4,
# each subject's directional score is in [-C, 2/e + C], C = 4/(1 - 2e).
# A subject inconsistent with those limits has score at least 1/e - C.
# The mean-zero score identity bounds directional information by
# N*C*(2/e+C). At a regular stationary constrained fit this yields
# T_score >= [M - (2*M + 4*N)*e]_+^2 / (8*N*e).
# This does not substitute LR/Wald for score, or certify nonregular inference.
# The complete derivation is in inst/doc/score-tail-bounds.txt.
.classical_score_tail_bound <- function(object, critical) {
  ct <- object$data$counts
  if (is.null(ct) || !is.data.frame(ct) || !nrow(ct)) return(NULL)
  odd <- seq.int(1L, nrow(ct), 2L)
  even <- odd + 1L
  N <- sum(ct$n_bilateral + ct$n_unilateral)
  if (!is.finite(N) || N <= 0) return(NULL)
  mismatches <- c(
    negative = sum(ct$m0[odd] + ct$m1[odd] + ct$u0[odd] +
                     ct$m1[even] + ct$m2[even] + ct$u1[even]),
    positive = sum(ct$m1[odd] + ct$m2[odd] + ct$u1[odd] +
                     ct$m0[even] + ct$m1[even] + ct$u0[even]))
  # Solve the bound = critical using a stable positive quadratic root in
  # sqrt(e). Scaling by N avoids squaring the original subject counts.
  fraction <- mismatches / N
  b <- sqrt(8 * critical / N)
  radius <- (2 * fraction /
    (b + sqrt(b^2 + 4 * (2 * fraction + 4) * fraction)))^2
  radius[fraction == 0] <- 0
  list(type = "Classical efficient score",
       range = c(-1 + unname(radius["negative"]),
                  1 - unname(radius["positive"])),
       subjects = N, incompatible_subjects = mismatches,
       tail_radius = radius, model = .fit_model(object))
}

.yule_ci_bound_value <- function(bound, d) {
  if (is.null(bound)) return(NA_real_)
  if (bound$type == "Pinsker deviance")
    return(max(0, 4 * sum(bound$weights * (d - bound$difference)^2) -
                 bound$fitted_saturated_deviance))
  if (bound$type == "Classical efficient score") {
    e <- 1 - abs(d)
    if (!is.finite(e) || e <= 0 || e > .25) return(0)
    direction <- if (d < 0) "negative" else "positive"
    fraction <- unname(bound$incompatible_subjects[direction]) / bound$subjects
    return(bound$subjects * max(0, fraction - (2 * fraction + 4) * e)^2 /
             (8 * e))
  }
  distance <- max(bound$empirical_difference_range[1L] - d,
                   d - bound$empirical_difference_range[2L], 0)
  bound$minimum_information * distance^2
}

#' Confidence sets for a common risk difference
#'
#' @param object An unconstrained, regular result from yule_fit or strat_fit.
#' @param level Confidence level strictly between zero and one.
#' @param method `"LR"`, `"score"`, or `"Wald"`.
#' @param control Named list: `grid.length` (33), `refinements` (1),
#'   `root.tol` (1e-6), `boundary.eps` (1e-5), `max.evaluations` (300),
#'   and `fit.control` (a list passed to constrained fits).
#' @details LR and score sets invert their respective tests over a global grid,
#'   supplemented near the estimate and uniformly refined. Conservative
#'   analytic statistic bounds exclude distant tails before numerical fitting.
#'   Pinsker's inequality applies to all LR sets. Yule score sets use an
#'   orthogonal-score bound; classical score sets use a separate bound from
#'   the counts incompatible with extreme margins. These bounds exclude
#'   tails of the regular score test, without fitting nearly deterministic
#'   tables. Remaining unresolved regions are retained explicitly. Excluded
#'   grid values are lower bounds, not fitted test statistics. All detected
#'   components are retained. `complete` means that the requested finite grid
#'   and root solves succeeded and component counts stabilized at that
#'   resolution; it is not a proof that arbitrarily narrow components do not
#'   exist. Increase `grid.length` or `refinements` to assess grid sensitivity.
#'   Unknown numerical regions make `complete = FALSE`; endpoints adjoining
#'   such regions are `NA` rather than invented. LR profiling can use a finite,
#'   converged boundary nuisance fit, whereas score inversion requires regular
#'   constrained fits. The full fit must be regular for every method.
#' @return A `yule_ci` list with a `lower`/`upper` interval matrix, method,
#'   level, estimate, connectedness, completeness, and numerical diagnostics.
#' @export
yule_confint <- function(object, level = 0.95,
                         method = c("LR", "score", "Wald"), control = list()) {
  .yule_check_inference_fit(object)
  if (!is.numeric(level) || length(level) != 1L || !is.finite(level) ||
      level <= 0 || level >= 1)
    stop("'level' must be a number strictly between zero and one.", call. = FALSE)
  method <- match.arg(method)
  settings <- .yule_ci_control(control)
  if (is.list(object$controls))
    settings$fit.control <- utils::modifyList(object$controls, settings$fit.control)
  critical <- stats::qchisq(level, df = 1)
  make.answer <- function(intervals, complete, connected, diagnostics) {
    colnames(intervals) <- c("lower", "upper")
    rownames(intervals) <- if (nrow(intervals))
      paste0("component", seq_len(nrow(intervals))) else character()
    structure(list(model = .fit_model(object), intervals = intervals,
                   method = method, level = level,
                   estimate = object$d, connected = connected, complete = complete,
                   diagnostics = diagnostics), class = "yule_ci")
  }
  if (method == "Wald") {
    half.width <- stats::qnorm((1 + level) / 2) * object$se
    intervals <- matrix(c(max(-1, object$d - half.width),
                          min(1, object$d + half.width)), 1L, 2L)
    return(make.answer(intervals, TRUE, TRUE,
                       list(critical_value = critical, evaluations = 0L,
                            physical_boundary_open = c(intervals[1, 1] == -1,
                                                       intervals[1, 2] == 1),
                            status = "complete")))
  }
  # Repeated requests for a completed set need no new profile optimization.
  # Snapshots include the full data and all fit fields used by the search;
  # copied fits can share the cache environment without sharing stale results.
  fit.cache <- attr(object, ".yule_cache", exact = TRUE)
  ci.key <- NULL
  if (is.environment(fit.cache)) {
    ci.key <- list(fit = .yule_null_cache_key(object, NULL, settings$fit.control),
                   se = object$se, efficient_information = object$efficient_information,
                   method = method, level = level, settings = settings)
    entries <- fit.cache$ci_entries
    if (length(entries)) {
      matching <- which(vapply(entries, function(z)
        identical(z$key, ci.key), logical(1)))
      if (length(matching)) {
        found <- matching[1L]
        entry <- entries[[found]]
        fit.cache$ci_entries <- c(entries[-found], list(entry))
        return(entry$answer)
      }
    }
  }
  tail.bound <- .yule_ci_tail_bound(object, method, critical)
  prepared <- if (inherits(object$data, "yule_data"))
    tryCatch(.model_fit_context(object$data, .fit_model(object), settings$fit.control),
             error = function(e) NULL) else NULL
  cache <- new.env(parent = emptyenv())
  records <- list()
  successful.d <- numeric()
  successful.fits <- list()
  evaluations <- 0L
  budget.reached <- FALSE
  profile.retries <- list()
  evaluate <- function(d) {
    key <- sprintf("%.17g", d)
    if (exists(key, envir = cache, inherits = FALSE))
      return(get(key, envir = cache, inherits = FALSE))
    lower.bound <- .yule_ci_bound_value(tail.bound, d)
    if (is.finite(lower.bound) && lower.bound > critical + 1e-8 * (1 + critical)) {
      record <- list(d = d, statistic = lower.bound, accepted = FALSE,
                     status = "excluded_bound", message = "Certified analytic rejection.",
                     fit = NULL)
      assign(key, record, envir = cache)
      records[[length(records) + 1L]] <<- record
      return(record)
    }
    if (evaluations >= settings$max.evaluations) {
      budget.reached <<- TRUE
      return(list(d = d, statistic = NA_real_, accepted = NA,
                  status = "budget", message = "Profile evaluation budget exhausted.",
                  fit = NULL))
    }
    start <- object
    if (length(successful.d)) {
      # Successful profiles are appended in the original evaluation order;
      # which.min retains the same first warm start when distances tie.
      closest <- which.min(abs(successful.d - d))
      start <- successful.fits[[closest]]
    }
    result <- if (is.null(prepared))
      .yule_profile_statistic(object, d, method, start = start,
                              fit.control = settings$fit.control, strict = FALSE) else
      .yule_profile_statistic(object, d, method, start = start,
                              fit.control = settings$fit.control, strict = FALSE,
                              prepared = prepared)
    evaluations <<- evaluations + 1L
    # A nearby profile is normally a useful warm start, but occasionally
    # exhausts the optimizer before reaching stationarity. For classical
    # score inversion only, retry that nonboundary failure once from the
    # original full fit. Both attempts count toward the existing budget;
    # successful evaluations and genuine boundary fits are never replaced.
    if (method == "score" && .fit_model(object) != "yule" &&
        !is.finite(result$statistic) && !is.null(result$fit) &&
        identical(result$fit$convergence$status, "not_converged") &&
        !isTRUE(result$fit$convergence$boundary) &&
        !identical(start, object) && evaluations < settings$max.evaluations) {
      retry <- if (is.null(prepared))
        .yule_profile_statistic(object, d, method, start = object,
          fit.control = settings$fit.control, strict = FALSE) else
        .yule_profile_statistic(object, d, method, start = object,
          fit.control = settings$fit.control, strict = FALSE, prepared = prepared)
      evaluations <<- evaluations + 1L
      previous.ll <- result$fit$logLik_kernel
      retry.ll <- if (is.null(retry$fit)) NA_real_ else retry$fit$logLik_kernel
      likelihood.ok <- is.finite(retry.ll) && is.finite(previous.ll) &&
        retry.ll >= previous.ll - 1e-8 * (1 + abs(previous.ll))
      recovered <- is.finite(retry$statistic) && likelihood.ok
      profile.retries[[length(profile.retries) + 1L]] <<- data.frame(
        d = d, initial_message = result$message,
        retry_message = retry$message, recovered = recovered,
        initial_logLik_kernel = previous.ll, retry_logLik_kernel = retry.ll,
        stringsAsFactors = FALSE)
      if (recovered) result <- retry
    }
    record <- list(d = d, statistic = result$statistic,
                   accepted = if (is.finite(result$statistic))
                     result$statistic <= critical else NA,
                   status = if (is.finite(result$statistic)) "ok" else "failed",
                   message = result$message, fit = result$fit)
    assign(key, record, envir = cache)
    records[[length(records) + 1L]] <<- record
    if (!is.null(result$fit) && isTRUE(result$fit$convergence$ok)) {
      successful.d <<- c(successful.d, d)
      successful.fits[[length(successful.fits) + 1L]] <<- result$fit
    }
    record
  }
  evaluate.nodes <- function(nodes) {
    ordered <- nodes[order(abs(nodes - object$d))]
    invisible(lapply(ordered, evaluate))
  }
  lower <- -1 + settings$boundary.eps
  upper <- 1 - settings$boundary.eps
  if (!is.null(tail.bound)) {
    padding <- max(10 * settings$root.tol, diff(tail.bound$range) / 1000)
    lower <- max(lower, tail.bound$range[1L] - padding)
    upper <- min(upper, tail.bound$range[2L] + padding)
  }
  local.length <- max(9L, as.integer(ceiling(settings$grid.length / 2)))
  local <- seq(max(lower, object$d - 8 * object$se),
               min(upper, object$d + 8 * object$se), length.out = local.length)
  nodes <- sort(unique(c(seq(lower, upper, length.out = settings$grid.length),
                         local, object$d)))
  evaluate.nodes(nodes)
  read.grid <- function(nodes) {
    results <- lapply(nodes, evaluate)
    data.frame(d = nodes,
               statistic = vapply(results, function(z) z$statistic, numeric(1)),
               accepted = vapply(results, function(z) z$accepted, logical(1)),
               status = vapply(results, function(z) z$status, character(1)),
               stringsAsFactors = FALSE)
  }
  grid <- read.grid(nodes)
  previous.components <- nrow(.yule_accepted_runs(grid$accepted))
  stable <- settings$refinements == 0L
  completed.refinements <- 0L
  if (settings$refinements > 0L) {
    for (round in seq_len(settings$refinements)) {
      midpoints <- (head(nodes, -1L) + tail(nodes, -1L)) / 2
      evaluate.nodes(midpoints)
      nodes <- sort(unique(c(nodes, midpoints)))
      grid <- read.grid(nodes)
      components <- nrow(.yule_accepted_runs(grid$accepted))
      stable <- components == previous.components
      previous.components <- components
      completed.refinements <- round
      if (budget.reached) break
    }
  }
  runs <- .yule_accepted_runs(grid$accepted)
  intervals <- matrix(NA_real_, nrow(runs), 2L)
  roots <- list()
  root.failed <- FALSE
  find.boundary <- function(a, b) {
    answer <- tryCatch(stats::uniroot(function(d) {
      value <- evaluate(d)$statistic
      if (!is.finite(value)) stop("A profile evaluation failed during root solving.")
      value - critical
    }, interval = c(a, b), tol = settings$root.tol, maxiter = 100L),
    error = function(e) e)
    if (inherits(answer, "error")) {
      root.failed <<- TRUE
      roots[[length(roots) + 1L]] <<- data.frame(left = a, right = b,
        root = NA_real_, status = conditionMessage(answer), stringsAsFactors = FALSE)
      return(NA_real_)
    }
    roots[[length(roots) + 1L]] <<- data.frame(left = a, right = b,
      root = answer$root, status = "ok", stringsAsFactors = FALSE)
    answer$root
  }
  boundary.unresolved <- FALSE
  if (nrow(runs)) {
    for (k in seq_len(nrow(runs))) {
      first <- runs[k, 1L]
      last <- runs[k, 2L]
      if (first > 1L && isFALSE(grid$accepted[first - 1L])) {
        intervals[k, 1L] <- find.boundary(grid$d[first - 1L], grid$d[first])
      } else {
        boundary.unresolved <- TRUE
      }
      if (last < nrow(grid) && isFALSE(grid$accepted[last + 1L])) {
        intervals[k, 2L] <- find.boundary(grid$d[last], grid$d[last + 1L])
      } else {
        boundary.unresolved <- TRUE
      }
    }
  }
  complete <- !anyNA(grid$accepted) && !budget.reached && !root.failed &&
    !boundary.unresolved && stable && completed.refinements == settings$refinements &&
    nrow(runs) > 0L
  failed <- records[vapply(records, function(z)
    !z$status %in% c("ok", "excluded_bound"), logical(1))]
  failed <- if (length(failed)) do.call(rbind, lapply(failed, function(z)
    data.frame(d = z$d, status = z$status, message = z$message,
               stringsAsFactors = FALSE))) else
    data.frame(d = numeric(), status = character(), message = character())
  messages <- character()
  boundary.profiles <- records[vapply(records, function(z)
    !is.null(z$fit) && isTRUE(z$fit$convergence$boundary), logical(1))]
  boundary.profiles <- if (length(boundary.profiles))
    do.call(rbind, lapply(boundary.profiles, function(z)
      data.frame(d = z$d, statistic = z$statistic, accepted = z$accepted))) else
    data.frame(d = numeric(), statistic = numeric(), accepted = logical())
  if (method == "LR" && nrow(boundary.profiles))
    messages <- c(messages, "Some constrained LR profiles reached a nuisance boundary; inspect boundary_profiles.")
  if (anyNA(grid$accepted)) messages <- c(messages, "Numerically unresolved grid regions remain.")
  if (budget.reached) messages <- c(messages, "The profile evaluation budget was exhausted.")
  if (root.failed) messages <- c(messages, "At least one endpoint could not be resolved.")
  if (boundary.unresolved) messages <- c(messages, "An accepted component adjoins an unknown region or search boundary.")
  if (!stable) messages <- c(messages, "The number of detected components changed in the final refinement.")
  if (!nrow(runs)) messages <- c(messages, "No accepted grid component could be resolved.")
  connected <- if (complete) nrow(intervals) == 1L else NA
  answer <- make.answer(intervals, complete, connected,
              list(critical_value = critical, evaluations = evaluations,
                   status = if (complete) "complete at reported resolution" else "incomplete",
                   messages = messages, grid = grid, failed = failed,
                   boundary_profiles = boundary.profiles,
                   roots = if (length(roots)) do.call(rbind, roots) else
                     data.frame(left = numeric(), right = numeric(), root = numeric(), status = character()),
                   search_domain = c(lower, upper), search_range = c(lower, upper),
                   certified_tail_bound = tail.bound,
                   maximum_grid_gap = max(diff(nodes)),
                   completed_refinements = completed.refinements,
                   component_count_stable = stable,
                   settings = settings))
  if (length(profile.retries))
    answer$diagnostics$profile_retries <- do.call(rbind, profile.retries)
  if (complete && is.environment(fit.cache)) {
    entries <- fit.cache$ci_entries
    if (length(entries)) entries <- entries[!vapply(entries, function(z)
      identical(z$key, ci.key), logical(1))]
    entries[[length(entries) + 1L]] <- list(key = ci.key, answer = answer)
    fit.cache$ci_entries <- tail(entries, 4L)
  }
  answer
}
