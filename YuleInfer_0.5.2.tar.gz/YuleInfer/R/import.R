# Convert one row per independent subject to the package's count format.
yule_import <- function(data, group, outcomes, stratum = NULL,
                        reference = NULL, id = NULL) {
  if (!is.data.frame(data) || !nrow(data))
    stop("'data' must be a nonempty data frame with one row per subject.", call. = FALSE)
  if (is.null(names(data)) || anyNA(names(data)) || anyDuplicated(names(data)))
    stop("Column names in 'data' must be nonmissing and unique.", call. = FALSE)

  column_names <- function(x, argument, allowed_lengths = 1L) {
    if (!is.character(x) || !is.null(dim(x)) || !length(x) %in% allowed_lengths ||
        anyNA(x) || any(!nzchar(x)) || anyDuplicated(x))
      stop("'", argument, "' must contain ",
           if (length(allowed_lengths) == 1L) "one column name" else "one or two distinct column names",
           " as character strings.", call. = FALSE)
    absent <- setdiff(x, names(data))
    if (length(absent))
      stop("Unknown column in '", argument, "': ", paste(absent, collapse = ", "), ".", call. = FALSE)
    x
  }
  group <- column_names(group, "group")
  outcomes <- column_names(outcomes, "outcomes", c(1L, 2L))
  if (!is.null(stratum)) stratum <- column_names(stratum, "stratum")
  if (!is.null(id)) id <- column_names(id, "id")
  if (anyDuplicated(c(group, outcomes, stratum, id)))
    stop("Group, outcome, stratum, and ID columns must be distinct.", call. = FALSE)

  labels <- function(column, argument) {
    x <- data[[column]]
    if (!is.atomic(x) || !is.null(dim(x)) || is.complex(x) || is.raw(x) ||
        length(x) != nrow(data))
      stop("The '", argument, "' column must be a vector of subject labels.", call. = FALSE)
    if (anyNA(x) || (is.numeric(x) && any(!is.finite(x))))
      stop("The '", argument, "' column must contain nonmissing, finite labels.", call. = FALSE)
    x <- as.character(x)
    if (anyNA(x) || any(!nzchar(trimws(x))))
      stop("The '", argument, "' column must contain nonmissing, nonempty labels.", call. = FALSE)
    x
  }
  group_labels <- labels(group, "group")
  groups <- unique(group_labels)
  if (length(groups) != 2L)
    stop("Exactly two observed treatment groups are required.", call. = FALSE)
  stratum_labels <- if (is.null(stratum)) rep("1", nrow(data)) else labels(stratum, "stratum")
  strata <- unique(stratum_labels)
  if (!is.null(id)) {
    subject_ids <- labels(id, "id")
    if (anyDuplicated(subject_ids))
      stop("The 'id' column must identify each subject uniquely across the entire data set, including across strata.",
           call. = FALSE)
  }
  if (!is.null(reference)) {
    if (!is.atomic(reference) || !is.null(dim(reference)) || length(reference) != 1L ||
        is.na(reference) || !as.character(reference) %in% groups)
      stop("'reference' must name one observed treatment group.", call. = FALSE)
  }

  responses <- lapply(outcomes, function(column) {
    x <- data[[column]]
    if (!(is.logical(x) || (is.numeric(x) && !is.complex(x))) ||
        is.object(x) || !is.null(dim(x)) || length(x) != nrow(data))
      stop("Outcome column '", column,
           "' must be numeric 0/1 or logical, with NA for unobserved outcomes; recode factors and text explicitly.",
           call. = FALSE)
    observed <- !is.na(x)
    if (any(!is.finite(x[observed])) || any(!x[observed] %in% c(0, 1)))
      stop("Outcome column '", column, "' contains values other than 0, 1, or NA.", call. = FALSE)
    x
  })
  responses <- do.call(cbind, responses)
  observed <- rowSums(!is.na(responses))
  empty <- which(observed == 0L)
  if (length(empty))
    stop("Every subject must have at least one observed outcome. No observed outcomes in row(s): ",
         paste(head(empty, 10L), collapse = ", "),
         if (length(empty) > 10L) ", ..." else "", ". No rows were dropped.", call. = FALSE)

  cell <- (match(stratum_labels, strata) - 1L) * 2L + match(group_labels, groups)
  subject_totals <- tabulate(cell, nbins = 2L * length(strata))
  if (any(subject_totals == 0L))
    stop("Each stratum must contain subjects from both treatment groups.", call. = FALSE)
  positives <- rowSums(responses, na.rm = TRUE)
  # Categories 1:3 count bilateral subjects; 4:5 count unilateral subjects.
  category <- ifelse(observed == 2L, positives + 1L, positives + 4L)
  n <- matrix(tabulate((cell - 1L) * 5L + category, nbins = 10L * length(strata)),
              ncol = 5L, byrow = TRUE)
  colnames(n) <- c("m0", "m1", "m2", "u0", "u1")
  counts <- data.frame(stratum = rep(strata, each = 2L), group = rep(groups, length(strata)),
                       n, row.names = NULL, check.names = FALSE)
  strat_data(counts, reference = reference)
}
