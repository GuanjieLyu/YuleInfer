# Validate aggregated subject counts and retain an explicit treatment order.
yule_data <- function(data, reference = NULL) {
  .make_yule_data(data, reference = reference, integer = TRUE)
}

.make_yule_data <- function(data, reference = NULL, integer = TRUE) {
  if (!is.data.frame(data) || !nrow(data))
    stop("'data' must be a nonempty data frame.", call. = FALSE)
  if (anyNA(names(data)) || anyDuplicated(names(data)))
    stop("Column names must be nonmissing and unique.", call. = FALSE)
  if (!"group" %in% names(data))
    stop("A 'group' column is required.", call. = FALSE)
  if (!"stratum" %in% names(data)) data$stratum <- "1"
  has_bilateral <- c("m0", "m1", "m2") %in% names(data)
  has_unilateral <- c("u0", "u1") %in% names(data)
  if (any(has_bilateral) && !all(has_bilateral))
    stop("Provide all three bilateral counts m0, m1 and m2, or omit all three.",
         call. = FALSE)
  if (any(has_unilateral) && !all(has_unilateral))
    stop("Provide both u0 and u1, or omit both.", call. = FALSE)
  if (!any(has_bilateral) && !any(has_unilateral))
    stop("Provide bilateral counts (m0, m1, m2), unilateral counts (u0, u1), or both. ",
         "For one row per subject, use yule_import() first.",
         call. = FALSE)
  if (!any(has_bilateral)) { data$m0 <- 0; data$m1 <- 0; data$m2 <- 0 }
  if (!any(has_unilateral)) { data$u0 <- 0; data$u1 <- 0 }
  required <- c("stratum", "group", "m0", "m1", "m2")
  counts <- data[c(required, "u0", "u1")]
  for (column in c("stratum", "group")) {
    x <- counts[[column]]
    if (!is.atomic(x) || !is.null(dim(x)) || is.complex(x) || is.raw(x) ||
        length(x) != nrow(counts))
      stop("The '", column, "' column must be a vector of labels, with one value per row.",
           call. = FALSE)
    if (anyNA(x) || (is.numeric(x) && any(!is.finite(x))))
      stop("The '", column, "' column must contain nonmissing, finite labels.", call. = FALSE)
    x <- as.character(x)
    if (anyNA(x) || any(!nzchar(trimws(x))))
      stop("The '", column, "' column must contain nonmissing, nonempty labels.", call. = FALSE)
    counts[[column]] <- x
  }
  for (column in c("m0", "m1", "m2", "u0", "u1")) {
    x <- counts[[column]]
    if (!is.numeric(x) || is.complex(x) || !is.null(dim(x)) || length(x) != nrow(counts))
      stop("Count column '", column, "' must be a numeric vector with one value per row.",
           call. = FALSE)
    if (any(!is.finite(x)) || any(x < 0) ||
        (integer && any(x != floor(x))))
      stop("Counts must be finite, nonnegative integers: ", column, ".", call. = FALSE)
  }
  strata <- unique(counts$stratum); groups <- unique(counts$group)
  if (length(groups) != 2L)
    stop("Exactly two treatment groups are required.", call. = FALSE)
  if (!is.null(reference)) {
    if (!is.atomic(reference) || !is.null(dim(reference)) ||
        length(reference) != 1L || is.na(reference) ||
        !as.character(reference) %in% groups)
      stop("'reference' must name one observed treatment group.", call. = FALSE)
    groups <- c(as.character(reference), setdiff(groups, as.character(reference)))
  }
  if (anyDuplicated(counts[c("stratum", "group")]) ||
      any(table(counts$stratum) != 2L))
    stop("Each stratum must contain exactly one row for each treatment group.", call. = FALSE)
  counts <- counts[order(match(counts$stratum, strata), match(counts$group, groups)), ]
  rownames(counts) <- NULL
  counts$n_bilateral <- counts$m0 + counts$m1 + counts$m2
  counts$n_unilateral <- counts$u0 + counts$u1
  totals <- counts$n_bilateral + counts$n_unilateral
  if (any(totals <= 0) || !is.finite(sum(totals)))
    stop("Each stratum/group row must contain subjects with a finite total.", call. = FALSE)
  structure(list(counts = counts, strata = strata, groups = groups,
                 reference = groups[1L], J = length(strata), N = sum(totals)),
            class = "yule_data")
}

.as_yule_data <- function(data) {
  if (inherits(data, "yule_data")) return(data)
  yule_data(data)
}

.numeric_vector <- function(x, name) {
  if (!is.numeric(x) || !length(x) || !is.null(dim(x)) || any(!is.finite(x)))
    stop("'", name, "' must be a nonempty finite numeric vector.", call. = FALSE)
  x
}

.scalar <- function(x, name, lower = -Inf, upper = Inf, open = FALSE) {
  .numeric_vector(x, name)
  outside <- if (open) x <= lower | x >= upper else x < lower | x > upper
  if (length(x) != 1L || any(outside))
    stop("Invalid scalar '" , name, "'.", call. = FALSE)
  x
}

.count_matrix <- function(x, J, name) {
  if (!is.numeric(x) || any(!is.finite(x)) || any(x < 0) || any(x != floor(x)))
    stop("'", name, "' must contain finite nonnegative integer counts.", call. = FALSE)
  if (is.matrix(x)) {
    if (!identical(dim(x), c(as.integer(J), 2L)))
      stop("'", name, "' must have J rows and two columns.", call. = FALSE)
    return(x)
  }
  if (length(x) == 1L) return(matrix(x, J, 2L))
  if (length(x) == 2L) return(matrix(rep(x, J), J, 2L, byrow = TRUE))
  stop("'", name, "' must be a scalar, two group counts, or a J by 2 matrix.", call. = FALSE)
}

.yule_design <- function(baseline, d, association, n_bilateral, n_unilateral) {
  baseline <- .numeric_vector(baseline, "baseline")
  .scalar(d, "d", -1, 1, open = TRUE)
  J <- length(baseline)
  association <- .numeric_vector(association, "association")
  if (!length(association) %in% c(1L, J))
    stop("'association' must be a scalar or one value per stratum.", call. = FALSE)
  association <- rep(association, length.out = J)
  pi <- cbind(baseline, baseline + d)
  if (any(pi <= 0 | pi >= 1) || any(abs(association) >= 1))
    stop("The design requires interior margins and Yule coefficients.", call. = FALSE)
  n <- .count_matrix(n_bilateral, J, "n_bilateral")
  u <- .count_matrix(n_unilateral, J, "n_unilateral")
  if (any(n + u <= 0) || !is.finite(sum(n + u)))
    stop("Each stratum/group must have a positive finite subject total.", call. = FALSE)
  labels <- names(baseline)
  if (is.null(labels) || anyNA(labels) || any(!nzchar(labels)) || anyDuplicated(labels))
    labels <- as.character(seq_len(J))
  list(J = J, baseline = baseline, d = d, association = association,
       pi = pi, n = n, u = u, N = sum(n + u), strata = labels)
}
