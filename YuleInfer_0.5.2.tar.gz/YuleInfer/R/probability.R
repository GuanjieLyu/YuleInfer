# Stable inverse of Yule's colligation coefficient, including negative association.
.yule_prob <- function(pi, association, derivatives = TRUE) {
  one_minus <- 1 - association
  one_plus <- 1 + association
  P <- pi * (1 - pi)
  D <- one_minus^2 + 16 * association * P
  negative <- association < 0
  # The alternative discriminant avoids cancellation near negative perfect
  # association. Evaluate it only where it is needed.
  if (any(negative)) D[negative] <- one_plus[negative]^2 -
    4 * association[negative] * (1 - 2 * pi[negative])^2
  r <- 2 * P * one_minus / (one_minus + sqrt(D))
  theta <- (one_plus / one_minus)^2
  product <- theta * r^2
  distance <- abs(1 - 2 * pi)
  small <- 2 * product / (distance + sqrt(distance^2 + 4 * product))
  # Select the complementary cells without constructing two ifelse results.
  # The arithmetic and names match the original stable inverse exactly.
  p0 <- small + distance
  q <- small
  names(p0) <- names(q) <- names(pi)
  upper <- which(pi > .5)
  if (length(upper)) {
    p0[upper] <- small[upper]
    q[upper] <- small[upper] + distance[upper]
  }
  p1 <- 2 * r
  p <- cbind(p0 = p0, p1 = p1, p2 = q)
  # These expressions avoid subtracting nearly equal derivative terms.
  w0 <- p1 * q; w1 <- 4 * p0 * q; w2 <- p0 * p1
  denominator <- w0 + w1 + w2
  qa <- 4 * p0 * q * (p1 / denominator) /
    (one_minus * one_plus)
  if (!derivatives) return(list(p = p, q = q, qa = qa))
  pp <- cbind(-(w1 + 2 * w2), 2 * (w2 - w0), 2 * w0 + w1) / denominator
  pa <- cbind(qa, -2 * qa, qa)
  list(p = p, q = q, qp = pp[, 3L], qa = qa, pp = pp, pa = pa)
}

yule_probabilities <- function(pi, association) {
  pi <- .numeric_vector(pi, "pi")
  association <- .numeric_vector(association, "association")
  length_out <- max(length(pi), length(association))
  if (!length(pi) %in% c(1L, length_out) ||
      !length(association) %in% c(1L, length_out))
    stop("Arguments must have equal lengths, or one must be a scalar.", call. = FALSE)
  pi <- rep(pi, length.out = length_out)
  association <- rep(association, length.out = length_out)
  if (any(pi <= 0 | pi >= 1) || any(abs(association) >= 1))
    stop("Require 0 < pi < 1 and -1 < association < 1.", call. = FALSE)
  pr <- .yule_prob(pi, association, derivatives = FALSE)
  if (any(!is.finite(pr$p)) || any(pr$p <= 0))
    stop("The requested probabilities exceed numerical precision.", call. = FALSE)
  data.frame(pi = pi, association = association, p0 = pr$p[, 1L],
             p1 = pr$p[, 2L], p2 = pr$p[, 3L], q = pr$q, row.names = NULL)
}

yule_simulate <- function(baseline, d, association, n_bilateral,
                          n_unilateral = 0, seed = NULL) {
  design <- .yule_design(baseline, d, association, n_bilateral, n_unilateral)
  if (!is.null(seed)) {
    .scalar(seed, "seed", 0, .Machine$integer.max)
    if (seed != floor(seed)) stop("'seed' must be an integer.", call. = FALSE)
    had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    on.exit(if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv)
            else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
              rm(".Random.seed", envir = .GlobalEnv), add = TRUE)
    set.seed(seed)
  }
  pi <- as.vector(t(design$pi)); n <- as.vector(t(design$n))
  u <- as.vector(t(design$u))
  pr <- .yule_prob(pi, rep(design$association, each = 2L), derivatives = FALSE)
  if (any(!is.finite(pr$p)) || any(pr$p <= 0))
    stop("The requested probabilities exceed numerical precision.", call. = FALSE)
  m <- t(vapply(seq_along(pi), function(k)
    as.numeric(stats::rmultinom(1L, n[k], pr$p[k, ])), numeric(3L)))
  u1 <- stats::rbinom(length(pi), u, pi)
  data.frame(stratum = rep(design$strata, each = 2L), group = rep(c("1", "2"), design$J),
             m0 = m[, 1L], m1 = m[, 2L], m2 = m[, 3L], u0 = u - u1, u1 = u1)
}
