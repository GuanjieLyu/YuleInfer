# Model-neutral entry points share data validation and inference with the
# original Yule interface. Native association is always shared within strata.
.strat_model <- function(model = c("yule", "dallal", "rosner", "donner")) {
  match.arg(model)
}

.fit_model <- function(object) {
  if (is.null(object$model)) "yule" else .strat_model(object$model)
}

.model_label <- function(model) {
  c(yule = "Yule", dallal = "Dallal", rosner = "Rosner", donner = "Donner")[[model]]
}

.association_label <- function(model) {
  c(yule = "Yule colligation coefficient",
    dallal = "conditional response probability (gamma)",
    rosner = "conditional-to-marginal risk ratio (R)",
    donner = "Pearson correlation (rho)")[[model]]
}

# Private immutable preparation for one confidence-set inversion. The caller
# prepares the exact data and fitting controls used by every constrained fit.
.model_fit_context <- function(data, model, control) {
  model <- .strat_model(model)
  data <- .as_yule_data(data)
  ctl <- .yule_fit_control(control)
  ct <- data$counts
  counts <- .yule_fit_counts(data)
  if (model != "yule") counts$m <- cbind(counts$m0, counts$m1, counts$m2)
  active <- which(counts$n_bilateral[counts$odd] + counts$n_bilateral[counts$even] > 0)
  constant <- sum(lgamma(ct$n_bilateral + 1) - lgamma(ct$m0 + 1) -
    lgamma(ct$m1 + 1) - lgamma(ct$m2 + 1) + lgamma(ct$n_unilateral + 1) -
    lgamma(ct$u0 + 1) - lgamma(ct$u1 + 1))
  list(data = data, model = model, controls = ctl, counts = counts, active = active,
    initial_pi = (ct$m1 + 2 * ct$m2 + ct$u1 + .5) /
      (2 * ct$n_bilateral + ct$n_unilateral + 1),
    initial_association = if (model == "yule")
      .yule_initial(data, active)$association else rep(NA_real_, data$J),
    constant = constant)
}

.model_fit <- function(data, model = "yule", d = NULL, start = NULL,
                       control = list(), prepared = NULL, profile = FALSE) {
  model <- .strat_model(model)
  if (inherits(start, "yule_fit") && .fit_model(start) != model)
    stop("The starting fit must use the same association model.", call. = FALSE)
  result <- if (model == "yule")
    .yule_fit(data, d = d, start = start, control = control,
              prepared = prepared, profile = profile) else
    .classical_fit(data, model = model, d = d, start = start, control = control,
                   prepared = prepared, profile = profile)
  result$model <- model
  result
}

strat_data <- function(data, reference = NULL) {
  result <- yule_data(data, reference = reference)
  class(result) <- c("strat_data", "yule_data")
  result
}

strat_fit <- function(data, d = NULL, control = list(),
                      model = c("yule", "dallal", "rosner", "donner")) {
  model <- .strat_model(model)
  if (inherits(data, "yule_data"))
    data <- .make_yule_data(data$counts, reference = data$reference, integer = TRUE)
  result <- .model_fit(data, model = model, d = d, control = control)
  class(result) <- c("strat_fit", "yule_fit")
  result
}

strat_test <- function(object, d0 = 0, method = c("LR", "score", "Wald")) {
  result <- yule_test(object, d0 = d0, method = match.arg(method))
  result$data.name <- paste(deparse(substitute(object)), collapse = " ")
  result
}

strat_confint <- function(object, level = .95,
                          method = c("LR", "score", "Wald"), control = list()) {
  result <- yule_confint(object, level = level, method = match.arg(method),
                         control = control)
  class(result) <- c("strat_ci", "yule_ci")
  result
}

strat_probabilities <- function(pi, association,
                                model = c("yule", "dallal", "rosner", "donner")) {
  model <- .strat_model(model)
  pi <- .numeric_vector(pi, "pi")
  association <- .numeric_vector(association, "association")
  length_out <- max(length(pi), length(association))
  if (!length(pi) %in% c(1L, length_out) ||
      !length(association) %in% c(1L, length_out))
    stop("Arguments must have equal lengths, or one must be a scalar.", call. = FALSE)
  pi <- rep(pi, length.out = length_out)
  association <- rep(association, length.out = length_out)
  if (any(pi <= 0 | pi >= 1))
    stop("Require 0 < pi < 1.", call. = FALSE)
  if (model == "yule" && any(abs(association) >= 1))
    stop("Require -1 < Yule association < 1.", call. = FALSE)
  pr <- .model_prob(pi, association, model, derivatives = FALSE)
  if (any(!is.finite(pr$p)) || any(pr$p <= 0))
    stop("The association and margins must give strictly positive cell probabilities; ",
         "check model feasibility and numerical precision.", call. = FALSE)
  result <- data.frame(pi = pi, association = association, p0 = pr$p[, 1L],
                       p1 = pr$p[, 2L], p2 = pr$p[, 3L], q = pr$q,
                       row.names = NULL)
  attr(result, "model") <- model
  result
}

.strat_design <- function(baseline, d, association, n_bilateral, n_unilateral,
                          model) {
  association <- .numeric_vector(association, "association")
  design <- .yule_design(baseline, d, 0, n_bilateral, n_unilateral)
  if (!length(association) %in% c(1L, design$J))
    stop("'association' must be a scalar or one value per stratum.", call. = FALSE)
  design$association <- rep(association, length.out = design$J)
  design$model <- model
  # Both treatment margins must admit the same native association value.
  strat_probabilities(as.vector(t(design$pi)),
                       rep(design$association, each = 2L), model = model)
  design
}

strat_simulate <- function(baseline, d, association, n_bilateral,
                           n_unilateral = 0, seed = NULL,
                           model = c("yule", "dallal", "rosner", "donner")) {
  model <- .strat_model(model)
  design <- .strat_design(baseline, d, association, n_bilateral, n_unilateral, model)
  if (!is.null(seed)) {
    .scalar(seed, "seed", 0, .Machine$integer.max)
    if (seed != floor(seed)) stop("'seed' must be an integer.", call. = FALSE)
    had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    on.exit(if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv)
            else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
              rm(".Random.seed", envir = .GlobalEnv), add = TRUE)
    set.seed(seed)
  }
  pi <- as.vector(t(design$pi)); n <- as.vector(t(design$n))
  u <- as.vector(t(design$u))
  pr <- .model_prob(pi, rep(design$association, each = 2L), model,
                    derivatives = FALSE)
  m <- t(vapply(seq_along(pi), function(k)
    as.numeric(stats::rmultinom(1L, n[k], pr$p[k, ])), numeric(3L)))
  u1 <- stats::rbinom(length(pi), u, pi)
  data.frame(stratum = rep(design$strata, each = 2L),
             group = rep(c("1", "2"), design$J), m0 = m[, 1L],
             m1 = m[, 2L], m2 = m[, 3L], u0 = u - u1, u1 = u1)
}

strat_power <- function(baseline, association, n_bilateral, n_unilateral = 0,
                        d0 = 0, h = NULL, delta = NULL, alpha = .05,
                        model = c("yule", "dallal", "rosner", "donner")) {
  model <- .strat_model(model)
  if (model == "yule") {
    result <- yule_power(baseline, association, n_bilateral, n_unilateral,
                         d0 = d0, h = h, delta = delta, alpha = alpha)
    result$model <- model
    design <- attr(result, "design")
    design$model <- model
    attr(result, "design") <- design
    return(result)
  }
  .scalar(alpha, "alpha", 0, 1, open = TRUE)
  design <- .strat_design(baseline, d0, association, n_bilateral,
                          n_unilateral, model)
  if (!is.null(h) && !is.null(delta))
    stop("Specify either 'h' or 'delta', not both.", call. = FALSE)
  if (is.null(h) && is.null(delta)) h <- 0
  if (is.null(h)) {
    delta <- .numeric_vector(delta, "delta")
    h <- sqrt(design$N) * delta
  } else {
    h <- .numeric_vector(h, "h")
    delta <- h / sqrt(design$N)
  }
  # Check the finite-N native-model path, in addition to its local limit.
  for (change in delta) {
    strat_probabilities(as.vector(t(cbind(design$baseline,
                                          design$baseline + d0 + change))),
                         rep(design$association, each = 2L), model = model)
  }
  active <- which(rowSums(design$n) > 0)
  association <- design$association
  association[setdiff(seq_len(design$J), active)] <- NA_real_
  information <- .classical_information(as.vector(t(design$pi)), association,
    as.vector(t(design$n)), as.vector(t(design$u)), active, design$strata,
    model = model)$efficient
  if (!is.finite(information) || information <= 0)
    stop("The design has unusable efficient information.", call. = FALSE)
  per_subject <- information / design$N
  lambda <- h^2 * per_subject
  result <- data.frame(N = design$N, d0 = d0, delta = delta, h = h,
    total_information = information, information_per_subject = per_subject,
    lambda = lambda, power = stats::pchisq(stats::qchisq(alpha, 1L, lower.tail = FALSE),
      df = 1L, ncp = lambda, lower.tail = FALSE), alpha = alpha, model = model)
  attr(result, "design") <- design
  result
}
