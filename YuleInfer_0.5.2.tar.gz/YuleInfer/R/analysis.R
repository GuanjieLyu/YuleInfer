# One practitioner-facing analysis keeps the fitted model, its test, and the
# actual confidence set together. Numerical inference remains in the existing
# fitting/testing engine; this file only validates, organizes, and prints it.

.yule_analysis_capture <- function(expr) {
  warnings <- character()
  value <- withCallingHandlers(tryCatch(force(expr), error = identity),
    warning = function(w) warnings <<- c(warnings, conditionMessage(w)))
  failed <- inherits(value, "error")
  list(value = if (failed) NULL else value,
       error = if (failed) conditionMessage(value) else "",
       warnings = unique(warnings))
}

#' Analyze a common risk difference in one call
#'
#' @param data A count data frame, or a validated strat_data/yule_data object.
#' @param reference The reference group. NULL preserves an existing data
#'   object's reference, or uses the first group in a count data frame.
#' @param model One shared association restriction.
#' @param d0 The null common risk difference, strictly between -1 and 1.
#' @param method One method used for both the test and confidence set.
#' @param conf.level Confidence level, strictly between zero and one.
#' @param control Named controls passed to strat_fit.
#' @param ci_control Named controls passed to strat_confint.
#' @return A yule_analysis object with fit, test, confint, and diagnostics.
#' @export
yule_analyze <- function(data, reference = NULL,
                         model = c("yule", "dallal", "rosner", "donner"),
                         d0 = 0, method = c("LR", "score", "Wald"),
                         conf.level = 0.95, control = list(), ci_control = list()) {
  call <- match.call()
  model <- .strat_model(model)
  method <- match.arg(method)
  .yule_check_null(d0)
  .scalar(conf.level, "conf.level", 0, 1, open = TRUE)
  .yule_fit_control(control)
  settings <- .yule_ci_control(ci_control)
  .yule_fit_control(settings$fit.control)
  if (inherits(data, "yule_data")) {
    if (is.null(reference)) reference <- data$reference
    data <- data$counts
  }
  prepared <- strat_data(data, reference = reference)

  # Invalid public inputs raise errors above. Numerical failures below remain
  # visible in the analysis, so a boundary estimate is not mistaken for a
  # successful test or a complete confidence set. Warnings are also retained
  # while preserving the underlying functions' ordinary warning behavior.
  fitted <- .yule_analysis_capture(strat_fit(prepared, model = model,
                                            control = control))
  fit <- fitted$value
  if (is.null(fit)) {
    unavailable <- list(value = NULL,
      error = paste0("Inference unavailable because fitting failed: ", fitted$error),
      warnings = character())
    tested <- interval <- unavailable
  } else {
    tested <- .yule_analysis_capture(strat_test(fit, d0 = d0, method = method))
    interval <- .yule_analysis_capture(strat_confint(fit, level = conf.level,
                                                    method = method, control = ci_control))
  }
  structure(list(call = call, model = model, method = method, d0 = d0,
    conf.level = conf.level, reference = prepared$groups[1L],
    comparison = prepared$groups[2L],
    direction = paste(prepared$groups[2L], "minus", prepared$groups[1L]),
    n_subjects = prepared$N, n_strata = prepared$J,
    fit = fit, test = tested$value, confint = interval$value,
    controls = list(fit = control, confidence_set = ci_control),
    diagnostics = list(
      fit = list(error = fitted$error, warnings = fitted$warnings,
                 convergence = if (is.null(fit)) NULL else fit$convergence),
      test = list(error = tested$error, warnings = tested$warnings),
      confint = list(error = interval$error, warnings = interval$warnings))),
    class = "yule_analysis")
}

.yule_analysis_results <- function(x) {
  fit <- x$fit; test <- x$test; ci <- x$confint
  regular <- !is.null(fit) && isTRUE(fit$convergence$regular)
  scalar <- function(z) if (is.numeric(z) && length(z) == 1L) unname(z) else NA_real_
  message <- function(z) {
    z <- as.character(z)
    paste(unique(z[!is.na(z) & nzchar(z)]), collapse = "; ")
  }
  p <- if (is.null(test)) NA_real_ else scalar(test$p.value)
  statistic <- if (is.null(test)) NA_real_ else scalar(test$statistic)
  test_available <- regular && is.finite(p) && p >= 0 && p <= 1
  intervals <- if (is.null(ci)) matrix(numeric(), 0L, 2L,
    dimnames = list(NULL, c("lower", "upper"))) else ci$intervals
  complete <- !is.null(ci) && isTRUE(ci$complete)
  ci_available <- regular && complete && is.matrix(intervals) &&
    ncol(intervals) == 2L && all(is.finite(intervals)) &&
    all(intervals[, 1L] <= intervals[, 2L])
  single <- ci_available && nrow(intervals) == 1L
  estimate <- if (is.null(fit)) NA_real_ else scalar(fit$d)
  fit_status <- if (is.null(fit)) "fit_error" else message(fit$convergence$status)
  fit_message <- if (is.null(fit)) message(x$diagnostics$fit$error) else
    message(fit$convergence$reason)
  ci_message <- message(c(x$diagnostics$confint$error,
    if (!is.null(ci)) ci$diagnostics$messages))
  if (!ci_available && !nzchar(ci_message))
    ci_message <- if (is.null(ci)) "No confidence set was returned." else
      "The confidence set is incomplete or contains unresolved endpoints."
  result <- data.frame(model = x$model, method = x$method,
    reference = x$reference, comparison = x$comparison, direction = x$direction,
    n_subjects = x$n_subjects, n_strata = x$n_strata,
    estimate = estimate, percentage_points = 100 * estimate,
    std.error = if (regular) scalar(fit$se) else NA_real_,
    null.value = x$d0, statistic = if (test_available) statistic else NA_real_,
    p.value = if (test_available) p else NA_real_, test_available = test_available,
    conf.level = x$conf.level,
    lower = if (single) intervals[1L, 1L] else NA_real_,
    upper = if (single) intervals[1L, 2L] else NA_real_,
    width = if (ci_available) sum(intervals[, 2L] - intervals[, 1L]) else NA_real_,
    ci_available = ci_available, ci_complete = complete,
    ci_connected = if (is.null(ci)) NA else ci$connected,
    ci_components = if (is.null(ci)) NA_integer_ else nrow(intervals),
    fit_regular = regular, fit_status = fit_status, fit_message = fit_message,
    test_message = message(x$diagnostics$test$error), ci_message = ci_message,
    stringsAsFactors = FALSE)
  # A list column preserves every original component, including unresolved
  # endpoints. It never replaces a disconnected set by its enclosing interval.
  result$intervals <- I(list(intervals))
  result
}

as.data.frame.yule_analysis <- function(x, row.names = NULL, optional = FALSE, ...) {
  result <- .yule_analysis_results(x)
  if (!is.null(row.names)) rownames(result) <- row.names
  result
}

print.yule_analysis <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  result <- .yule_analysis_results(x)
  number <- function(z) format(z, digits = digits, trim = TRUE)
  cat("YuleInfer common risk difference analysis\n")
  cat("Model:", .model_label(x$model), "  Method:", x$method, "\n")
  cat("Direction:", x$direction, "\n")
  cat("Subjects:", number(x$n_subjects), "  Strata:", x$n_strata, "\n")
  if (is.finite(result$estimate))
    cat("Risk difference: ", number(result$estimate),
        " (", number(result$percentage_points), " percentage points)\n", sep = "")
  cat("Fit status:", result$fit_status, "\n")
  if (!result$fit_regular) cat(result$fit_message, "\n")
  if (result$test_available) {
    cat(x$method, " test of RD = ", number(x$d0), ": p = ",
        format.pval(result$p.value, digits = digits), "\n", sep = "")
  } else cat("Test unavailable:", result$test_message, "\n")
  label <- paste0(number(100 * x$conf.level), "% ", x$method)
  if (result$ci_available && result$ci_components == 1L) {
    cat(label, " confidence interval: [", number(result$lower), ", ", number(result$upper), "]\n", sep = "")
    cat("In percentage points: [", number(100 * result$lower), ", ",
        number(100 * result$upper), "]\n", sep = "")
  } else if (result$ci_available) {
    cat(label, " confidence set: ", result$ci_components, " separate components\n", sep = "")
    for (i in seq_len(result$ci_components)) {
      z <- x$confint$intervals[i, ]
      cat("  [", number(z[1L]), ", ", number(z[2L]), "]  (", number(100 * z[1L]),
          " to ", number(100 * z[2L]), " percentage points)\n", sep = "")
    }
  } else cat(label, " confidence set unavailable: ", result$ci_message, "\n", sep = "")
  if (result$ci_available && nzchar(result$ci_message))
    cat("Confidence-set diagnostic:", result$ci_message, "\n")
  warnings <- unique(unlist(lapply(x$diagnostics, `[[`, "warnings"), use.names = FALSE))
  if (length(warnings)) cat("Recorded warnings:", paste(warnings, collapse = "; "), "\n")
  invisible(x)
}
