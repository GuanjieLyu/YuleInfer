coef.yule_fit <- function(object, ...) object$coefficients

logLik.yule_fit <- function(object, ...) {
  structure(object$logLik, df = object$parameter_count,
            nobs = object$data$N, class = "logLik")
}

nobs.yule_fit <- function(object, ...) object$data$N

fitted.yule_fit <- function(object, ...) {
  p <- object$probabilities
  stats::setNames(p$pi, paste(p$stratum, p$group, sep = ":"))
}

vcov.yule_fit <- function(object, ...) {
  if (!isTRUE(object$convergence$regular))
    stop("Covariance estimation requires a regular interior fit.", call. = FALSE)
  I <- object$information; J <- object$data$J
  if (.fit_model(object) != "yule") {
    used <- if (object$fixed) seq.int(2L, nrow(I)) else seq_len(nrow(I))
    block <- I[used, used, drop = FALSE]
    scale <- sqrt(diag(block))
    inverse <- tryCatch(chol2inv(chol(block / outer(scale, scale))) /
                         outer(scale, scale), error = function(e) NULL)
    if (is.null(inverse) || any(!is.finite(inverse)))
      stop("The expected information cannot be inverted reliably.", call. = FALSE)
    V <- matrix(0, nrow(I), ncol(I), dimnames = dimnames(I))
    V[used, used] <- inverse
    return(V)
  }
  V <- matrix(0, nrow(I), ncol(I), dimnames = dimnames(I))
  b <- seq_len(J) + 1L; a <- setdiff(seq_len(nrow(I)), c(1L, b))
  # Orthogonality gives a stable closed inverse without ill-scaled joint solves.
  V[b, b] <- diag(1 / diag(I)[b], nrow = J)
  if (!object$fixed) {
    variance <- 1 / object$efficient_information
    w <- I[1L, b] / diag(I)[b]
    V[1L, 1L] <- variance
    V[1L, b] <- V[b, 1L] <- -w * variance
    V[b, b] <- V[b, b] + outer(w, w) * variance
  }
  if (length(a)) V[a, a] <- diag(1 / diag(I)[a], nrow = length(a))
  V
}

summary.yule_fit <- function(object, ...) {
  se <- if (isTRUE(object$convergence$regular)) sqrt(diag(vcov.yule_fit(object)))
        else rep(NA_real_, length(object$coefficients))
  structure(list(coefficients = cbind(Estimate = object$coefficients, SE = se),
                 d = object$d, se = object$se, logLik = object$logLik,
                 strata = object$data$J, subjects = object$data$N,
                 groups = object$data$groups, fixed = object$fixed,
                 model = .fit_model(object), convergence = object$convergence),
            class = "summary.yule_fit")
}

print.yule_data <- function(x, ...) {
  cat("YuleInfer count data:", x$J, "strata,", format(x$N), "subjects\n")
  cat("Risk difference:", x$groups[2L], "minus", x$groups[1L], "\n")
  print(x$counts, row.names = FALSE, ...)
  invisible(x)
}

as.data.frame.yule_data <- function(x, row.names = NULL, optional = FALSE, ...) {
  as.data.frame(x$counts, row.names = row.names, optional = optional, ...)
}

print.yule_fit <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  cat("YuleInfer", .model_label(.fit_model(x)), "common risk difference fit\n")
  cat("Association:", .association_label(.fit_model(x)), "\n")
  cat("Direction:", x$data$groups[2L], "minus", x$data$groups[1L], "\n")
  cat("RD:", format(x$d, digits = digits),
      if (x$fixed) "(fixed)" else paste0("  SE: ", format(x$se, digits = digits)), "\n")
  cat("Subjects:", format(x$data$N), "  Strata:", x$data$J,
      "  Log likelihood:", format(x$logLik, digits = digits), "\n")
  cat("Status:", x$convergence$status, "\n")
  if (!isTRUE(x$convergence$regular)) cat(x$convergence$reason, "\n")
  invisible(x)
}

print.summary.yule_fit <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  cat("YuleInfer", .model_label(.fit_model(x)), "common risk difference model\n")
  cat("Association:", .association_label(.fit_model(x)), "\n")
  cat("Direction:", x$groups[2L], "minus", x$groups[1L], "\n")
  print(x$coefficients, digits = digits, ...)
  cat("\nSubjects:", format(x$subjects), "  Strata:", x$strata,
      "  Log likelihood:", format(x$logLik, digits = digits), "\n")
  cat("Status:", x$convergence$status, "\n")
  if (!isTRUE(x$convergence$regular)) cat(x$convergence$reason, "\n")
  invisible(x)
}

confint.yule_fit <- function(object, parm = "d", level = .95,
                             method = c("LR", "score", "Wald"), ...) {
  if (length(parm) != 1L || !as.character(parm) %in% c("d", "1"))
    stop("Confidence sets are available for the common risk difference ('d').", call. = FALSE)
  if (inherits(object, "strat_fit"))
    strat_confint(object, level = level, method = match.arg(method), ...) else
    yule_confint(object, level = level, method = match.arg(method), ...)
}

print.yule_ci <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  cat(format(100 * x$level), "% ", .model_label(.fit_model(x)), " ", x$method,
      " confidence set for the common risk difference\n", sep = "")
  print(x$intervals, digits = digits, ...)
  cat("Complete at reported numerical resolution:", isTRUE(x$complete), "\n")
  if (length(x$diagnostics$messages))
    cat(paste(x$diagnostics$messages, collapse = " "), "\n")
  invisible(x)
}

as.data.frame.yule_ci <- function(x, row.names = NULL, optional = FALSE, ...) {
  result <- as.data.frame(x$intervals, row.names = row.names, optional = optional, ...)
  result$method <- rep(x$method, nrow(result))
  result$level <- rep(x$level, nrow(result))
  result$complete <- rep(x$complete, nrow(result))
  result
}
