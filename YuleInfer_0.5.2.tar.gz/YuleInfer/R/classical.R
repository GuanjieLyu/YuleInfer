# Common-RD likelihoods with a shared native classical association per stratum.
.classical_model <- function(model) {
  if (!is.character(model) || length(model) != 1L || is.na(model) ||
      !tolower(model) %in% c("dallal", "rosner", "donner"))
    stop("model must be dallal, rosner or donner.", call. = FALSE)
  tolower(model)
}

.model_prob <- function(pi, association, model, derivatives = TRUE) {
  length_out <- max(length(pi), length(association))
  if (!length(pi) %in% c(1L, length_out) ||
      !length(association) %in% c(1L, length_out))
    stop("Arguments must have equal lengths, or one must be a scalar.", call. = FALSE)
  pi <- rep(pi, length.out = length_out)
  association <- rep(association, length.out = length_out)
  if (is.character(model) && length(model) == 1L && !is.na(model) &&
      tolower(model) == "yule")
    return(.yule_prob(pi, association, derivatives = derivatives))
  model <- .classical_model(model)
  .classical_prob(pi, association, model, derivatives)
}

# The fitting engine has already validated the model and vector lengths.
# Keep its probability arithmetic identical to the checked public path.
.classical_prob <- function(pi, association, model, derivatives = TRUE) {
  P <- pi * (1 - pi)
  if (model == "dallal") {
    q <- association * pi
    p0 <- 1 - 2 * pi + q
    high <- pi > .5
    p0[high] <- pi[high] * (association[high] - (2 - 1 / pi[high]))
    p1 <- 2 * pi * (1 - association)
    qp <- association; qa <- pi
  } else if (model == "rosner") {
    q <- association * pi^2
    p0 <- 1 - 2 * pi + q
    high <- pi > .5
    p0[high] <- pi[high]^2 *
      (association[high] - (2 * pi[high] - 1) / pi[high]^2)
    p1 <- 2 * pi * (1 - association * pi)
    qp <- 2 * association * pi; qa <- pi^2
  } else {
    q <- pi * (pi + association * (1 - pi))
    p0 <- (1 - pi) * (1 - pi + association * pi)
    p1 <- 2 * P * (1 - association)
    qp <- 2 * pi + association * (1 - 2 * pi); qa <- P
  }
  p <- cbind(p0 = p0, p1 = p1, p2 = q)
  if (!derivatives) return(list(p = p, q = q, qa = qa))
  list(p = p, q = q, qp = qp, qa = qa,
       pp = cbind(qp - 2, 2 - 2 * qp, qp),
       pa = cbind(qa, -2 * qa, qa))
}

# The bounds are the intersection of the two groups' strictly positive-table
# domains. Averaged derivatives at ties are only an optimizer coordinate;
# inference and Fisher polishing use the smooth natural likelihood directly.
.classical_bounds <- function(pi, model, derivatives = TRUE, odd = NULL,
                              compact = FALSE, common_d = NULL) {
  J <- length(pi) / 2L
  if (is.null(odd)) odd <- seq.int(1L, 2L * J, 2L)
  p1 <- pi[odd]; p2 <- pi[odd + 1L]
  if (model != "donner") {
    # Optimization and encoding know the common difference, so the larger
    # group's margin is already identified. General callers retain pmax.
    maximum <- if (is.null(common_d)) pmax(p1, p2) else
      if (common_d >= 0) p2 else p1
  }
  if (model == "dallal") {
    L <- pmax(0, 2 - 1 / maximum); H <- rep(1, J)
    if (!derivatives) return(list(lower = L, upper = H))
    w1 <- as.numeric(p1 == maximum); w2 <- as.numeric(p2 == maximum)
    total <- w1 + w2; w1 <- w1 / total; w2 <- w2 / total
    derivative <- numeric(J)
    high <- maximum > .5; tie <- maximum == .5
    derivative[high] <- 1 / maximum[high]^2
    derivative[tie] <- .5 / maximum[tie]^2
    lp1 <- w1 * derivative; lp2 <- w2 * derivative
    hp1 <- hp2 <- numeric(J)
  } else if (model == "rosner") {
    L <- pmax(0, (2 * maximum - 1) / maximum^2); H <- 1 / maximum
    if (!derivatives) return(list(lower = L, upper = H))
    w1 <- as.numeric(p1 == maximum); w2 <- as.numeric(p2 == maximum)
    total <- w1 + w2; w1 <- w1 / total; w2 <- w2 / total
    derivative <- numeric(J)
    high <- maximum > .5; tie <- maximum == .5
    derivative[high] <- 2 * (1 - maximum[high]) / maximum[high]^3
    derivative[tie] <- (1 - maximum[tie]) / maximum[tie]^3
    lp1 <- w1 * derivative; lp2 <- w2 * derivative
    hp1 <- -w1 / maximum^2; hp2 <- -w2 / maximum^2
  } else {
    if (!is.null(names(pi))) { names(p1) <- NULL; names(p2) <- NULL }
    lower1 <- -p1 / (1 - p1); high <- p1 > .5
    lower1[high] <- -(1 - p1[high]) / p1[high]
    lower2 <- -p2 / (1 - p2); high <- p2 > .5
    lower2[high] <- -(1 - p2[high]) / p2[high]
    L <- pmax(lower1, lower2); H <- rep(1, J)
    if (!derivatives) return(list(lower = L, upper = H))
    w1 <- as.numeric(lower1 == L); w2 <- as.numeric(lower2 == L)
    total <- w1 + w2; w1 <- w1 / total; w2 <- w2 / total
    derivative1 <- derivative2 <- numeric(J)
    low <- p1 < .5; high <- p1 > .5
    derivative1[low] <- -1 / (1 - p1[low])^2
    derivative1[high] <- 1 / p1[high]^2
    low <- p2 < .5; high <- p2 > .5
    derivative2[low] <- -1 / (1 - p2[low])^2
    derivative2[high] <- 1 / p2[high]^2
    lp1 <- w1 * derivative1; lp2 <- w2 * derivative2
    hp1 <- hp2 <- numeric(J)
  }
  # Decoding needs only the derivative columns, avoiding construction and
  # immediate subsetting of four small matrices at every optimizer evaluation.
  if (compact) return(list(lower = L, upper = H, lp1 = lp1, lp2 = lp2,
                           hp1 = hp1, hp2 = hp2))
  list(lower = L, upper = H,
       lower_derivative = matrix(c(lp1, lp2), J, 2L),
       upper_derivative = matrix(c(hp1, hp2), J, 2L))
}

.classical_decode <- function(x, J, active, model, d = NULL, odd = NULL) {
  z <- .yule_decode(x, J, integer(), d)
  if (!length(active)) {
    z$ab <- numeric(); z$ad <- numeric()
    return(z)
  }
  bounds <- .classical_bounds(z$pi, model, odd = odd, compact = TRUE,
                              common_d = z$d)
  s <- stats::plogis(x[as.integer(z$free) + J + seq_along(active)])
  width <- bounds$upper[active] - bounds$lower[active]
  z$association[active] <- bounds$lower[active] + width * s
  z$ar <- width * s * (1 - s)
  ap1 <- bounds$lp1[active] * (1 - s) + bounds$hp1[active] * s
  ap2 <- bounds$lp2[active] * (1 - s) + bounds$hp2[active] * s
  z$ab <- ap1 + ap2; z$ad <- ap2
  z
}

.classical_encode <- function(d, baseline, association, active, model,
                              fixed = NULL, safe = TRUE) {
  if (safe) {
    margin <- .yule_encode(d, baseline, rep(NA_real_, length(baseline)),
                           integer(), fixed)
    z <- .yule_decode(margin, length(baseline), integer(), fixed)
    baseline <- z$baseline; d <- z$d
  } else {
    margin <- c(if (is.null(fixed)) atanh(d),
                (stats::qlogis(baseline) + stats::qlogis(baseline + d)) / 2)
  }
  bounds <- .classical_bounds(as.vector(rbind(baseline, baseline + d)), model,
                              derivatives = FALSE, common_d = d)
  s <- (association[active] - bounds$lower[active]) /
    (bounds$upper[active] - bounds$lower[active])
  if (safe) s <- pmax(1e-8, pmin(1 - 1e-8, s))
  c(margin, stats::qlogis(s))
}

.classical_probability <- function(pi, association, active, model) {
  a <- rep(association, each = 2L)
  inactive <- is.na(a)
  # No bilateral observations identify an association in an inactive stratum.
  # Independent placeholder tables keep zero-weight likelihood terms finite.
  a[inactive] <- switch(model, dallal = pi[inactive], rosner = 1, donner = 0)
  .classical_prob(pi, a, model)
}

.classical_components <- function(pi, pr, n, u, active) {
  J <- length(pi) / 2L
  odd <- seq.int(1L, 2L * J, 2L); even <- odd + 1L
  # These dense three-column numeric matrices have no row names in the
  # fitting engine. The same base summation kernel avoids general checks.
  A <- n * .rowSums(pr$pp^2 / pr$p, 2L * J, 3L) + u / (pi * (1 - pi))
  B <- n * .rowSums(pr$pp * pr$pa / pr$p, 2L * J, 3L)
  C <- n * .rowSums(pr$pa^2 / pr$p, 2L * J, 3L)
  E <- A[odd] + A[even]; F <- B[odd] + B[even]; G <- C[odd] + C[even]
  invv1 <- A[even] / E; invv2 <- numeric(J)
  determinant <- E[active] * G[active] - F[active]^2
  invv1[active] <- (G[active] * A[even[active]] - F[active] * B[even[active]]) / determinant
  invv2[active] <- (E[active] * B[even[active]] - F[active] * A[even[active]]) / determinant
  # A sum of squared efficient-score derivatives avoids cancellation in the
  # equivalent Schur complement A2 - v' K^-1 v near an association boundary.
  coefficient <- rep(c(0, 1), J) - rep(invv1, each = 2L)
  efficient_derivative <- pr$pp * coefficient - pr$pa * rep(invv2, each = 2L)
  efficient <- sum(n * .rowSums(efficient_derivative^2 / pr$p, 2L * J, 3L) +
                     u * coefficient^2 / (pi * (1 - pi)))
  variance <- pr$p[, 1L] * (2 * pi)^2 + pr$p[, 2L] * (1 - 2 * pi)^2 +
    pr$p[, 3L] * (2 - 2 * pi)^2
  list(A = A, B = B, C = C, E = E, F = F, G = G,
       determinant = determinant, invv1 = invv1, invv2 = invv2,
       efficient = efficient, variance = variance)
}

.classical_information <- function(pi, association, n, u, active, strata, model,
                                   probability = NULL, components = NULL) {
  model <- .classical_model(model)
  if (is.null(probability))
    probability <- .classical_probability(pi, association, active, model)
  parts <- if (is.null(components))
    .classical_components(pi, probability, n, u, active) else components
  J <- length(strata); even <- seq.int(2L, 2L * J, 2L)
  nm <- c("d", paste0("baseline[", strata, "]"),
          if (length(active)) paste0("association[", strata[active], "]"))
  info <- matrix(0, length(nm), length(nm), dimnames = list(nm, nm))
  info[1L, 1L] <- sum(parts$A[even])
  info[1L, 1L + seq_len(J)] <- info[1L + seq_len(J), 1L] <- parts$A[even]
  diag(info)[1L + seq_len(J)] <- parts$E
  if (length(active)) {
    ia <- 1L + J + seq_along(active); ib <- 1L + active
    info[1L, ia] <- info[ia, 1L] <- parts$B[even[active]]
    info[cbind(ib, ia)] <- info[cbind(ia, ib)] <- parts$F[active]
    diag(info)[ia] <- parts$G[active]
  }
  c(list(matrix = info), parts)
}

.classical_evaluate_R <- function(x, data, active, model, fixed = NULL, counts) {
  z <- .classical_decode(x, data$J, active, model, fixed, counts$odd)
  invalid <- function() list(value = 1e100, gradient = rep(0, length(x)), invalid = TRUE)
  if (any(!is.finite(z$pi)) || any(z$pi <= 0 | z$pi >= 1)) return(invalid())
  pr <- .classical_probability(z$pi, z$association, active, model)
  if (any(!is.finite(pr$p)) || any(pr$p <= 0)) return(invalid())
  ll <- sum(counts$m * log(pr$p)) +
    sum(counts$u1 * log(z$pi) + counts$u0 * log1p(-z$pi))
  weights <- counts$m / pr$p
  up <- .rowSums(weights * pr$pp, 2L * data$J, 3L) +
    (counts$u1 - counts$n_unilateral * z$pi) / (z$pi * (1 - z$pi))
  ua <- .rowSums(weights * pr$pa, 2L * data$J, 3L)
  Ub <- up[counts$odd] + up[counts$even]
  Ua <- (ua[counts$odd] + ua[counts$even])[active]
  Ud <- sum(up[counts$even])
  gh <- Ub * z$bh
  gh[active] <- gh[active] + Ua * z$ab * z$bh[active]
  gd <- Ud + sum(Ub * z$bd) + sum(Ua * (z$ad + z$ab * z$bd[active]))
  gradient <- -c(if (z$free) (1 - z$d^2) * gd, gh, Ua * z$ar)
  list(value = -ll, gradient = gradient, score = c(Ud, Ub, Ua),
       natural = z, probability = pr,
       invalid = !is.finite(ll) || any(!is.finite(gradient)))
}

.classical_fit <- function(data, model, d = NULL, start = NULL, control = list(),
                           prepared = NULL, profile = FALSE) {
  model <- .classical_model(model)
  data <- if (is.null(prepared)) .as_yule_data(data) else prepared$data
  ctl <- if (is.null(prepared)) .yule_fit_control(control) else prepared$controls
  if (!is.null(d) && (!is.numeric(d) || length(d) != 1L || !is.finite(d) || abs(d) >= 1))
    stop("d must be NULL or a number strictly between -1 and 1.", call. = FALSE)
  counts <- if (is.null(prepared)) .yule_fit_counts(data) else prepared$counts
  if (is.null(prepared)) counts$m <- cbind(counts$m0, counts$m1, counts$m2)
  active <- if (is.null(prepared))
    which(counts$n_bilateral[counts$odd] + counts$n_bilateral[counts$even] > 0) else prepared$active
  initial <- .yule_initial(data, active, d, prepared)
  pi <- as.vector(rbind(initial$baseline, initial$baseline + initial$d))
  initial$association[] <- NA_real_
  for (j in active) {
    ix <- c(counts$odd[j], counts$even[j]); ix <- ix[counts$n_bilateral[ix] > 0]
    low <- pmax(0, 2 * pi[ix] - 1); width <- pi[ix] - low
    q <- pmax(low + 1e-4 * width, pmin(pi[ix] - 1e-4 * width,
      (counts$m2[ix] + .5) / (counts$n_bilateral[ix] + 1)))
    a <- switch(model, dallal = q / pi[ix], rosner = q / pi[ix]^2,
                donner = (q - pi[ix]^2) / (pi[ix] * (1 - pi[ix])))
    initial$association[j] <- stats::weighted.mean(a, counts$n_bilateral[ix])
  }
  xstarts <- list(.classical_encode(initial$d, initial$baseline,
    initial$association, active, model, d))
  if (!is.null(start)) {
    if (inherits(start, "yule_fit")) {
      if (is.null(start$model) || !identical(tolower(start$model), model))
        stop("start uses a different association model.", call. = FALSE)
      if (!identical(start$data$strata, data$strata) || !identical(start$data$groups, data$groups))
        stop("start has incompatible stratum or group ordering.", call. = FALSE)
      start <- list(d = start$d, baseline = start$baseline, association = start$association)
    }
    if (!is.list(start))
      stop("start must contain compatible d, baseline, and native association values.", call. = FALSE)
    valid_a <- is.numeric(start$association) && length(start$association) == data$J &&
      all(is.finite(start$association[active]))
    if (valid_a) valid_a <- switch(model,
      dallal = all(start$association[active] > 0 & start$association[active] < 1),
      rosner = all(start$association[active] > 0),
      donner = all(abs(start$association[active]) < 1))
    if (!is.list(start) || !is.numeric(start$d) || length(start$d) != 1L ||
        !is.finite(start$d) || abs(start$d) >= 1 || !is.numeric(start$baseline) ||
        length(start$baseline) != data$J || any(!is.finite(start$baseline)) || !valid_a)
      stop("start must contain compatible d, baseline, and native association values.", call. = FALSE)
    if (!is.null(d)) start$d <- d
    x <- .classical_encode(start$d, start$baseline, start$association, active, model, d)
    xstarts <- if (ctl$multistart) c(list(x), xstarts) else list(x)
  }
  if (ctl$multistart && length(active)) {
    for (r in c(0, -1, 1)) {
      x <- xstarts[[length(xstarts)]]
      x[as.integer(is.null(d)) + data$J + seq_along(active)] <- r
      xstarts[[length(xstarts) + 1L]] <- x
    }
    neutral <- initial$association
    neutral[active] <- switch(model,
      dallal = initial$baseline[active] + initial$d / 2, rosner = 1, donner = 0)
    xstarts[[length(xstarts) + 1L]] <- .classical_encode(initial$d, initial$baseline,
      neutral, active, model, d)
  }
  xstarts <- xstarts[!duplicated(vapply(xstarts, paste, collapse = ",", character(1L)))]
  engine <- .native_fit_evaluator(data, active, model, d, counts)
  evaluate <- engine$evaluate
  optimize <- function(x, tolerance) tryCatch(engine$optimize(x, ctl$maxit, tolerance),
    error = function(e) NULL)
  candidates <- lapply(xstarts, optimize, tolerance = ctl$reltol)
  candidates <- Filter(function(o) !is.null(o) && is.finite(o$value) &&
                         !evaluate(o$par)$invalid, candidates)
  if (!length(candidates))
    stop("No finite interior likelihood fit was found; check sparse or degenerate data.", call. = FALSE)
  best <- candidates[[which.min(vapply(candidates, function(o) o$value, numeric(1L)))]]
  components <- function(fit) .classical_components(fit$natural$pi, fit$probability,
    counts$n_bilateral, counts$n_unilateral, active)
  scale_score <- function(fit, parts) {
    diagonal <- c(sum(parts$A[counts$even]), parts$E, parts$G[active])
    checked <- if (is.null(d)) seq_along(diagonal) else seq.int(2L, length(diagonal))
    max(abs(fit$score[checked]) / sqrt(pmax(diagonal[checked], 1)))
  }
  used <- sort(c(counts$odd[active], counts$even[active]))
  boundary <- function(fit) min(c(fit$natural$pi, 1 - fit$natural$pi,
    if (length(used)) fit$probability$p[used, , drop = FALSE] else Inf)) <= ctl$boundary_tol
  fit <- evaluate(best$par); steps <- backtracks <- 0L
  target <- min(ctl$gradient_tol / 10, 1e-7)
  parts <- components(fit)
  for (iteration in seq_len(min(30L, ctl$maxit))) {
    scaled <- scale_score(fit, parts)
    if (!is.finite(scaled) || boundary(fit) ||
        any(!is.finite(c(parts$E, parts$G[active], parts$determinant, parts$efficient))) ||
        any(c(parts$E, parts$G[active], parts$determinant, parts$efficient) <= 0)) break
    if (scaled <= target) { best$convergence <- 0L; break }
    Ub <- fit$score[1L + seq_len(data$J)]
    Ua <- fit$score[1L + data$J + seq_along(active)]
    invu1 <- Ub / parts$E; invu2 <- numeric(data$J)
    invu1[active] <- (parts$G[active] * Ub[active] - parts$F[active] * Ua) / parts$determinant
    invu2[active] <- (parts$E[active] * Ua - parts$F[active] * Ub[active]) / parts$determinant
    dd <- if (is.null(d)) (fit$score[1L] - sum(parts$A[counts$even] * invu1 +
      parts$B[counts$even] * invu2)) / parts$efficient else 0
    db <- invu1 - parts$invv1 * dd
    da <- (invu2 - parts$invv2 * dd)[active]
    direction <- c(dd, db, da)
    slope <- sum(fit$score * direction)
    if (any(!is.finite(direction)) || !is.finite(slope) || slope <= 0) break
    accepted <- FALSE; z <- fit$natural
    rounding <- 32 * .Machine$double.eps * max(1, abs(fit$value))
    for (bt in 0:24) {
      step <- 2^(-bt); td <- z$d + step * dd
      tb <- z$baseline + step * db; ta <- z$association
      ta[active] <- ta[active] + step * da
      tpi <- as.vector(rbind(tb, tb + td))
      if (abs(td) >= 1 || any(tpi <= 0 | tpi >= 1)) next
      bounds <- .classical_bounds(tpi, model, derivatives = FALSE, common_d = td)
      if (any(ta[active] <= bounds$lower[active] | ta[active] >= bounds$upper[active])) next
      tx <- .classical_encode(td, tb, ta, active, model, d, safe = FALSE)
      if (any(!is.finite(tx))) next
      trial <- evaluate(tx)
      if (trial$invalid || trial$value > fit$value + rounding) next
      trial_parts <- components(trial)
      trial_scaled <- scale_score(trial, trial_parts)
      if (trial$value <= fit$value - 1e-4 * step * slope ||
          (is.finite(trial_scaled) && trial_scaled < scaled)) {
        best$par <- tx; best$value <- trial$value; fit <- trial
        parts <- trial_parts
        steps <- steps + 1L; backtracks <- backtracks + bt; accepted <- TRUE; break
      }
    }
    if (!accepted) break
  }
  if (boundary(fit) || !is.finite(scale_score(fit, parts)) ||
      scale_score(fit, parts) > ctl$gradient_tol || best$convergence != 0L) {
    for (iteration in seq_len(2L)) {
      candidate <- optimize(best$par, min(ctl$reltol, 1e-13))
      if (!is.null(candidate) && candidate$value <= best$value + 1e-9 &&
          !evaluate(candidate$par)$invalid) best <- candidate
    }
    fit <- evaluate(best$par)
    parts <- components(fit)
  }
  z <- fit$natural; pr <- fit$probability
  info <- .classical_information(z$pi, z$association, counts$n_bilateral,
    counts$n_unilateral, active, data$strata, model,
    probability = pr, components = parts)
  scaled <- scale_score(fit, info); rawgradient <- max(abs(fit$gradient))
  is_boundary <- boundary(fit)
  nonsingular <- all(is.finite(info$matrix)) && all(diag(info$matrix) > 0) &&
    all(info$determinant > 0) && is.finite(info$efficient) && info$efficient > 0
  stationary <- is.finite(scaled) && scaled <= ctl$gradient_tol
  boundary_stationary <- is_boundary && is.finite(rawgradient) &&
    rawgradient / sqrt(max(1, data$N)) <= ctl$gradient_tol
  ok <- best$convergence == 0L && (stationary || boundary_stationary)
  regular <- ok && !is_boundary && nonsingular
  status <- if (!ok) "not_converged" else if (is_boundary) "boundary" else
    if (!nonsingular) "singular_information" else "converged"
  reason <- switch(status, converged = "Interior likelihood maximum with stationary scores.",
    boundary = "The estimate is near a parameter or probability boundary; regular inference is unavailable.",
    singular_information = "Expected information is singular; regular inference is unavailable.",
    not_converged = "Optimization did not satisfy the stationary-score criterion.")
  names(z$baseline) <- names(z$association) <- data$strata
  coefficients <- c(z$d, z$baseline, z$association[active])
  names(coefficients) <- names(fit$score) <- colnames(info$matrix)
  ct <- data$counts
  # Compact fits stay inside CI inversion and its warm starts. Public fitting
  # and testing always request full objects with display fields and caches.
  if (profile) {
    constant <- if (!is.null(prepared)) prepared$constant else
      sum(lgamma(ct$n_bilateral + 1) - lgamma(ct$m0 + 1) - lgamma(ct$m1 + 1) -
        lgamma(ct$m2 + 1) + lgamma(ct$n_unilateral + 1) - lgamma(ct$u0 + 1) - lgamma(ct$u1 + 1))
    return(structure(list(data = data, model = model, d = z$d, baseline = z$baseline,
      association = z$association, logLik = -fit$value + constant, logLik_kernel = -fit$value,
      score = fit$score, information = info$matrix, efficient_information = info$efficient,
      convergence = list(ok = ok, regular = regular, status = status, gradient = rawgradient,
        scaled_gradient = scaled, iterations = NA_integer_, evaluations = best$counts,
        boundary = is_boundary, reason = reason, starts = length(xstarts),
        likelihood_evaluations = engine$evaluations(), fisher_iterations = steps, fisher_backtracks = backtracks,
        minimum_probability = if (length(used)) min(pr$p[used, , drop = FALSE]) else Inf),
      fixed = !is.null(d), controls = ctl, active_association = active), class = "yule_fit"))
  }
  ptable <- data.frame(stratum = ct$stratum, group = ct$group, pi = z$pi,
    association = rep(z$association, each = 2L), p0 = pr$p[, 1L],
    p1 = pr$p[, 2L], p2 = pr$p[, 3L], q = pr$q)
  ptable[is.na(ptable$association), c("p0", "p1", "p2", "q")] <- NA_real_
  constant <- sum(lgamma(ct$n_bilateral + 1) - lgamma(ct$m0 + 1) -
    lgamma(ct$m1 + 1) - lgamma(ct$m2 + 1) + lgamma(ct$n_unilateral + 1) -
    lgamma(ct$u0 + 1) - lgamma(ct$u1 + 1))
  structure(list(data = data, model = model, d = z$d, baseline = z$baseline,
    association = z$association, probabilities = ptable, coefficients = coefficients,
    logLik = -fit$value + constant, logLik_kernel = -fit$value, logLik_constant = constant,
    score = fit$score, information = info$matrix, efficient_information = info$efficient,
    se = if (regular) 1 / sqrt(info$efficient) else NA_real_,
    convergence = list(ok = ok, regular = regular, status = status, gradient = rawgradient,
      scaled_gradient = scaled, iterations = NA_integer_, evaluations = best$counts,
      boundary = is_boundary, reason = reason, starts = length(xstarts),
      likelihood_evaluations = engine$evaluations(), fisher_iterations = steps,
      fisher_backtracks = backtracks,
      minimum_probability = if (length(used)) min(pr$p[used, , drop = FALSE]) else Inf),
    parameter_count = length(coefficients) - as.integer(!is.null(d)), fixed = !is.null(d),
    controls = ctl, active_association = active), class = "yule_fit",
    .yule_cache = new.env(parent = emptyenv()))
}
