# The registered evaluator computes the same likelihood and score as the R
# reference functions. The optimizer uses R's BFGS implementation directly;
# start selection, Fisher polishing and inference/regularity rules stay in R.
# Keep the R versions available for numerical audits on other toolchains.
.yule_evaluate <- function(x, data, active, fixed = NULL, counts = NULL) {
  derivatives <- is.null(counts)
  if (is.null(counts)) counts <- .yule_fit_counts(data)
  .Call(C_strat_evaluate, x, as.integer(data$J), active, 0L, fixed, counts,
        derivatives)
}
.classical_evaluate <- function(x, data, active, model, fixed = NULL, counts) {
  id <- switch(model, dallal = 1L, rosner = 2L, donner = 3L)
  .Call(C_strat_evaluate, x, as.integer(data$J), active, id, fixed, counts, TRUE)
}

# One private evaluator state survives all starts and polishing steps in a fit.
# BFGS needs only value and gradient, so its native callbacks retain a compact
# result. Expand that same cached point only when the R-side Fisher step or
# final diagnostics need natural scores and probabilities. Neither expansion
# nor repeated fn/gr requests count as a new parameter evaluation.
.native_fit_evaluator <- function(data, active, model, fixed, counts) {
  state <- new.env(parent = emptyenv())
  state$last <- state$val <- NULL
  state$compact <- FALSE
  state$evaluations <- 0L
  J <- as.integer(data$J)
  id <- switch(model, yule = 0L, dallal = 1L, rosner = 2L, donner = 3L)
  full <- if (model == "yule")
    function(x) .yule_evaluate(x, data, active, fixed, counts) else
    function(x) .classical_evaluate(x, data, active, model, fixed, counts)
  evaluate <- function(x) {
    changed <- is.null(state$last) || !identical(x, state$last)
    if (changed || isTRUE(state$compact)) {
      state$val <- full(x)
      state$last <- x
      state$compact <- FALSE
      if (changed) state$evaluations <- state$evaluations + 1L
    }
    state$val
  }
  optimize <- function(x, maxit, reltol) {
    .Call(C_strat_optim, x, J, active, id, fixed, counts, maxit, reltol, state)
  }
  list(evaluate = evaluate, optimize = optimize,
       evaluations = function() state$evaluations)
}
