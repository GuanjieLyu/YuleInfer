# First-order power along the correctly specified shared-Yule path.
yule_power <- function(baseline, association, n_bilateral, n_unilateral = 0,
                       d0 = 0, h = NULL, delta = NULL, alpha = .05) {
  .scalar(alpha, "alpha", 0, 1, open = TRUE)
  design <- .yule_design(baseline, d0, association, n_bilateral, n_unilateral)
  if (!is.null(h) && !is.null(delta))
    stop("Specify either 'h' or 'delta', not both.", call. = FALSE)
  if (is.null(h) && is.null(delta)) h <- 0
  if (is.null(h)) {
    delta <- .numeric_vector(delta, "delta")
    h <- sqrt(design$N) * delta
  } else {
    h <- .numeric_vector(h, "h")
    delta <- h / sqrt(design$N)
  }
  feasible <- vapply(delta, function(x)
    all(design$baseline + d0 + x > 0 & design$baseline + d0 + x < 1), logical(1L))
  if (any(!feasible))
    stop("A requested finite-N alternative has a noninterior treatment margin.", call. = FALSE)
  pi <- as.vector(t(design$pi))
  pr <- .yule_prob(pi, rep(design$association, each = 2L), derivatives = FALSE)
  variance <- rowSums(pr$p * (matrix(rep(0:2, each = length(pi)), length(pi), 3L) - 2 * pi)^2)
  A <- matrix(4 * as.vector(t(design$n)) / variance +
                as.vector(t(design$u)) / (pi * (1 - pi)), design$J, 2L, byrow = TRUE)
  # The reciprocal form avoids overflow of the product at very small risks.
  information <- sum(1 / (1 / A[, 1L] + 1 / A[, 2L]))
  if (!is.finite(information) || information <= 0)
    stop("The design has unusable efficient information.", call. = FALSE)
  per_subject <- information / design$N
  lambda <- h^2 * per_subject
  power <- stats::pchisq(stats::qchisq(alpha, 1L, lower.tail = FALSE), df = 1L,
                         ncp = lambda, lower.tail = FALSE)
  result <- data.frame(N = design$N, d0 = d0, delta = delta, h = h,
                       total_information = information,
                       information_per_subject = per_subject,
                       lambda = lambda, power = power, alpha = alpha)
  attr(result, "design") <- design
  result
}
